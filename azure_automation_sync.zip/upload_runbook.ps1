
# Upload runbook content
$automationAccount = "databricksUserSync"
$resourceGroup = "your-resource-group-name"
$runbookName = "SyncDatabricksUsers"
$runbookFile = "./runbook.ps1"

az automation runbook replace-content `
  --name $runbookName `
  --resource-group $resourceGroup `
  --automation-account-name $automationAccount `
  --content-path $runbookFile
