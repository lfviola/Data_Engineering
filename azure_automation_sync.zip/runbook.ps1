
Connect-MgGraph -Identity -Scopes "Group.Read.All", "User.Read.All"

$groupId         = Get-AutomationVariable -Name "group_id"
$databricksUrl   = Get-AutomationVariable -Name "databricks_url"
$databricksToken = Get-AutomationVariable -Name "databricks_token"

try {
    $previousRaw = Get-AutomationVariable -Name "previous_members"
    $previousMembers = $previousRaw -split ","
} catch {
    $previousMembers = @()
}

$currentMembers = Get-MgGroupMember -GroupId $groupId -All | Where-Object {$_.UserPrincipalName} | ForEach-Object { $_.UserPrincipalName }

$addedMembers = $currentMembers | Where-Object { $_ -notin $previousMembers }
$removedMembers = $previousMembers | Where-Object { $_ -notin $currentMembers }

foreach ($user in $addedMembers) {
    Write-Output "Adding user to Databricks: $user"
    $headers = @{
        Authorization = "Bearer $databricksToken"
        'Content-Type' = 'application/scim+json'
    }

    $body = @{
        userName = $user
        emails   = @(@{ value = $user })
        entitlements = @(@{ value = "allow-cluster-create" })
    } | ConvertTo-Json -Depth 3

    try {
        Invoke-RestMethod -Uri "$databricksUrl/api/2.0/preview/scim/v2/Users" -Method Post -Headers $headers -Body $body
        Write-Output "✅ Added $user"
    } catch {
        Write-Output "⚠️ Could not add $user: $_"
    }
}

foreach ($user in $removedMembers) {
    Write-Output "⚠️ User $user removed from group – manual cleanup needed"
}

$newRaw = ($currentMembers -join ",")
Set-AutomationVariable -Name "previous_members" -Value $newRaw
