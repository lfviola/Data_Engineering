#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from os import getenv
from setuptools import setup

setup(version=getenv("AAB_APPLICATION_VERSION"))
