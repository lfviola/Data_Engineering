# README

- Configure pip with trusted hosts pypi.org, pypi.python.org, files.pythonhosted.org either in pip.conf:
  ```
  [global]
  trusted-host = pypi.org pypi.python.org files.pythonhosted.org
  ```
  or command-line
  ```
  pip config set global.trusted-host "pypi.org files.pythonhosted.org pypi.python.org"
  ```
- Clone the repo
- cd into cloned dir
- Install python 3.10
- Create a virtual environment
- Install requirements.txt, if you run into a timeout error, use the `pip install --default-timeout=100` flag
- install package in editable mode  `pip install -e .`
- **Optional**: _Create a `pre-commit-config.yaml` file following this [template](#pre-commit-configuration), Install pre-commit `pip install pre-commit` and the hooks `pre-commit install`_

  If you like to use `pre-commit`, make sure you manually update your `.pre-commit-config.yaml` if CI formatting checks fail by running `pre-commit autoupdate`.
    Otherwise, manually use `ruff format` to format your code. This is due to the fact that ruff versions in the `pre-commit` hooks and our CI pipelines are defined differently and can go out of sync.
- Run tests using `pytest`
- When commiting, if you get SSL error, run `git config --global http.sslbackend schannel`

## Release Processs
- Make sure that there are no open PRs
- Switch to main branch
- Pull the latest changes
- check the last version in `tbump.toml`
- Bump the version using `tbump {NEW_VERSION}`
- This will create a new commit and automatically push new tag with v{NEW_VERSION}




### Recommended IDE Setup/Plugins
- Ruff
- SonarLint (connect to SonarQube account and corresponding project)
- Azure pipelines




------
# About this package
This is the DQE Modernization package to manage the logic for automated data quality checks.
It's expected to works with Databricks and provide the logic layer for automated checks.

## Documentation
For more in depth documentation, see the `docs` folder where the files give the following overviews:

1. Tutorials: Step-by-step guides to help you learn and implement key features in the codebase.
2. How-to Guides: Practical instructions for accomplishing specific tasks or solving common problems.
3. Reference: Detailed information on functions, modules, classes, infrastructure and KPI's for in-depth understanding.
4. Explanation: In-depth discussions to clarify complex concepts and provide knowledge.

## Pre-requesites
Make sure you have the latest version of PyPA’s build installed:
py -m pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org --upgrade build

Also wheel package:
python -m pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org wheel

And both PyTest and PySpark packcages:
python -m pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org -U pytest
python -m pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org -U pyspark

## How to test
For package tests it's needed to run the following command from python_package directory:
pytest

For manual tests during development you can use python, the following lines are an example of how to run filter:
from dqe_modernization.filter import Filter
from pyspark.sql import Row

data1 = Row(type="equals",attribute="column_X",value="CA")
data2 = [Row(type="equals",attribute="column_X",value="CA"),Row(type="equals",attribute="column_Y",value="AC")]

A = Filter(data1).getFilter()
B = Filter(data2).getFilter()

## How to build the package
Due access limitation on ABN AMRO network to external URL's, it's not possible to build the complete package set, but it's possible to build wheel packages, which can be used to install in any environment, as local computer or Databricks.

To build the wheel package run the command:

python ./setup.py bdist_wheel

## How to update it our environments
Despite of we can just update the file into Databricks cluster library, for the automatically run it's done with job clusters, to update the package for that it's a 2 steps task:

The first step is only needed if the file name changed, e.g. in case of a different version, in this case ADF need to be updated for the new name, for that check our ADF documentation.

The second step is to update the file into Databricks, for that:
- Open Databricks
- In the left menu click in **Data** to open the slide menu
- At the top left of that menu change the type from *Database Tables* to **DBFS**
- Select the **FileStore** folder
- Delete current file for that package
- At the top right of that menu click in **Upload** and a new pop-up window will appear
- Drag and Drop the file at the center of that windon, or click on it to choose the file location
- Once the file is uploaded, click in **Done** to finish this step

## Usage
You can use this package as any other python package, just remember that's expected to be run from Databricks with a SparkSessin, otherwise you will need to provide the SparkSession in your code if you plan to use outside it.

## Samples
### Filter
The following shows how to use filters from a Dataframe:

from dqe_modernization.filter import Filter
dataframe.filter(Filter(row).filter())

## More about Markdown
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)

## Pre-commit configuration

```
repos:
-   repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.6.0
    hooks:
    -   id: end-of-file-fixer
    -   id: trailing-whitespace
- repo: https://github.com/astral-sh/ruff-pre-commit
  # Ruff version.
  rev: v0.5.7
  hooks:
    # Run the linter.
    - id: ruff
      args: [ --fix ]
    # Run the formatter.
    - id: ruff-format
```
