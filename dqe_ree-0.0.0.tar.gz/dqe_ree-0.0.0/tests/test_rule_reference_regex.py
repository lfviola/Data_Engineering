import pytest
from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import ParameterNotFoundException

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_uuid",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "phone",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
    "bd5cce48-424e-4158-a046-c149625e5910": "is_male",
    "bd5cce48-424e-4158-a046-c149625e5911": "user_uuid",
    "bd5cce48-424e-4158-a046-c149625e5912": "index_str",
    "bd5cce48-424e-4158-a046-c149625e5913": "index_str_test",
    "bd5cce48-424e-4158-a046-c149625e5914": "index_str_test2",
    "bd5cce48-424e-4158-a046-c149625e5915": "index_str_test_int",
    "bd5cce48-424e-4158-a046-c149625e5916": "dq_dataset_name",
    "bd5cce48-424e-4158-a046-c149625e5917": "column_name",
    "bd5cce48-424e-4158-a046-c149625e5918": "data_attribute_uuid",
    "bd5cce48-424e-4158-a046-c149625e5919": "data_attribute_uuid_int",
    "bd5cce48-424e-4158-a046-c149625e5920": "primary_key",
    "bd5cce48-424e-4158-a046-c149625e5921": "dq_dataset_name_ref",
    "bd5cce48-424e-4158-a046-c149625e5922": "column_name_ref",
    "bd5cce48-424e-4158-a046-c149625e5923": "data_attribute_uuid_ref",
    "bd5cce48-424e-4158-a046-c149625e5924": "data_attribute_uuid_int_ref",
    "bd5cce48-424e-4158-a046-c149625e5925": "primary_key_ref",
    "bd5cce48-424e-4158-a046-c149625e5930": "postal_code",
    "bd5cce48-424e-4158-a046-c149625e5931": "country",
    "bd5cce48-424e-4158-a046-c149625e5932": "regex_data_attribute",
    "bd5cce48-424e-4158-a046-c149625e5933": "country_ref",
}


def get_latest_file(filename):
    return "tests/resources/ref_data.csv"


helper_functions = {"get_latest_file": get_latest_file}


@pytest.mark.usefixtures("df_regex", "spark_session", "metadata_df")
def test_reference_check_regex(df_regex, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_referenced_regex",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5933",
                "lookup_attribute_id": "bd5cce48-424e-4158-a046-c149625e5931",
                "reference_regex_attribute_id": "bd5cce48-424e-4158-a046-c149625e5932",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5930",
                "data_attribute_source": "dsapp",
            },
        },
    }

    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        df_regex,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions,
        metadata_table=metadata_df,
        testing=True,
    )
    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == df_regex.count()
    assert hits_count == 3
    assert passing_recs_count == 4
    assert df_regex.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("df_regex", "spark_session", "metadata_df")
def test_on_without_parameter(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_referenced_regex",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5911",
                "reference_regex_attribute_id": "bd5cce48-424e-4158-a046-c149625e5932",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ParameterNotFoundException,
        match=r"Required parameter 'lookup_attribute_id' not found.",
    ):
        run_check(
            spark_session,
            data_frame,
            rule_json,
            att_colname_map,
            helper_func_dict=helper_functions,
            metadata_table=metadata_df,
            testing=True,
        )


@pytest.mark.usefixtures("df_regex", "spark_session", "metadata_df")
def test_on_wrong_regex_datatype(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_referenced_regex",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5908",
                "lookup_attribute_id": "bd5cce48-424e-4158-a046-c149625e5931",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ParameterNotFoundException,
        match=r"Required parameter 'reference_regex_attribute_id' not found.",
    ):
        run_check(
            spark_session,
            data_frame,
            rule_json,
            att_colname_map,
            helper_func_dict=helper_functions,
            metadata_table=metadata_df,
            testing=True,
        )
