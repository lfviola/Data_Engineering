# test_rule.py
import pytest
from unittest.mock import MagicMock
from pyspark.sql import DataFrame
from pyspark.sql.types import StructType, StructField, StringType

from dq_engine.rules.rule import Rule, ParameterDefinition
from dq_engine.rules.custom_exceptions import (
    ColumnNotFoundException,
    ParameterNotFoundException,
)
from dq_engine.lib import get_all_rules


@pytest.fixture
def sample_rule_class():
    class _SampleRule(Rule):
        @classmethod
        def uuid(cls) -> str:
            return "sample-rule-uuid"

        @classmethod
        def functional_name(cls) -> str:
            return "Sample Rule"

        @classmethod
        def description(cls) -> str:
            return "A rule for sample purposes."

        @classmethod
        def subdimension(cls) -> str:
            return "sample"

        @classmethod
        def parameter_definitions(cls) -> list:
            return [
                ParameterDefinition(
                    technical_name="test_param",
                    functional_name="Test Parameter",
                    description="A test parameter",
                    value_type="string",
                    logical_type="value",
                    required=True,
                )
            ]

        @classmethod
        def aliases(cls):
            return ["sample-rule", "example-rule"]

        def passing(self, data_frame: DataFrame) -> DataFrame:
            return data_frame

        def failing(self, data_frame: DataFrame) -> DataFrame:
            return data_frame

    return _SampleRule


@pytest.fixture
def sample_dataframe(spark_session):
    schema = StructType(
        [
            StructField("column_name", StringType(), True),
            StructField("data_attribute_uuid", StringType(), True),
        ]
    )
    data = [("TestColumn", "uuid-123")]
    return spark_session.createDataFrame(data, schema)


def test_get_column_name(sample_rule_class, sample_dataframe):
    rule = sample_rule_class(
        spark=MagicMock(),
        data_attribute_uuid="uuid-123",
        parameters={"test_param": "value"},
        att_colname_map={"uuid-123": "TestColumn"},
        metadata_dataframe=sample_dataframe,
    )
    assert rule.get_column_name("uuid-123") == "TESTCOLUMN"


def test_validate_column_name_raises_exception(sample_rule_class, sample_dataframe):
    rule = sample_rule_class(
        spark=MagicMock(),
        data_attribute_uuid="uuid-123",
        parameters={"test_param": "value"},
        att_colname_map={"uuid-123": "TestColumn"},
        metadata_dataframe=sample_dataframe,
    )
    with pytest.raises(ColumnNotFoundException, match=""):
        rule.validate_column_name(
            sample_dataframe.withColumnRenamed("TestColumn", "WrongColumn")
        )


def test_parse_parameters_raises_exception(sample_rule_class):
    with pytest.raises(
        ParameterNotFoundException, match="Required parameter 'test_param' not found."
    ):
        _rule = sample_rule_class(
            spark=MagicMock(),
            data_attribute_uuid="uuid-123",
            parameters={},
            att_colname_map={"uuid-123": "TestColumn"},
        )


def test_usage_examples():
    for cls_obj in get_all_rules():
        cls_obj.usage_examples()
