import pytest
from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import (
    DatatypeException,
    InvalidRegexException,
    DataAttributeNotFoundException,
)
from dq_engine.rules.helpers import get_datatype_from_colname

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "phone",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
}


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_email_regex(data_frame, spark_session):
    regex = """^[a-z0-9]+(?:[._][a-z0-9]+)*@(?:\\w+\\.)+\\w{2,3}$"""
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_generic_regex",
            "parameters": {"regex": regex},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5906",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 2
    assert passing_count == 998
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_first_name_regex(data_frame, spark_session):
    regex = """^([^0-9]*)$"""
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_generic_regex",
            "parameters": {"regex": regex},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 0
    assert passing_count == 1000
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("spark_session")
def test_special_characters_regex(spark_session):
    """This test checks the regex for special characters."""
    data = [
        (1, "MOÇAMBIQUE"),
        (2, "MOÇAMBIQUE"),
        (3, "MOÇAMBIQUE"),
        (4, "São Gonçalo"),  # Passing
        (5, "VALENÇA*VIANA DO CASTELO"),
    ]
    data_frame = spark_session.createDataFrame(data, ["ID", "PLC_OF_BRTH"])

    regex = """^[a-zA-Z-'-ÄäãáËëÉéÏïíÍÖÓóöÜÚüúñçß. ]+$"""
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_generic_regex",
            "parameters": {"regex": regex},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5999",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        data_frame,
        rule_json,
        {
            "bd5cce48-424e-4158-a046-c149625e5998": "ID",
            "bd5cce48-424e-4158-a046-c149625e5999": "PLC_OF_BRTH",
        },
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 4
    assert passing_count == 1
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()
    assert (
        "São Gonçalo"
        == passing_recs.select("PLC_OF_BRTH").distinct().collect()[0]["PLC_OF_BRTH"]
    )


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_last_name_regex(data_frame, spark_session):
    regex = """^([^0-9]*)$"""
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_generic_regex",
            "parameters": {"regex": regex},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 1
    assert passing_count == 999
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_regex_as_filter(data_frame, spark_session):
    regex = "^.*org.*$"
    rule_json = {
        "filters": [
            {
                "technical_name": "expect_column_values_to_match_generic_regex",
                "parameters": {"regex": regex},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5906",
                    "data_attribute_source": "dsapp",
                },
            }
        ],
        "rule": {
            "technical_name": "expect_column_values_to_match_generic_regex",
            "parameters": {"regex": "^.*Male.*$"},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    filtered_count = filtered_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == filtered_count
    assert hits_count == 161
    assert passing_count == 182
    assert filtered_count == 343
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_invalid_regex(data_frame, spark_session):
    regex = """*)$"""
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_generic_regex",
            "parameters": {"regex": regex},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(InvalidRegexException, match="Not a valid regex expression."):
        run_check(spark_session, data_frame, rule_json, att_colname_map)


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_data_type_type(data_frame, spark_session):
    regex = """^([^0-9]*)$"""
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_generic_regex",
            "parameters": {"regex": regex},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        DatatypeException,
        match=f"Column type {get_datatype_from_colname(data_frame, att_colname_map['bd5cce48-424e-4158-a046-c149625e5908'])} not supported. Only strings, integers and longs types are currently supported",
    ):
        run_check(spark_session, data_frame, rule_json, att_colname_map)


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_float_datatype(data_frame, spark_session):
    regex = """^([^0-9]*)$"""
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_generic_regex",
            "parameters": {"regex": regex},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                "data_attribute_source": "dsapp",
            },
        },
    }
    data_frame = data_frame.withColumn("index", data_frame["index"].cast("float"))
    with pytest.raises(
        DatatypeException,
        match="Column type float not supported. Only strings, integers and longs types are currently supported",
    ):
        run_check(spark_session, data_frame, rule_json, att_colname_map)


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_decimal_datatype(data_frame, spark_session):
    regex = """^([^0-9]*)$"""
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_generic_regex",
            "parameters": {"regex": regex},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                "data_attribute_source": "dsapp",
            },
        },
    }
    data_frame = data_frame.withColumn("index", data_frame["index"].cast("decimal"))
    with pytest.raises(
        DatatypeException,
        match="Column type decimal not supported. Only strings, integers and longs types are currently supported",
    ):
        run_check(spark_session, data_frame, rule_json, att_colname_map)


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_like_pattern(data_frame, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_sql_like_pattern",
            "parameters": {"like_pattern": "%example.com"},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5906",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == filtered_recs.count()
    assert hits_count == 661
    assert passing_count == 339
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_incorrect_data_attribute_uuid(data_frame, spark_session):
    regex = """^([^0-9]*)$"""
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_match_generic_regex",
            "parameters": {"regex": regex},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5999",
                "data_attribute_source": "dsapp",
            },
        },
    }
    data_frame = data_frame.withColumn("index", data_frame["index"].cast("decimal"))
    with pytest.raises(
        DataAttributeNotFoundException,
        match="Data attribute 'bd5cce48-424e-4158-a046-c149625e5999' is not defined on the flat file. Please check the validity of the provided data attribute uuid.",
    ):
        run_check(spark_session, data_frame, rule_json, att_colname_map)
