import pytest
from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import ParameterNotFoundException

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "phone",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
}
att_colname = {
    "cd5cce48-424e-4158-a046-c149625e5901": "index",
    "cd5cce48-424e-4158-a046-c149625e5902": "year",
    "cd5cce48-424e-4158-a046-c149625e5903": "value",
    "cd5cce48-424e-4158-a046-c149625e5904": "value_as_string_with_decimal",
    "cd5cce48-424e-4158-a046-c149625e5905": "value_with_decimal",
}

att_colname_amount = {
    "dd5cce48-424e-4158-a046-c149625e5901": "AMOUNT",
    "dd5cce48-424e-4158-a046-c149625e5902": "credit_amount",
    "dd5cce48-424e-4158-a046-c149625e5903": "Debit_amount",
    "dd5cce48-424e-4158-a046-c149625e5904": "Due_date",
    "dd5cce48-424e-4158-a046-c149625e5905": "Total_Amount",
}


class TestDateFormatRule:
    rule_name = "expect_column_values_to_be_valid_date_format"

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_date(self, spark_session, data_frame):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"date_format": "yyyy-MM-dd"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 0
        assert passing_count == data_frame.count()
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("date_dataframe", "spark_session")
    def test_column_with_numbers_and_special_characters(
        self, spark_session, date_dataframe
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"date_format": "yyyy-MM-dd"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_dataframe, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_dataframe.count()
        assert hits_count == 2
        assert passing_count == 9
        assert date_dataframe.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("date_dataframe", "spark_session")
    def test_rule_with_wrong_parameter_name(self, spark_session, date_dataframe):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"": "yyyy-MM-dd"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException, match="Parameter 'date_format' not found."
        ):
            run_check(spark_session, date_dataframe, rule_json, att_colname_map)

    @pytest.mark.usefixtures("date_dataframe", "spark_session")
    def test_rule_with_wrong_parameter_type(self, spark_session, date_dataframe):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException, match="Parameter 'date_format' not found."
        ):
            run_check(spark_session, date_dataframe, rule_json, att_colname_map)

    @pytest.mark.usefixtures("date_dataframe", "spark_session")
    def test_column_with_wrong_date_format(self, spark_session, date_dataframe):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"date_format": "dd-MM-yyyy"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_dataframe, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_dataframe.count()
        assert hits_count == 11
        assert date_dataframe.count() == out_of_scope_recs_count + filtered_recs.count()


class TestToBeNumbersRule:
    rule_name = "expect_column_values_to_be_numbers"

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_numbers_and_letters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_numbers(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 0
        assert passing_count == data_frame.count()
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_string(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_string_and_special_characters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_type(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError,
            match=f"Column {att_colname_map['bd5cce48-424e-4158-a046-c149625e5908'].upper()} is not a number.",
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("decimal_df", "spark_session")
    def test_column_with_decimal(self, spark_session, decimal_df):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "cd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df.count()
        assert hits_count == 18
        assert passing_count == 2
        assert decimal_df.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df", "spark_session")
    def test_on_column_with_decimal_values_only(self, spark_session, decimal_df):
        decimal_df = decimal_df.withColumn(
            "value_with_decimal", decimal_df["value_with_decimal"].cast("double")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "cd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df.count()
        assert hits_count == 3
        assert passing_count == 17
        assert decimal_df.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df", "spark_session")
    def test_on_column_with_string_decimal_values_only(self, spark_session, decimal_df):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "cd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df.count()
        assert hits_count == 3
        assert passing_count == 17
        assert decimal_df.count() == out_of_scope_recs_count + filtered_recs.count()


class TestToBeWholeNumberRule:
    rule_name = "expect_column_values_to_be_a_whole_number"

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_number(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 0
        assert passing_count == data_frame.count()
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_string(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_string_and_null(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5909",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_string_and_special_characters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_type(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError,
            match=f"Column {att_colname_map['bd5cce48-424e-4158-a046-c149625e5908'].upper()} is not a number or a string.",
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("decimal_df", "spark_session")
    def test_column_with_decimal_as_string(self, spark_session, decimal_df):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "cd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df.count()
        assert hits_count == 18
        assert passing_count == 2
        assert decimal_df.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df", "spark_session")
    def test_column_with_decimal_dot_as_string(self, spark_session, decimal_df):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "cd5cce48-424e-4158-a046-c149625e5904",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df.count()
        assert hits_count == 18
        assert passing_count == 2
        assert decimal_df.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df", "spark_session")
    def test_column_with_decimal_dot(self, spark_session, decimal_df):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "cd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df.count()
        assert hits_count == 17
        assert passing_count == 3
        assert decimal_df.count() == out_of_scope_recs_count + filtered_recs.count()


class TestToBevalidamount:
    rule_name = "expect_column_values_to_be_amount"

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_number(self, amount_df, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "dd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, amount_df, rule_json, att_colname_amount
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == amount_df.count()
        assert hits_count == 0
        assert passing_count == 9
        assert amount_df.count() == out_of_scope_recs_count + filtered_recs.count()

    def test_column_with_decimal(self, amount_df, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "dd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, amount_df, rule_json, att_colname_amount
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == amount_df.count()
        assert hits_count == 0
        assert passing_count == 9
        assert amount_df.count() == out_of_scope_recs_count + filtered_recs.count()

    def test_column_with_string_amount(self, amount_df, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "dd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, amount_df, rule_json, att_colname_amount
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == amount_df.count()
        assert hits_count == 2
        assert passing_count == 7
        assert amount_df.count() == out_of_scope_recs_count + filtered_recs.count()

    def test_column_with_string_null_value(self, amount_df, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "dd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, amount_df, rule_json, att_colname_amount
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == amount_df.count()
        assert hits_count == 6
        assert passing_count == 3
        assert amount_df.count() == out_of_scope_recs_count + filtered_recs.count()

    def test_column_with_date(self, amount_df, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "dd5cce48-424e-4158-a046-c149625e5904",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, amount_df, rule_json, att_colname_amount
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == amount_df.count()
        assert hits_count == 9
        assert passing_count == 0
        assert amount_df.count() == out_of_scope_recs_count + filtered_recs.count()
