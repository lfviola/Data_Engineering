import ast
import os
import shutil
from unittest.mock import MagicMock, call, patch

import pytest
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from dq_engine.lib import rule_json_export
from dq_engine.rules.custom_exceptions import (
    BaseException,
    DataAttributeNotFoundValidationException,
    FileNameNotFoundException,
    FileNotFoundException,
    FileReadException,
)
from dq_engine.rules_parser import (
    ChecksParser,
    get_parameters_combined,
    parse_and_flatten,
)

dqrem_path = os.path.join(os.path.dirname(__file__), "resources")
invalid_checks_folder = os.path.join(dqrem_path, "invalid_checks")
old_checks_df_dir = os.path.join(dqrem_path, "dq_checks")
new_checks_df_dir = os.path.join(dqrem_path, "new_dq_checks")
functional_name_technical_name_map = {
    rule["name"]: rule["technical_name"] for rule in rule_json_export()
}


def mock_get_latest_snapshot_file_path(file_name, *args, **kwargs):
    """
    Mocks the method `DatabricksHelperFunctions.get_latest_snapshot_file_path()` to
    retrieve desired path or error.
    """
    path_map = {
        "people_1000": "path1",
        "dq_dataset_df": "path2",
        "file1": "path1",
        "file2": "path2",
        "dq_dataset_1": "path_dq_dataset",
    }
    if file_name == "file_not_found":
        raise FileReadException(file_name)
    if file_name == "file_without_snapshot":
        raise IndexError
    if file_name in path_map:
        return path_map[file_name]
    else:
        raise FileNotFoundError


@pytest.mark.usefixtures(
    "spark_session",
    "dial_metadata_df",
    "dq_checks_valid",
    "dq_filters",
    "dq_dataset_metadata_dataframe",
)
def test_old_dq_checks_not_present_parquet(
    spark_session,
    dial_metadata_df,
    dq_checks_valid,
    dq_filters,
    dq_dataset_metadata_dataframe,
):
    databricks_helpers = MagicMock()
    databricks_helpers.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    obj = ChecksParser(
        spark_session,
        dqrem_path=dqrem_path,
        invalid_checks_folder=invalid_checks_folder,
        checks_dir=old_checks_df_dir,
        databricks_helpers=databricks_helpers,
        new_checks_dir=new_checks_df_dir,
        dial_metadata=dial_metadata_df,
        dq_dataset_metadata=dq_dataset_metadata_dataframe,
    )

    (
        not_found_files,
        new_checks,
        valid_checks_with_extra_colums,
        checks_without_filename,
        checks_without_snapshot,
        checks_with_attribute_errors,
    ) = obj.refresh_checks_and_return_new_checks_from_dataframe(
        dq_checks_valid, dq_filters, old_checks_df=None
    )
    assert len(not_found_files) == 0
    assert new_checks.count() == 3
    assert valid_checks_with_extra_colums.count() == 3
    assert checks_without_filename.count() == 2
    assert checks_without_snapshot.count() == 0
    assert (
        new_checks.filter(new_checks["id"] == "2-90ab-1234-567890abcdef")
        .select("file_name")
        .collect()[0]["file_name"]
        == "dq_dataset_1"
    )


@pytest.mark.usefixtures(
    "spark_session",
    "dial_metadata_df",
    "dq_checks_invalid",
    "dq_filters",
    "dq_dataset_metadata_dataframe",
)
def test_invalid_old_dq_checks_not_present_parquet(
    spark_session,
    dial_metadata_df,
    dq_checks_invalid,
    dq_filters,
    dq_dataset_metadata_dataframe,
):
    databricks_helpers = MagicMock()
    databricks_helpers.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    obj = ChecksParser(
        spark_session,
        dqrem_path=dqrem_path,
        invalid_checks_folder=invalid_checks_folder,
        checks_dir=old_checks_df_dir,
        databricks_helpers=databricks_helpers,
        new_checks_dir=new_checks_df_dir,
        dial_metadata=dial_metadata_df,
        dq_dataset_metadata=dq_dataset_metadata_dataframe,
    )

    (
        not_found_files,
        new_checks,
        valid_checks_with_extra_colums,
        checks_without_filename,
        checks_without_snapshot,
        checks_with_attribute_errors,
    ) = obj.refresh_checks_and_return_new_checks_from_dataframe(
        dq_checks_invalid, dq_filters, old_checks_df=None
    )
    assert len(not_found_files) == 0
    assert new_checks.count() == 1
    check_json = new_checks.first().check_json
    assert (
        ast.literal_eval(check_json)["rule"]["dq_dataset_data_attribute"][
            "data_attribute_uuid"
        ]
        is None
    )
    check_json_attribute_errors = checks_with_attribute_errors.first().check_json
    assert (
        ast.literal_eval(check_json_attribute_errors)["rule"][
            "dq_dataset_data_attribute"
        ]["data_attribute_uuid"]
        is None
    )
    assert valid_checks_with_extra_colums.count() == 1
    assert checks_without_filename.count() == 0
    assert checks_without_snapshot.count() == 0
    assert checks_with_attribute_errors.count() == 12
    assert checks_with_attribute_errors.groupBy("id").agg(F.count("id")).count() == 5


@pytest.mark.usefixtures(
    "spark_session",
    "dial_metadata_df",
    "dq_checks_valid_new",
    "dq_filters",
    "dq_dataset_metadata_dataframe",
)
def test_old_dq_checks_not_present_with_json_v3_parquet(
    spark_session,
    dial_metadata_df,
    dq_checks_valid_new,
    dq_filters,
    dq_dataset_metadata_dataframe,
):
    databricks_helpers = MagicMock()
    databricks_helpers.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    obj = ChecksParser(
        spark_session,
        dqrem_path=dqrem_path,
        invalid_checks_folder=invalid_checks_folder,
        checks_dir=old_checks_df_dir,
        databricks_helpers=databricks_helpers,
        new_checks_dir=new_checks_df_dir,
        dial_metadata=dial_metadata_df,
        dq_dataset_metadata=dq_dataset_metadata_dataframe,
    )

    (
        not_found_files,
        new_checks,
        valid_checks_with_extra_columns,
        checks_without_filename,
        checks_without_snapshot,
        checks_with_attribute_errors,
    ) = obj.refresh_checks_and_return_new_checks_from_dataframe(
        dq_checks_valid_new, dq_filters, old_checks_df=None
    )

    assert len(not_found_files) == 2
    assert new_checks.count() == 3
    assert valid_checks_with_extra_columns.count() == 3
    assert checks_without_filename.count() == 2
    assert checks_without_snapshot.count() == 2


@pytest.mark.usefixtures(
    "spark_session",
    "dial_metadata_df",
    "dq_checks_valid",
    "dq_checks_valid_new",
    "dq_filters",
    "dq_dataset_metadata_dataframe",
)
def test_compare_checks_parquet(
    spark_session,
    dial_metadata_df,
    dq_checks_valid,
    dq_checks_valid_new,
    dq_filters,
    dq_dataset_metadata_dataframe,
):
    databricks_helpers = MagicMock()
    databricks_helpers.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    obj = ChecksParser(
        spark_session,
        dqrem_path=dqrem_path,
        invalid_checks_folder=invalid_checks_folder,
        checks_dir=old_checks_df_dir,
        databricks_helpers=databricks_helpers,
        new_checks_dir=new_checks_df_dir,
        dial_metadata=dial_metadata_df,
        dq_dataset_metadata=dq_dataset_metadata_dataframe,
    )

    (
        not_found_files,
        new_checks,
        valid_checks_with_extra_colums,
        checks_without_filename,
        checks_without_snapshot,
        checks_with_attribute_errors,
    ) = obj.refresh_checks_and_return_new_checks_from_dataframe(
        dq_checks_valid, dq_filters, old_checks_df=None
    )

    old_checks = valid_checks_with_extra_colums

    (
        not_found_files,
        updated_checks,
        all_checks,
        checks_without_filename,
        checks_without_snapshot,
        checks_with_attribute_errors,
    ) = obj.refresh_checks_and_return_new_checks_from_dataframe(
        dq_checks_valid_new, dq_filters, old_checks_df=old_checks
    )

    assert updated_checks.count() == 1
    assert all_checks.count() == 3


@pytest.mark.usefixtures(
    "spark_session",
    "dial_metadata_df",
    "dq_checks_valid_new",
    "dq_filters",
    "dq_dataset_metadata_dataframe",
)
def test_check_file_not_found_for_check_parquet(
    spark_session,
    dial_metadata_df,
    dq_checks_valid_new,
    dq_filters,
    dq_dataset_metadata_dataframe,
):
    databricks_helpers = MagicMock()
    databricks_helpers.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    obj = ChecksParser(
        spark_session,
        dqrem_path=dqrem_path,
        invalid_checks_folder=invalid_checks_folder,
        checks_dir=old_checks_df_dir,
        databricks_helpers=databricks_helpers,
        new_checks_dir=new_checks_df_dir,
        dial_metadata=dial_metadata_df,
        dq_dataset_metadata=dq_dataset_metadata_dataframe,
    )

    (
        not_found_files,
        new_checks,
        valid_checks_with_extra_colums,
        checks_without_filename,
        checks_without_snapshot,
        checks_with_attribute_errors,
    ) = obj.refresh_checks_and_return_new_checks_from_dataframe(
        dq_checks_valid_new, dq_filters, old_checks_df=None
    )
    not_found_check_ids = [
        rec["id"] for rec in checks_without_filename.orderBy("id").collect()
    ]
    with pytest.raises(expected_exception=FileReadException):
        databricks_helpers.get_latest_snapshot_file_path("file_not_found", "dial")
    assert checks_without_filename.count() == 2
    assert not_found_check_ids == ["3-90ab-1234-567890abcdeg", "file_not_found"]
    assert not_found_files == [
        ["file_not_found", "dial"],
        ["file_without_snapshot", "dial"],
    ]
    assert new_checks.count() == 3
    assert valid_checks_with_extra_colums.count() == 3


@pytest.mark.usefixtures(
    "spark_session",
    "dial_metadata_df",
    "dq_checks_valid",
    "dq_filters",
    "dq_dataset_metadata_dataframe",
)
def test_return_check_json(
    spark_session,
    dial_metadata_df,
    dq_checks_valid,
    dq_filters,
    dq_dataset_metadata_dataframe,
):
    databricks_helpers = MagicMock()
    databricks_helpers.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    expected_rule_json = {
        "golden_data_element_id": 2,
        "id": "5-90ab-1234-567890abcdei",
        "check_version": 1,
        "description": "EDA compliancy",
        "status_id": "In Production",
        "source_id": "A",
        "file_name": "file2",
        "rule": {
            "technical_name": "expect_column_values_to_not_be_in_list",
            "functional_name": "must not be in list of values (automatable)",
            "parameters": {"values": ["Male", "Female"]},
            "data_attribute": {
                "data_attribute_uuid": "550e8400-e29b-41d4-a716-446655440004",
                "data_attribute_source": "DSApp",
            },
            "dq_dataset_data_attribute": {
                "data_attribute_uuid": None,
            },
        },
        "filters": [
            {
                "parameters": {"value": "Biomedical engineer"},
                "description": "equal to biomedical engineer",
                "data_attribute": {
                    "data_attribute_uuid": "550e8400-e29b-41d4-a716-446655440000",
                    "data_attribute_source": "DSApp",
                },
                "technical_name": "expect_column_values_to_be_equal_to_value",
            }
        ],
    }

    obj = ChecksParser(
        spark_session,
        dqrem_path=dqrem_path,
        invalid_checks_folder=invalid_checks_folder,
        checks_dir=old_checks_df_dir,
        databricks_helpers=databricks_helpers,
        new_checks_dir=new_checks_df_dir,
        dial_metadata=dial_metadata_df,
        dq_dataset_metadata=dq_dataset_metadata_dataframe,
    )
    (
        checks_with_filename,
        filename_checks_filters_dataframe,
        checks_without_filename,
    ) = obj.add_filename_to_checks_df(dq_checks_valid, dq_filters)
    rule_json = obj.return_check_json(
        checks_with_filename.first(),
        [dq_filters.first().asDict()],
        functional_name_technical_name_map,
    )

    assert rule_json == expected_rule_json


@pytest.mark.usefixtures(
    "spark_session",
    "dial_metadata_df",
    "dq_checks_valid",
    "dq_filters",
    "dq_dataset_metadata_dataframe",
)
def test_other_metadata_sources(
    spark_session,
    dial_metadata_df,
    dq_checks_valid,
    dq_filters,
    dq_dataset_metadata_dataframe,
):
    """Test that an error is raised when the given source is not supported."""
    dq_checks_valid = dq_checks_valid.withColumn(
        "data_attribute_source",
        F.when(
            dq_checks_valid["id"] == "4-90ab-1234-567890abcdeh", "not supported source"
        ).otherwise(dq_checks_valid["data_attribute_source"]),
    )

    databricks_helpers = MagicMock()
    databricks_helpers.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    obj = ChecksParser(
        spark_session,
        dqrem_path=dqrem_path,
        invalid_checks_folder=invalid_checks_folder,
        checks_dir=old_checks_df_dir,
        databricks_helpers=databricks_helpers,
        new_checks_dir=new_checks_df_dir,
        dial_metadata=dial_metadata_df,
        dq_dataset_metadata=dq_dataset_metadata_dataframe,
    )
    with pytest.raises(expected_exception=ValueError):
        obj.refresh_checks_and_return_new_checks_from_dataframe(
            dq_checks_valid, dq_filters, old_checks_df=None
        )


@pytest.mark.usefixtures(
    "spark_session",
    "dq_checks_valid",
    "dq_filters",
    "dial_metadata_df",
    "dq_dataset_metadata_dataframe",
)
def test_merge_checks_and_filters_dataframes_empty_filters(
    spark_session: SparkSession,
    dq_checks_valid: DataFrame,
    dq_filters: DataFrame,
    dial_metadata_df: DataFrame,
    dq_dataset_metadata_dataframe: DataFrame,
):
    """Test when empty df is provided for filters."""

    databricks_helpers = MagicMock()
    databricks_helpers.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    checks_parser = ChecksParser(
        spark_session,
        dqrem_path=dqrem_path,
        invalid_checks_folder=invalid_checks_folder,
        checks_dir=old_checks_df_dir,
        databricks_helpers=databricks_helpers,
        new_checks_dir=new_checks_df_dir,
        dial_metadata=dial_metadata_df,
        dq_dataset_metadata=dq_dataset_metadata_dataframe,
    )

    empty_filters_df = dq_filters.limit(0)

    (
        not_found_files,
        new_checks_df,
        all_checks_df,
        checks_without_filename_df,
        checks_without_snapshot,
        checks_with_attribute_errors,
    ) = checks_parser.refresh_checks_and_return_new_checks_from_dataframe(
        dq_checks_valid,
        empty_filters_df,
    )

    checks_and_filters = (
        new_checks_df.select("check_json").rdd.flatMap(lambda x: x).collect()
    )

    for check in checks_and_filters:
        assert len(ast.literal_eval(check)["filters"]) == 0


def __eq__(self, other):
    if isinstance(other, BaseException):
        return self.error_code == other.error_code and self.message == other.message
    return False


@pytest.mark.usefixtures(
    "spark_session",
    "dq_filters",
    "parsed_checks",
    "checks_without_filename",
    "checks_without_snapshot",
    "checks_with_attribute_errors",
)
def test_write_outputs(
    spark_session: SparkSession,
    dq_filters: DataFrame,
    parsed_checks: DataFrame,
    checks_without_filename: DataFrame,
    checks_without_snapshot: DataFrame,
    checks_with_attribute_errors: DataFrame,
):
    setattr(BaseException, "__eq__", __eq__)
    with patch("dq_engine.rules_parser.log_check_output") as mock_log_check_output:
        checks_parser = ChecksParser(
            spark_session,
            dqrem_path=dqrem_path,
            invalid_checks_folder=invalid_checks_folder,
            checks_dir=old_checks_df_dir,
            databricks_helpers=MagicMock(),
            new_checks_dir=new_checks_df_dir,
            dial_metadata=MagicMock(),
            dq_dataset_metadata=MagicMock(),
        )

        checks_parser.cache_outputs = {
            "not_found_files": [],
            "new_checks_df": parsed_checks,
            "all_checks_df": parsed_checks,
            "checks_without_filename_df": checks_without_filename,
            "filters_dataframe": dq_filters,
            "checks_without_snapshot": checks_without_snapshot,
            "checks_with_attribute_errors": checks_with_attribute_errors,
        }
        dbutils_mock = MagicMock()
        spark_mock = MagicMock()
        checks_parser.databricks_helpers.dbutils_obj = dbutils_mock
        checks_parser.databricks_helpers.spark = spark_mock
        checks_parser.log_invalid_checks = MagicMock()
        checks_parser.save_parquet = MagicMock()

        output_paths = [
            "./tests/resources/dq_checks",
            "./tests/resources/invalid_checks",
            "./tests/resources/new_dq_checks",
        ]

        try:
            checks_parser.write_outputs()

            expected_call_list = [
                call(
                    spark=spark_mock,
                    dbutils=dbutils_mock,
                    rule_id="601333bb-df64-42d1-b808-3bcb6068c714",
                    rule_json_dict={"check": "definition"},
                    error=[
                        DataAttributeNotFoundValidationException(
                            "12344143432", "file1", "rule", "regular"
                        ),
                        DataAttributeNotFoundValidationException(
                            "12344143432", "file2", "rule", "reference"
                        ),
                    ],
                    logs_directory="check_outputs",
                    dq_lib_logs_directory="check_outputs",
                ),
                call(
                    spark=spark_mock,
                    dbutils=dbutils_mock,
                    rule_id="601333bb-df64-42d1-b808-3bcb6068c715",
                    rule_json_dict={"check": "definition"},
                    error=[
                        DataAttributeNotFoundValidationException(
                            "550e8400-e29b-41d4-a716-39293020",
                            "file1",
                            "rule",
                            "regular",
                        ),
                        DataAttributeNotFoundValidationException(
                            "550e8400-e29b-41d4-a716-446655440099",
                            "file1",
                            "filter",
                            "regular",
                        ),
                    ],
                    logs_directory="check_outputs",
                    dq_lib_logs_directory="check_outputs",
                ),
                call(
                    spark=spark_mock,
                    dbutils=dbutils_mock,
                    rule_id="1",
                    rule_json_dict={
                        "golden_data_element_id": 101,
                        "id": "1",
                        "check_version": 5,
                        "description": "Check functional description",
                        "status_id": "Approved",
                        "source_id": "Source1",
                        "file_name": None,
                        "rule": {
                            "technical_name": "Rule1",
                            "functional_name": "Rule1",
                            "parameters": {"param1": "value1", "param2": "value2"},
                            "data_attribute": {
                                "data_attribute_uuid": "UUID1",
                                "data_attribute_source": "SourceA",
                            },
                            "dq_dataset_data_attribute": {
                                "data_attribute_uuid": "UUID_Dataset1"
                            },
                        },
                        "filters": [
                            {
                                "parameters": {"value": "Biomedical engineer"},
                                "description": "equal to biomedical engineer",
                                "data_attribute": {
                                    "data_attribute_uuid": "550e8400-e29b-41d4-a716-446655440000",
                                    "data_attribute_source": "SourceA",
                                },
                                "technical_name": "expect_column_values_to_be_equal_to_value",
                            }
                        ],
                    },
                    error=FileNameNotFoundException(
                        "filename not found for data attribute uuid."
                    ),
                    logs_directory="check_outputs",
                    dq_lib_logs_directory="check_outputs",
                ),
                call(
                    spark=spark_mock,
                    dbutils=dbutils_mock,
                    rule_id="2",
                    rule_json_dict={
                        "golden_data_element_id": 102,
                        "id": "2",
                        "check_version": 6,
                        "description": "Another functional description",
                        "status_id": "Pending",
                        "source_id": "Source2",
                        "file_name": None,
                        "rule": {
                            "technical_name": "Rule2",
                            "functional_name": "Rule2",
                            "parameters": {"param1": "value1", "param2": "value2"},
                            "data_attribute": {
                                "data_attribute_uuid": "UUID2",
                                "data_attribute_source": "SourceB",
                            },
                            "dq_dataset_data_attribute": {
                                "data_attribute_uuid": "UUID_Dataset2"
                            },
                        },
                        "filters": [],
                    },
                    error=FileNameNotFoundException(
                        "filename not found for data attribute uuid."
                    ),
                    logs_directory="check_outputs",
                    dq_lib_logs_directory="check_outputs",
                ),
                call(
                    spark=spark_mock,
                    dbutils=dbutils_mock,
                    rule_id="1",
                    rule_json_dict={},
                    error=FileNotFoundException("file1", "csv"),
                    logs_directory="check_outputs",
                    dq_lib_logs_directory="check_outputs",
                ),
                call(
                    spark=spark_mock,
                    dbutils=dbutils_mock,
                    rule_id="2",
                    rule_json_dict={},
                    error=FileNotFoundException("file2", "json"),
                    logs_directory="check_outputs",
                    dq_lib_logs_directory="check_outputs",
                ),
            ]

            assert mock_log_check_output.called
            for index, (actual_call, expected_call) in enumerate(
                zip(mock_log_check_output.call_args_list, expected_call_list)
            ):
                assert actual_call.kwargs.keys() == expected_call.kwargs.keys(), (
                    f"Keys mismatch at call index {index}"
                )
                for key in actual_call.kwargs.keys():
                    actual_value = actual_call.kwargs[key]
                    expected_value = expected_call.kwargs[key]
                    assert actual_value == expected_value, (
                        f"Mismatch in {key} at call index {index}: {actual_value} != {expected_value}"
                    )

        finally:
            if hasattr(BaseException, "__eq__"):
                delattr(BaseException, "__eq__")
            for path in output_paths:
                if os.path.exists(path):
                    shutil.rmtree(path)


@pytest.mark.parametrize(
    "rule_name,parameters",
    [
        ("expect_column_values_to_be_greater_than_other_column", ["column_to_compare"]),
        ("expect_column_value_to_exist_in_reference_column", []),
    ],
)
def test_udf_get_parameters_functions(rule_name, parameters):
    result = get_parameters_combined(rule_name, reference=False)
    assert result == parameters


@pytest.mark.parametrize(
    "rule_name,parameters",
    [
        ("expect_column_value_to_exist_in_reference_column", []),
        ("expect_column_values_to_be_greater_than_other_column", []),
        (
            "expect_column_values_to_match_referenced_regex",
            ["reference_data_attribute_id", "reference_regex_attribute_id"],
        ),
    ],
)
def test_udf_get_reference_parameters_functions(rule_name, parameters):
    result = get_parameters_combined(rule_name, reference=True)
    assert result == parameters


@pytest.mark.parametrize(
    "value,expected_result",
    [
        ("test", "test"),
        (['["test", "other_value"]'], ["test", "other_value"]),
        ([], []),
        ([None], [None]),
    ],
)
def test_udf_parse_and_flatten_functions(value, expected_result):
    result = parse_and_flatten(value)
    assert result == expected_result
