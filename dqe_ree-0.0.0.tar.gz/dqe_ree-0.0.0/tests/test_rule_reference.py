from copy import deepcopy

import pytest
from pyspark.sql.functions import col

from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import (
    InvalidColumnDatatypeException,
    ParameterNotFoundException,
)

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "seq_number",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
    "bd5cce48-424e-4158-a046-c149625e5910": "is_male",
    "bd5cce48-424e-4158-a046-c149625e5911": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5912": "index_str",
    "bd5cce48-424e-4158-a046-c149625e5913": "index_str_test",
    "bd5cce48-424e-4158-a046-c149625e5914": "index_str_test2",
    "bd5cce48-424e-4158-a046-c149625e5915": "index_str_test_int",
    "bd5cce48-424e-4158-a046-c149625e5916": "dq_dataset_name",
    "bd5cce48-424e-4158-a046-c149625e5917": "column_name",
    "bd5cce48-424e-4158-a046-c149625e5918": "data_attribute_id",
    "bd5cce48-424e-4158-a046-c149625e5919": "data_attribute_id_int",
    "bd5cce48-424e-4158-a046-c149625e5920": "primary_key",
    "bd5cce48-424e-4158-a046-c149625e5921": "dq_dataset_name_ref",
    "bd5cce48-424e-4158-a046-c149625e5922": "column_name_ref",
    "bd5cce48-424e-4158-a046-c149625e5923": "data_attribute_id_ref",
    "bd5cce48-424e-4158-a046-c149625e5924": "data_attribute_id_int_ref",
    "bd5cce48-424e-4158-a046-c149625e5925": "primary_key_ref",
}


def get_latest_file(filename):
    return "tests/resources/ref_data.csv"


def get_latest_file_occurrences(filename):
    return "tests/resources/ref_data_occurrences.csv"


helper_functions = {"get_latest_file": get_latest_file}
helper_functions_occurrences = {"get_latest_file": get_latest_file_occurrences}


@pytest.fixture
def helper_functions_copy():
    return deepcopy(helper_functions)


@pytest.mark.usefixtures("data_frame", "spark_session", "metadata_df")
def test_reference_check(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5911"
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        data_frame,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions,
        metadata_table=metadata_df,
        testing=True,
    )
    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == data_frame.count()
    assert hits_count == 950
    assert passing_recs_count == 50
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()
    assert not [col_name for col_name in hits.columns if "_REFERENCE" in col_name]


@pytest.mark.usefixtures("data_frame", "spark_session", "metadata_df")
def test_on_wrong_datatype_col(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5911",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(InvalidColumnDatatypeException, match=r"Main Column datatype "):
        run_check(
            spark_session,
            data_frame,
            rule_json,
            att_colname_map,
            helper_func_dict=helper_functions,
            metadata_table=metadata_df,
            testing=True,
        )


@pytest.mark.usefixtures("data_frame", "spark_session", "metadata_df")
def test_on_string_int_datatype_col_comparison(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5912",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        data_frame,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions,
        metadata_table=metadata_df,
        testing=True,
    )
    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == data_frame.count()
    assert hits_count == 950
    assert passing_recs_count == 50
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("df_ref_test", "spark_session", "metadata_df")
def test_on_string_int_datatype_col_comparison_optional_parameter_string(
    df_ref_test, spark_session, metadata_df
):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5913",
                "comparison_type": "string",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5918",
                "data_attribute_source": "dsapp",
            },
        },
    }

    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        df_ref_test,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions,
        metadata_table=metadata_df,
        testing=True,
    )
    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == df_ref_test.count()
    assert hits_count == 5
    assert passing_recs_count == 4
    assert df_ref_test.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("df_ref_test", "spark_session", "metadata_df")
def test_on_string_int_datatype_col_comparison_optional_numeric(
    df_ref_test, spark_session, metadata_df
):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5915",
                "comparison_type": "numeric",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5919",
                "data_attribute_source": "dsapp",
            },
        },
    }

    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        df_ref_test,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions,
        metadata_table=metadata_df,
        testing=True,
    )
    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == df_ref_test.count()
    assert hits_count == 5
    assert passing_recs_count == 4
    assert df_ref_test.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("df_ref_test", "spark_session", "metadata_df")
def test_on_string_str_datatype_col_comparison_optional_numeric(
    df_ref_test, spark_session, metadata_df
):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5915",
                "comparison_type": "numeric",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5918",
                "data_attribute_source": "dsapp",
            },
        },
    }

    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        df_ref_test,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions,
        metadata_table=metadata_df,
        testing=True,
    )
    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == df_ref_test.count()
    assert hits_count == 5
    assert passing_recs_count == 4
    assert df_ref_test.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("df_ref_test", "spark_session", "metadata_df")
def test_on_string_str_datatype_col_comparison_optional_string(
    df_ref_test, spark_session, metadata_df
):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5913",
                "comparison_type": "string",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5918",
                "data_attribute_source": "dsapp",
            },
        },
    }

    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        df_ref_test,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions,
        metadata_table=metadata_df,
        testing=True,
    )
    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == df_ref_test.count()
    assert hits_count == 5
    assert passing_recs_count == 4
    assert df_ref_test.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures(
    "df_ref_decimal_test",
    "spark_session",
    "metadata_df",
    "df_ref_data_decimal",
    "helper_functions_copy",
)
def test_on_decimal_int_datatype_col_comparison_optional_numeric(
    df_ref_decimal_test,
    spark_session,
    metadata_df,
    df_ref_data_decimal,
    helper_functions_copy,
):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5940",
                "comparison_type": "numeric",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5935",
                "data_attribute_source": "dsapp",
            },
        },
    }
    helper_functions_copy["ref_df"] = df_ref_data_decimal

    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        df_ref_decimal_test,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions_copy,
        metadata_table=metadata_df,
        testing=True,
    )

    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == df_ref_decimal_test.count()
    assert hits_count == 1
    assert passing_recs_count == 4
    assert (
        df_ref_decimal_test.count() == out_of_scope_recs_count + filtered_recs.count()
    )


@pytest.mark.usefixtures(
    "df_ref_decimal_test",
    "spark_session",
    "metadata_df",
    "df_ref_data_decimal",
    "helper_functions_copy",
)
def test_on_decimal_str_datatype_col_comparison_optional_numeric(
    df_ref_decimal_test,
    spark_session,
    metadata_df,
    df_ref_data_decimal,
    helper_functions_copy,
):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5939",
                "comparison_type": "numeric",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5937",
                "data_attribute_source": "dsapp",
            },
        },
    }

    helper_functions_copy["ref_df"] = df_ref_data_decimal

    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        df_ref_decimal_test,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions_copy,
        metadata_table=metadata_df,
        testing=True,
    )

    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == df_ref_decimal_test.count()
    assert hits_count == 3
    assert passing_recs_count == 2
    assert (
        df_ref_decimal_test.count() == out_of_scope_recs_count + filtered_recs.count()
    )


@pytest.mark.usefixtures(
    "df_ref_decimal_test",
    "spark_session",
    "metadata_df",
    "df_ref_data_decimal",
    "helper_functions_copy",
)
def test_on_decimal_decimal_datatype_col_comparison_optional_numeric(
    df_ref_decimal_test,
    spark_session,
    metadata_df,
    df_ref_data_decimal,
    helper_functions_copy,
):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5939",
                "comparison_type": "numeric",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5935",
                "data_attribute_source": "dsapp",
            },
        },
    }

    helper_functions_copy["ref_df"] = df_ref_data_decimal

    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        df_ref_decimal_test,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions_copy,
        metadata_table=metadata_df,
        testing=True,
    )

    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == df_ref_decimal_test.count()
    assert hits_count == 1
    assert passing_recs_count == 4
    assert (
        df_ref_decimal_test.count() == out_of_scope_recs_count + filtered_recs.count()
    )


@pytest.mark.usefixtures(
    "df_ref_decimal_test",
    "spark_session",
    "metadata_df",
    "df_ref_data_decimal",
    "helper_functions_copy",
)
def test_on_decimal_decimal_precision_datatype_col_comparison_optional_numeric(
    df_ref_decimal_test,
    spark_session,
    metadata_df,
    df_ref_data_decimal,
    helper_functions_copy,
):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5939",
                "comparison_type": "numeric",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5936",
                "data_attribute_source": "dsapp",
            },
        },
    }

    helper_functions_copy["ref_df"] = df_ref_data_decimal

    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        df_ref_decimal_test,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions_copy,
        metadata_table=metadata_df,
        testing=True,
    )

    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_recs_count == df_ref_decimal_test.count()
    assert hits_count == 1
    assert passing_recs_count == 4
    assert (
        df_ref_decimal_test.count() == out_of_scope_recs_count + filtered_recs.count()
    )


@pytest.mark.usefixtures("data_frame", "spark_session", "metadata_df")
def test_on_wrong_comparision_type_input(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_value_to_exist_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5911",
                "comparison_type": "decimal",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(InvalidColumnDatatypeException, match=r"comparison_type"):
        run_check(
            spark_session,
            data_frame,
            rule_json,
            att_colname_map,
            helper_func_dict=helper_functions,
            metadata_table=metadata_df,
            testing=True,
        )


@pytest.mark.usefixtures("data_frame", "spark_session", "metadata_df")
def test_reference_occurrences_comparison_check(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_number_of_occurrences_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5911",
                "_dq_dataset": None,
                "occurrences": 1,
                "operator": "greater than or equal",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    data_frame = data_frame.select([col(c).cast("string") for c in data_frame.columns])
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        data_frame,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions_occurrences,
        metadata_table=metadata_df,
        testing=True,
    )

    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    assert hits_count + passing_recs_count == data_frame.count()
    assert hits_count == 956
    assert passing_recs_count == 44


@pytest.mark.usefixtures("data_frame", "spark_session", "metadata_df")
def test_reference_zero_occurrences(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_number_of_occurrences_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5911",
                "_dq_dataset": None,
                "occurrences": 0,
                "operator": "is",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    data_frame = data_frame.select([col(c).cast("string") for c in data_frame.columns])
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        data_frame,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions_occurrences,
        metadata_table=metadata_df,
        testing=True,
    )

    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    assert hits_count + passing_recs_count == data_frame.count()
    assert hits_count == 44
    assert passing_recs_count == 956


@pytest.mark.usefixtures("data_frame", "spark_session", "metadata_df")
def test_reference_less_than_3_occurrences(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_number_of_occurrences_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5911",
                "_dq_dataset": None,
                "occurrences": 3,
                "operator": "less than",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    data_frame = data_frame.select([col(c).cast("string") for c in data_frame.columns])
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session,
        data_frame,
        rule_json,
        att_colname_map,
        helper_func_dict=helper_functions_occurrences,
        metadata_table=metadata_df,
        testing=True,
    )

    hits_count = hits.count()
    passing_recs_count = passing_recs.count()
    assert hits_count + passing_recs_count == data_frame.count()
    assert hits_count == 2
    assert passing_recs_count == 998


@pytest.mark.usefixtures("data_frame", "spark_session", "metadata_df")
def test_operator_parameter_missing(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_number_of_occurrences_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5911",
                "_dq_dataset": None,
                "occurrences": 1,
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ParameterNotFoundException, match=r"Required parameter 'operator' not found."
    ):
        run_check(
            spark_session,
            data_frame,
            rule_json,
            att_colname_map,
            helper_func_dict=helper_functions_occurrences,
            metadata_table=metadata_df,
            testing=True,
        )


@pytest.mark.usefixtures("data_frame", "spark_session", "metadata_df")
def test_occurrences_parameter_missing(data_frame, spark_session, metadata_df):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_number_of_occurrences_in_reference_column",
            "parameters": {
                "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5911",
                "operator": "less than",
                "_dq_dataset": None,
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ParameterNotFoundException, match=r"Required parameter 'occurrences' not found."
    ):
        run_check(
            spark_session,
            data_frame,
            rule_json,
            att_colname_map,
            helper_func_dict=helper_functions_occurrences,
            metadata_table=metadata_df,
            testing=True,
        )
