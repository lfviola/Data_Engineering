import logging
from functools import partial
from dataclasses import dataclass
from unittest.mock import MagicMock, patch
import pytest

from dq_engine.export_dq_dataset_metadata import CreateDQDatasetMetadata
from dq_engine.rules.custom_exceptions import FileNotFoundException


@dataclass
class ConnectionDetails:
    name: str
    default_url: str
    container_name: str
    metadata_path: str


class DQE_Obj:
    def __init__(self) -> None:
        self.default_container_name = "dqe-data"


@pytest.mark.usefixtures("spark_session")
def target_dataframe(dataset_name, spark_session):
    filename_file_mapping = {
        "BONumberBasicDetailsHRDMPA": spark_session.read.options(header=True).csv(
            "tests/resources/dq_datasets/data/data_BONumberBasicDetailsHRDMPA.csv"
        ),
        "Charge": spark_session.read.options(header=True).csv(
            "tests/resources/dq_datasets/data/data_CHARGE.csv"
        ),
        "CreditAgreement": spark_session.read.options(header=True).csv(
            "tests/resources/dq_datasets/data/data_CreditAgreement.csv"
        ),
        "TestDataset": spark_session.read.options(header=True).csv(
            "tests/resources/dq_datasets/data/data_test.csv"
        ),
    }
    return filename_file_mapping[dataset_name]


def mock_get_latest_snapshot_file_path(file_name, *args, **kwargs):
    """
    Mocks the method `DatabricksHelperFunctions.get_latest_snapshot_file_path()` to
    retrieve desired path or error.
    """
    path_map = {
        "TestDataset": "dq_dataset_test",
    }
    return path_map[file_name]


@pytest.mark.usefixtures(
    "azure_handler",
    "att_id_att_uuid_file_id_map_dict",
)
def test_metadata_export(
    spark_session,
    azure_handler,
    att_id_att_uuid_file_id_map_dict,
):
    file_handlers = {"dqe-data": azure_handler}
    dqe_conn_obj = DQE_Obj()
    metadata_locations = [
        ConnectionDetails(
            name="dqe-data",
            default_url="",
            container_name="",
            metadata_path="dq_dataset_metadata",
        )
    ]

    databricks_helper = MagicMock()

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map=att_id_att_uuid_file_id_map_dict,
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    metadata_files = obj.read_metadata_files()
    assert len(metadata_files.keys()) == 3
    column_lengths = {
        "BONumberBasicDetailsHRDMPA": 25,
        "Charge": 24,
        "CreditAgreement": 26,
    }
    with patch(
        "dq_engine.export_dq_dataset_metadata.CreateDQDatasetMetadata.load_dq_dataset",
        side_effect=partial(target_dataframe, spark_session=spark_session),
    ):
        validated_metadata = obj.validate_metadata(metadata_files)
        metadata_json = obj.create_metadata_list(validated_metadata)

    for metadata in metadata_json:
        column_length = column_lengths.get(metadata["name"])
        assert column_length == len(metadata["columns"])
    assert len(metadata_files.keys()) == len(metadata_json)
    assert list(metadata_json[0]["columns"][0].keys()) == [
        "column_name",
        "uuid",
        "data_attribute_uuid",
        "flat_file_id",
        "data_attribute_id",
        "primary_key",
    ]

    obj.save_metadata(
        dqe_file_handler=azure_handler,
        json_data=metadata_json,
        dqe_obj=dqe_conn_obj,
        base_dict={"version": 1, "dq_datasets": []},
        update_key="dq_datasets",
    )


def test_hash_generation(spark_session):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={},
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )

    uuid = obj.return_id("test")
    assert str(uuid) == "098f6bcd4621d373cade4e832627b4f6"


@pytest.mark.parametrize(
    "input_value,output_value,error_message",
    [
        (("dataset_name", "column_1", "23923", True), 23923, None),
        (
            ("dataset_name", "column_1", "23924", True),
            None,
            "Incorrect metadata. Attribute identifier '23924' not found in metadata mapping for column 'column_1' in dataset 'dataset_name'.",
        ),
        (
            ("dataset_name", "column_2", "PRTY_NM", False),
            None,
            "Input should be a valid integer, unable to parse string as an integer",
        ),
        (
            ("dataset_name", "column_3", "", True),
            None,
            "Input should be a valid integer, unable to parse string as an integer",
        ),
    ],
)
def test_attribute_id_parsing(
    spark_session, caplog, input_value, output_value, error_message
):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={23923: ("correct_value", 123)},
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with caplog.at_level(logging.ERROR):
        try:
            outcome = obj.parse_metadata_row(
                input_value,
                [
                    "dq_dataset_name",
                    "column_name",
                    "data_attribute_id",
                    "primary_key",
                ],
                "dataset_name",
                "file_location",
            )
        except ValueError as e:
            if output_value is None:
                assert error_message in str(e)
            else:
                assert outcome["data_attribute_id"] == output_value


def test_incorrect_metadata_schema(spark_session, caplog):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={23923: ("correct_value", 123)},
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with caplog.at_level(logging.ERROR):
        try:
            obj.parse_metadata_row(
                (
                    "incorrect_dataset",
                    "column_1",
                    "23923",
                    True,
                    "some faulty unexpected column",
                ),
                [
                    "dq_dataset_name",
                    "column_name",
                    "data_attribute_id",
                    "primary_key",
                    "incorrect_column",
                ],
                "dataset_name",
                "file_location",
            )
        except ValueError as e:
            assert (
                "Incorrect metadata. Validation error in file 'file_location' for row '('incorrect_dataset', 'column_1', '23923', True, 'some faulty unexpected column')'"
                in str(e)
            )


def test_incorrect_metadata_primary_key(spark_session, caplog):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={23923: ("correct_value", 123)},
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with caplog.at_level(logging.ERROR):
        try:
            obj.parse_metadata_row(
                (
                    "incorrect_dataset",
                    "column_1",
                    "23923",
                    "This is a primary key",
                ),
                [
                    "dq_dataset_name",
                    "column_name",
                    "data_attribute_id",
                    "primary_key",
                ],
                "dataset_name",
                "file_location",
            )
        except ValueError as e:
            assert (
                "Incorrect metadata. Primary key must be either 'yes' or 'no'."
                in str(e)
            )


def test_correct_metadata_column_name(spark_session, caplog):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={23923: ("correct_value", 123)},
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with caplog.at_level(logging.ERROR):
        result = obj.parse_metadata_row(
            (
                "incorrect_dataset",
                "column_1 ",
                "23923",
                "yes",
            ),
            [
                "dq_dataset_name",
                "column_name",
                "data_attribute_id",
                "primary_key",
            ],
            "dataset_name",
            "file_location",
        )
        assert result["column_name"] == "column_1"


def test_incorrect_metadata_column_name(spark_session, caplog):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={23923: ("correct_value", 123)},
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with caplog.at_level(logging.ERROR):
        try:
            obj.parse_metadata_row(
                (
                    "incorrect_dataset",
                    "column 1",
                    "23923",
                    "yes",
                ),
                [
                    "dq_dataset_name",
                    "column_name",
                    "data_attribute_id",
                    "primary_key",
                ],
                "dataset_name",
                "file_location",
            )
        except ValueError as e:
            assert "Incorrect metadata. Column name must not contain spaces." in str(e)


def test_incorrect_metadata_no_primary_keys(spark_session, caplog):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    csv_content = (
        "dq_dataset_name|column_name|data_attribute_id|primary_key\n"
        "TestDataset|column1|23923|no\n"
        "TestDataset|column2|23924|no"
    )
    # Encode the content to bytes, as expected by csv_data.
    fake_file_bytes = csv_content.encode()

    # Build a dict mimicking the metadata_file_data_dict with one file.
    metadata_files = {"fake_file.csv": fake_file_bytes}

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={
            23923: ("correct_value", 123),
            23924: ("also_correct_value", 124),
        },
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with caplog.at_level(logging.ERROR):
        validated_metadata = obj.validate_metadata(metadata_files)
        metadata_json = obj.create_metadata_list(validated_metadata)
    assert (
        "Incorrect metadata. No primary key flagged as true for dataset 'TestDataset'."
        in caplog.text
    )
    assert len(metadata_json) == 0


def test_incorrect_metadata_primary_keys_on_different_flat_file(spark_session, caplog):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    csv_content = (
        "dq_dataset_name|column_name|data_attribute_id|primary_key\n"
        "TestDataset|column1|23923|yes\n"
        "TestDataset|column2|23924|yes"
    )
    # Encode the content to bytes, as expected by csv_data.
    fake_file_bytes = csv_content.encode()

    # Build a dict mimicking the metadata_file_data_dict with one file.
    metadata_files = {"fake_file.csv": fake_file_bytes}

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={
            23923: ("correct_value", 123),
            23924: ("also_correct_value", 124),
        },
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with caplog.at_level(logging.ERROR):
        validated_metadata = obj.validate_metadata(metadata_files)
        metadata_json = obj.create_metadata_list(validated_metadata)
    assert (
        "Incorrect metadata. Not all primary keys in dataset 'TestDataset' are defined on the same flat file"
        in caplog.text
    )
    assert len(metadata_json) == 0


def test_incorrect_metadata_duplicate_columns_equal(spark_session, caplog):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    databricks_helper.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    csv_content = (
        "dq_dataset_name|column_name|data_attribute_id|primary_key\n"
        "TestDataset|column1|23923|yes\n"
        "TestDataset|column1|23923|yes\n"
        "TestDataset|column2|23924|no\n"
    )
    # Encode the content to bytes, as expected by csv_data.
    fake_file_bytes = csv_content.encode()

    # Build a dict mimicking the metadata_file_data_dict with one file.
    metadata_files = {"fake_file.csv": fake_file_bytes}

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={
            23923: ("correct_value", 123),
            23924: ("also_correct_value", 124),
        },
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with (
        caplog.at_level(logging.WARNING),
        patch(
            "dq_engine.export_dq_dataset_metadata.CreateDQDatasetMetadata.load_dq_dataset",
            side_effect=partial(target_dataframe, spark_session=spark_session),
        ),
    ):
        validated_metadata = obj.validate_metadata(metadata_files)
        metadata_json = obj.create_metadata_list(validated_metadata)
    assert (
        "Metadata in dataset 'TestDataset' contains duplicate column 'column1' that is exactly the same. Keeping one instance."
        in caplog.text
    )
    assert len(metadata_json) == 1
    assert len(metadata_json[0]["columns"]) == 2


def test_incorrect_metadata_duplicate_columns_not_equal(spark_session, caplog):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    databricks_helper.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    csv_content = (
        "dq_dataset_name|column_name|data_attribute_id|primary_key\n"
        "TestDataset|column1|23923|yes\n"
        "TestDataset|column1|23924|no\n"
        "TestDataset|column2|23924|no\n"
    )
    # Encode the content to bytes, as expected by csv_data.
    fake_file_bytes = csv_content.encode()

    # Build a dict mimicking the metadata_file_data_dict with one file.
    metadata_files = {"fake_file.csv": fake_file_bytes}

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={
            23923: ("correct_value", 123),
            23924: ("also_correct_value", 124),
        },
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with (
        caplog.at_level(logging.WARNING),
        patch(
            "dq_engine.export_dq_dataset_metadata.CreateDQDatasetMetadata.load_dq_dataset",
            side_effect=partial(target_dataframe, spark_session=spark_session),
        ),
    ):
        validated_metadata = obj.validate_metadata(metadata_files)
        metadata_json = obj.create_metadata_list(validated_metadata)
    assert (
        "Incorrect metadata. Metadata in dataset 'TestDataset' contains duplicate column name 'column1' with conflicting definitions. Ignoring all duplicates."
        in caplog.text
    )
    assert (
        "Warning. Metadata and physical data for dataset 'TestDataset' are not consistent. The following columns are defined in the data but are not present in the metadata: ['COLUMN1'], maybe they are forgotten."
        in caplog.text
    )
    assert len(metadata_json) == 1
    assert len(metadata_json[0]["columns"]) == 1


def test_metadata_not_consistent_with_data(spark_session, caplog):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    databricks_helper.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    csv_content = (
        "dq_dataset_name|column_name|data_attribute_id|primary_key\n"
        "TestDataset|column1|23923|yes\n"
        "TestDataset|column2|23924|no\n"
        "TestDataset|column3|23924|no\n"
    )
    # Encode the content to bytes, as expected by csv_data.
    fake_file_bytes = csv_content.encode()

    # Build a dict mimicking the metadata_file_data_dict with one file.
    metadata_files = {"fake_file.csv": fake_file_bytes}

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={
            23923: ("correct_value", 123),
            23924: ("also_correct_value", 124),
        },
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with (
        caplog.at_level(logging.ERROR),
        patch(
            "dq_engine.export_dq_dataset_metadata.CreateDQDatasetMetadata.load_dq_dataset",
            side_effect=partial(target_dataframe, spark_session=spark_session),
        ),
    ):
        validated_metadata = obj.validate_metadata(metadata_files)
        metadata_json = obj.create_metadata_list(validated_metadata)
    assert (
        "Invalid metadata. Metadata and physical data for dataset 'TestDataset' are not consistent. The following columns are defined in the metadata but are not present in the data: ['COLUMN3']"
        in caplog.text
    )
    assert len(metadata_json) == 1
    assert len(metadata_json[0]["columns"]) == 2


def test_metadata_data_not_present(spark_session, caplog):
    metadata_locations = MagicMock()
    file_handlers = MagicMock()
    databricks_helper = MagicMock()

    databricks_helper.get_latest_snapshot_file_path.side_effect = (
        mock_get_latest_snapshot_file_path
    )

    csv_content = (
        "dq_dataset_name|column_name|data_attribute_id|primary_key\n"
        "TestDataset|column1|23923|yes\n"
        "TestDataset|column2|23924|no\n"
        "TestDataset|column3|23924|no\n"
    )
    # Encode the content to bytes, as expected by csv_data.
    fake_file_bytes = csv_content.encode()

    # Build a dict mimicking the metadata_file_data_dict with one file.
    metadata_files = {"fake_file.csv": fake_file_bytes}

    obj = CreateDQDatasetMetadata(
        metadata_folder_locations=metadata_locations,
        output_location="",
        azure_file_handlers=file_handlers,
        att_id_att_uuid_file_id_map={
            23923: ("correct_value", 123),
            23924: ("also_correct_value", 124),
        },
        databricks_helpers=databricks_helper,
        spark=spark_session,
    )
    with (
        caplog.at_level(logging.ERROR),
        patch(
            "dq_engine.export_dq_dataset_metadata.CreateDQDatasetMetadata.load_dq_dataset",
            side_effect=FileNotFoundException("file_name", "file_type"),
        ),
    ):
        validated_metadata = obj.validate_metadata(metadata_files)
        metadata_json = obj.create_metadata_list(validated_metadata)
    assert len(metadata_json) == 1
    assert len(metadata_json[0]["columns"]) == 3
    assert "Warning. Physical data does not exist. We will not check consistency as it is assumed this is a new dataset."
