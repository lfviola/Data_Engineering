from dq_engine.lib import rule_json_export
from dq_engine.rules.rule import Rule, ParameterDefinition
from unittest.mock import patch


class RuleTest(Rule):
    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="test attribute",
                functional_name="Test Attribute",
                description="Some test description",
                value_type="data-attribute",
                logical_type="array",
                required=False,
                is_reference_data_attribute=False,
            ),
            ParameterDefinition(
                technical_name="test value",
                functional_name="Test Value",
                description="Some test description",
                value_type="string",
                logical_type="value",
                required=True,
            ),
            ParameterDefinition(
                technical_name="test value 2",
                functional_name="Test Value 2",
                description="Some test description",
                value_type="string",
                logical_type="value",
                required=True,
                enum_values=["Option 1", "Option 2"],
            ),
            ParameterDefinition(
                technical_name="test boolean",
                functional_name="Test Boolean",
                description="Some test description",
                value_type="boolean",
                logical_type="value",
                required=False,
                enum_values=[True, False],
            ),
        ]


test_rule_json = [
    {
        "id": None,
        "name": None,
        "description": None,
        "technical_name": "RuleTest",
        "subdimension": None,
        "scope": "both",
        "parameters": [
            {
                "name": "Test Attribute",
                "description": "Some test description",
                "technical_name": "test attribute",
                "value_type": "data-attribute",
                "logical_type": "array",
                "required": False,
                "is_reference_data_attribute": False,
            },
            {
                "name": "Test Value",
                "description": "Some test description",
                "technical_name": "test value",
                "value_type": "string",
                "logical_type": "value",
                "required": True,
            },
            {
                "name": "Test Value 2",
                "description": "Some test description",
                "technical_name": "test value 2",
                "value_type": "string",
                "logical_type": "value",
                "required": True,
                "enum_values": ["Option 1", "Option 2"],
            },
            {
                "name": "Test Boolean",
                "description": "Some test description",
                "technical_name": "test boolean",
                "value_type": "boolean",
                "logical_type": "value",
                "required": False,
                "enum_values": [True, False],
            },
        ],
    }
]


def test_rule_json_export():
    with patch("dq_engine.lib.get_all_rules") as mock_get_all_rules:
        mock_get_all_rules.return_value = [RuleTest]
        rule_json = rule_json_export()

    assert len(rule_json) == 1
    assert rule_json == test_rule_json


def test_automatable_in_rule_name():
    for rule in rule_json_export():
        assert "(automatable)" in rule["name"]
