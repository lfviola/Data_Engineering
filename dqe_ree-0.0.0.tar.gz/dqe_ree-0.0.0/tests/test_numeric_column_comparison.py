import pytest

from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import (
    AttributeIDNotFoundException,
    ParameterNotFoundException,
)

att_colname = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "year",
    "bd5cce48-424e-4158-a046-c149625e5903": "value",
    "bd5cce48-424e-4158-a046-c149625e5904": "value_as_string_with_decimal",
    "bd5cce48-424e-4158-a046-c149625e5905": "value_with_decimal",
    "bd5cce48-424e-4158-a046-c149625e5906": "comparison_column",
}


class TestColumnValuesToBeGreaterThanOtherColumnRule:
    rule_name = "expect_column_values_to_be_greater_than_other_column"

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_on_string_and_numeric_columns(self, decimal_df_2, spark_session):
        decimal_df_2 = decimal_df_2.withColumn(
            "value_as_string_with_decimal",
            decimal_df_2["value_as_string_with_decimal"].cast("string"),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5904"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError,
            match=f"Column {att_colname['bd5cce48-424e-4158-a046-c149625e5904'].upper()} is not a number",
        ):
            run_check(spark_session, decimal_df_2, rule_json, att_colname)

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_wrong_parameter(self, decimal_df_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_comre": "bd5cce48-424e-4158-a046-c149625e5904"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'column_to_compare' not found.",
        ):
            run_check(spark_session, decimal_df_2, rule_json, att_colname)

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_on_numeric_columns_same_type(self, decimal_df_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5906"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df_2, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df_2.count()
        assert passing_count == 5
        assert hits_count == 15
        assert decimal_df_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_on_numeric_columns_different_type(self, decimal_df_2, spark_session):
        decimal_df_2 = decimal_df_2.withColumn(
            "value_with_decimal", decimal_df_2["value_with_decimal"].cast("int")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5906"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df_2, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df_2.count()
        assert passing_count == 5
        assert hits_count == 15
        assert decimal_df_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_with_wrong_att_id(self, decimal_df_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5907"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            AttributeIDNotFoundException,
            match="attribute bd5cce48-424e-4158-a046-c149625e5907 could not be mapped to a column name on the dataset",
        ):
            run_check(spark_session, decimal_df_2, rule_json, att_colname)


class TestColumnValuesToBeEqualOrGreaterThanOtherColumnRule:
    rule_name = "expect_column_values_to_be_equal_or_greater_than_other_column"

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_on_numeric_columns_same_type(self, decimal_df_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5906"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df_2, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df_2.count()
        assert passing_count == 13
        assert hits_count == 7
        assert decimal_df_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_on_numeric_columns_different_type(self, decimal_df_2, spark_session):
        decimal_df_2 = decimal_df_2.withColumn(
            "value_with_decimal", decimal_df_2["value_with_decimal"].cast("int")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5906"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df_2, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df_2.count()
        assert passing_count == 5
        assert hits_count == 15
        assert decimal_df_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_with_wrong_att_id(self, decimal_df_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5908"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            AttributeIDNotFoundException,
            match="attribute bd5cce48-424e-4158-a046-c149625e5908 could not be mapped to a column name on the dataset",
        ):
            run_check(spark_session, decimal_df_2, rule_json, att_colname)


class TestColumnValuesToBeLessThanOtherColumn:
    rule_name = "expect_column_values_to_be_less_than_other_column"

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_on_numeric_columns_same_type(self, decimal_df_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5906"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df_2, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df_2.count()
        assert passing_count == 3
        assert hits_count == 17
        assert decimal_df_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_on_numeric_columns_different_type(self, decimal_df_2, spark_session):
        decimal_df_2 = decimal_df_2.withColumn(
            "value_with_decimal", decimal_df_2["value_with_decimal"].cast("int")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5906"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df_2, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df_2.count()
        assert passing_count == 11
        assert hits_count == 9
        assert decimal_df_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_with_wrong_att_id(self, decimal_df_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5909"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            AttributeIDNotFoundException,
            match="attribute bd5cce48-424e-4158-a046-c149625e5909 could not be mapped to a column name on the dataset",
        ):
            run_check(spark_session, decimal_df_2, rule_json, att_colname)


class TestColumnValuesToBeEqualOrLessThanOtherColumn:
    rule_name = "expect_column_values_to_be_equal_or_less_than_other_column"

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_on_numeric_columns_same_type(self, decimal_df_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5906"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df_2, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df_2.count()
        assert passing_count == 11
        assert hits_count == 9
        assert decimal_df_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_on_numeric_columns_different_type(self, decimal_df_2, spark_session):
        decimal_df_2 = decimal_df_2.withColumn(
            "value_with_decimal", decimal_df_2["value_with_decimal"].cast("int")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5906"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, decimal_df_2, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == decimal_df_2.count()
        assert passing_count == 11
        assert hits_count == 9
        assert decimal_df_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("decimal_df_2", "spark_session")
    def test_with_wrong_att_id(self, decimal_df_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            AttributeIDNotFoundException,
            match="attribute bd5cce48-424e-4158-a046-c149625e5910 could not be mapped to a column name on the dataset",
        ):
            run_check(spark_session, decimal_df_2, rule_json, att_colname)
