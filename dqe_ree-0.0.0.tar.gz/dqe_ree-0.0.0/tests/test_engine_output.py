import datetime
import json
import os
import re
import tempfile
from pathlib import Path
from typing import BinaryIO, Dict
from unittest.mock import MagicMock, patch

import pandas as pd
import pyspark.sql.functions as F
import pytest
from pandas.testing import assert_frame_equal
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import DecimalType, FloatType, IntegerType, StringType

from dq_engine.lib import create_pk_data, output_dqsm, run_check
from dq_engine.output_generation import (
    _prepare_counts_df,
    _prepare_pk_scope_df,
    _prepare_records_sample_df,
    get_pk_scope_data,
    write_uat_files,
)
from dq_engine.rules.custom_exceptions import (
    DataAttributeNotFoundValidationException,
    PrimaryKeyColumnNotFoundException,
    get_error_json,
)
from dq_engine.utils.check_output import log_check_output

summary_columns = [
    "dq_check_id",
    "dq_check_scope_number_of_records",
    "dq_check_hit_number_of_records",
    "snapshotdate",
    "dq_execution_date",
    "generated_date",
    "generated_by",
    "data_attribute_id",
    "check_version",
]

outcome_columns = [
    "dq_check_id",
    "data_attribute_id",
    "dq_execution_date",
    "generated_by",
    "generated_date",
    "snapshotdate",
    "primary_key",
    "business_key",
    "dq_check_attributes",
    "outcome_details",
]


@pytest.mark.usefixtures(
    "dial_metadata_df",
)
def test_create_pk_data_dial(
    dial_metadata_df,
) -> None:
    file_name = "dial_df"
    file_type = "dsapp"

    pk_dict = create_pk_data(file_name, file_type, dial_metadata_df)
    assert len(pk_dict) == 2
    assert pk_dict["ID"] == 131
    assert pk_dict["USER_ID"] == 132


@pytest.mark.usefixtures(
    "dq_dataset_metadata_df",
)
def test_create_pk_data_dq_dataset(
    dq_dataset_metadata_df,
) -> None:
    file_name = "dq_dataset_df"
    file_type = "dq_dataset"

    pk_dict = create_pk_data(file_name, file_type, dq_dataset_metadata_df)
    assert len(pk_dict) == 2
    assert pk_dict["ID"] == 123
    assert pk_dict["USER_ID"] == 124


@pytest.mark.usefixtures(
    "dq_dataset_metadata_df",
)
def test_create_pk_undefined_file_type(
    dq_dataset_metadata_df,
) -> None:
    file_name = "dq_dataset_df"
    file_type = "dq"

    with pytest.raises(ValueError, match="File type is not valid"):
        create_pk_data(
            file_name,
            file_type,
            dq_dataset_metadata_df,
        )


@pytest.mark.usefixtures(
    "spark_session",
    "dq_checks_json_fixture",
    "dq_dataset_metadata_df",
    "dq_dataset_df",
    "dial_metadata_df",
)
def test_dq_dataset_output(
    spark_session,
    dq_checks_json_fixture,
    dq_dataset_metadata_df,
    dq_dataset_df,
    dial_metadata_df,
) -> None:
    """
    Tests the DQ engine output for signal format, running checks over a
    DQ dataset.
    """
    dq_dataset_df = dq_dataset_df.toDF(*[c.upper() for c in dq_dataset_df.columns])
    att_colname_map = {
        row.data_attribute_uuid: row.column_name.upper()
        for row in dq_dataset_metadata_df.collect()
    }
    file_name = "dq_dataset_df"
    file_type = "dq_dataset"
    output_ = dq_dataset_df.limit(0)
    for check in dq_checks_json_fixture:
        rule_output_cd = -1
        df_hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dq_dataset_df, check, att_colname_map
        )
        dq_check_hit_number_of_records = df_hits.count()
        dq_check_number_of_records = filtered_recs.count()
        snapshot_date_time = "2023-15-01"
        column_name = att_colname_map[
            check["rule"]["data_attribute"]["data_attribute_uuid"]
        ]
        if dq_check_hit_number_of_records == 0:
            df_hits = spark_session.createDataFrame(
                data=[tuple([None] * len(df_hits.columns))], schema=df_hits.schema
            )
            rule_output_cd = 0
        df_hits = (
            df_hits.withColumn(
                "rule_technical_name", F.lit(check["rule"]["technical_name"])
            )
            .withColumn("check_id_dq", F.lit(check["dq_check_id"]))
            .withColumn(
                "dq_check_scope_number_of_records", F.lit(dq_check_number_of_records)
            )
            .withColumn(
                "dq_check_hit_number_of_records", F.lit(dq_check_hit_number_of_records)
            )
            .withColumn("snapshotdate", F.lit(snapshot_date_time))
            .withColumn("dq_execution_date", F.current_timestamp())
            .withColumn("generated_date", F.current_timestamp())
            .withColumn("generated_by", F.lit("unit testing"))
            .withColumn("rule_output_cd", F.lit(rule_output_cd))
            .withColumn(
                "data_attribute_uuid",
                F.lit(check["rule"]["data_attribute"]["data_attribute_uuid"]),
            )
            .withColumn("dq_check_attr_value", df_hits[column_name])
            .withColumn(
                "_check_version", F.lit(check["check_version"]).cast(IntegerType())
            )
        )
        output_ = output_.unionByName(df_hits, allowMissingColumns=True)

    output_ = (
        output_.withColumnRenamed("check_id_dq", "_check_id_dq")
        .withColumnRenamed("rule_technical_name", "_rule_technical_name")
        .withColumnRenamed(
            "dq_check_scope_number_of_records", "_dq_check_scope_number_of_records"
        )
        .withColumnRenamed(
            "dq_check_hit_number_of_records", "_dq_check_hit_number_of_records"
        )
        .withColumnRenamed("snapshotdate", "_snapshotdate")
        .withColumnRenamed("dq_execution_date", "_dq_execution_date")
        .withColumnRenamed("generated_date", "_generated_date")
        .withColumnRenamed("generated_by", "_generated_by")
        .withColumnRenamed("rule_output_cd", "_rule_output_cd")
        .withColumnRenamed("data_attribute_uuid", "_data_attribute_uuid")
        .withColumnRenamed("dq_check_attr_value", "_dq_check_attr_value")
    )

    pk_dict = create_pk_data(file_name, file_type, dq_dataset_metadata_df)
    check_status = [
        "12-90ab-cdef-1234-567890abcdef",
        "123-90ab-1234-567890abcdef",
        "1234-90ab-1234-567890abcdef1",
        "12345-90ab-cdef-1234-567890abcdef2",
        "123456-90ab-cdef-1234-567890abcdef2",
        "1234567-90ab-cdef-1234-567890abcdef3",
    ]
    df_chk_summary_out, df_chk_details_out = output_dqsm(
        output_, pk_dict, check_status, dial_metadata_df
    )
    assert len(df_chk_summary_out.columns) == 9
    assert sorted(df_chk_summary_out.columns) == sorted(summary_columns)
    assert df_chk_summary_out.count() == 6
    assert df_chk_summary_out.filter("data_attribute_id is NULL").count() == 0
    assert df_chk_summary_out.filter("dq_check_id is NULL").count() == 0
    assert df_chk_summary_out.filter("dq_execution_date is NULL").count() == 0
    assert df_chk_summary_out.filter("generated_by is NULL").count() == 0
    assert df_chk_summary_out.filter("generated_date is NULL").count() == 0
    assert df_chk_summary_out.filter("snapshotdate is NULL").count() == 0
    assert (
        df_chk_summary_out.filter("dq_check_hit_number_of_records is NULL").count() == 0
    )
    assert (
        df_chk_summary_out.filter("dq_check_scope_number_of_records is NULL").count()
        == 0
    )
    assert df_chk_details_out.count() == 12
    assert len(df_chk_details_out.columns) == 10
    assert sorted(df_chk_details_out.columns) == sorted(outcome_columns)
    assert df_chk_details_out.filter("data_attribute_id is NULL").count() == 0
    assert df_chk_details_out.filter("dq_check_attributes is NULL").count() == 0
    assert df_chk_details_out.filter("dq_check_id is NULL").count() == 0
    assert df_chk_details_out.filter("dq_execution_date is NULL").count() == 0
    assert df_chk_details_out.filter("generated_by is NULL").count() == 0
    assert df_chk_details_out.filter("generated_date is NULL").count() == 0
    assert df_chk_details_out.filter("primary_key is NULL").count() == 0
    assert df_chk_details_out.filter("snapshotdate is NULL").count() == 0


@pytest.mark.usefixtures(
    "spark_session",
    "dq_dataset_metadata_df",
    "dq_dataset_df",
    "dq_checks_dial_json_fixture",
    "dial_metadata_df",
)
def test_dial_df_output(
    spark_session,
    dq_dataset_metadata_df,
    dq_dataset_df,
    dq_checks_dial_json_fixture,
    dial_metadata_df,
) -> None:
    """
    Tests the DQ engine output for signal format, running checks over a
    DIAL dataset.
    """
    dq_dataset_df = dq_dataset_df.toDF(*[c.upper() for c in dq_dataset_df.columns])
    att_colname_map = {
        row.data_attribute_uuid: row.column_name.upper()
        for row in dq_dataset_metadata_df.collect()
    }
    file_name = "dial_df"
    file_type = "dsapp"
    output_ = dq_dataset_df.limit(0)
    for check in dq_checks_dial_json_fixture:
        rule_output_cd = -1
        df_hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dq_dataset_df, check, att_colname_map
        )
        dq_check_hit_number_of_records = df_hits.count()
        dq_check_number_of_records = filtered_recs.count()
        snapshot_date_time = "2023-15-01"
        column_name = att_colname_map[
            check["rule"]["data_attribute"]["data_attribute_uuid"]
        ]
        if dq_check_hit_number_of_records == 0:
            df_hits = spark_session.createDataFrame(
                data=[tuple([None] * len(df_hits.columns))], schema=df_hits.schema
            )
            rule_output_cd = 0
        decimal_type = isinstance(df_hits.schema[column_name].dataType, DecimalType)
        df_hits = (
            df_hits.withColumn(
                "rule_technical_name", F.lit(check["rule"]["technical_name"])
            )
            .withColumn("check_id_dq", F.lit(check["dq_check_id"]))
            .withColumn(
                "dq_check_scope_number_of_records", F.lit(dq_check_number_of_records)
            )
            .withColumn(
                "dq_check_hit_number_of_records", F.lit(dq_check_hit_number_of_records)
            )
            .withColumn("snapshotdate", F.lit(snapshot_date_time))
            .withColumn("dq_execution_date", F.current_timestamp())
            .withColumn("generated_date", F.current_timestamp())
            .withColumn("generated_by", F.lit("unit testing"))
            .withColumn("rule_output_cd", F.lit(rule_output_cd))
            .withColumn(
                "data_attribute_uuid",
                F.lit(check["rule"]["data_attribute"]["data_attribute_uuid"]),
            )
            .withColumn(
                "dq_check_attr_value",
                df_hits[column_name].cast(StringType())
                if not decimal_type
                else df_hits[column_name].cast(FloatType()),
            )
            .withColumn(
                "_check_version", F.lit(check["check_version"]).cast(IntegerType())
            )
        )
        output_ = output_.unionByName(df_hits, allowMissingColumns=True)

    output_ = (
        output_.withColumnRenamed("check_id_dq", "_check_id_dq")
        .withColumnRenamed("rule_technical_name", "_rule_technical_name")
        .withColumnRenamed(
            "dq_check_scope_number_of_records", "_dq_check_scope_number_of_records"
        )
        .withColumnRenamed(
            "dq_check_hit_number_of_records", "_dq_check_hit_number_of_records"
        )
        .withColumnRenamed("snapshotdate", "_snapshotdate")
        .withColumnRenamed("dq_execution_date", "_dq_execution_date")
        .withColumnRenamed("generated_date", "_generated_date")
        .withColumnRenamed("generated_by", "_generated_by")
        .withColumnRenamed("rule_output_cd", "_rule_output_cd")
        .withColumnRenamed("data_attribute_uuid", "_data_attribute_uuid")
        .withColumnRenamed("dq_check_attr_value", "_dq_check_attr_value")
    )

    pk_dict = create_pk_data(file_name, file_type, dial_metadata_df)
    check_status_id = [
        "128901234-90ab-cdef-1234-567890abcdef",
        "12345678910-90ab-cdef-1234-567890abcdef3",
        "12345678910-90ab-cdef-1234-567890KLTERYUOPUUV",
    ]

    df_chk_summary_out, df_chk_details_out = output_dqsm(
        output_, pk_dict, check_status_id, dial_metadata_df
    )
    check_attribute_value = [
        [attribute.dq_check_attr_value for attribute in row.dq_check_attributes]
        for row in df_chk_details_out.select("dq_check_attributes")
        .filter(
            df_chk_details_out["dq_check_id"]
            == "12345678910-90ab-cdef-1234-567890KLTERYUOPUUV"
        )
        .collect()
    ]
    assert df_chk_summary_out.count() == 5
    assert len(df_chk_summary_out.columns) == 9
    assert sorted(df_chk_summary_out.columns) == sorted(summary_columns)
    assert df_chk_summary_out.filter("data_attribute_id is NULL").count() == 0
    assert df_chk_summary_out.filter("dq_check_id is NULL").count() == 0
    assert df_chk_summary_out.filter("dq_execution_date is NULL").count() == 0
    assert df_chk_summary_out.filter("generated_by is NULL").count() == 0
    assert df_chk_summary_out.filter("generated_date is NULL").count() == 0
    assert df_chk_summary_out.filter("snapshotdate is NULL").count() == 0
    assert (
        df_chk_summary_out.filter("dq_check_hit_number_of_records is NULL").count() == 0
    )
    assert (
        df_chk_summary_out.filter("dq_check_scope_number_of_records is NULL").count()
        == 0
    )

    assert df_chk_details_out.count() == 8
    assert len(df_chk_details_out.columns) == 10
    assert sorted(df_chk_details_out.columns) == sorted(outcome_columns)
    assert df_chk_details_out.filter("data_attribute_id is NULL").count() == 0
    assert df_chk_details_out.filter("dq_check_attributes is NULL").count() == 0
    assert df_chk_details_out.filter("dq_check_id is NULL").count() == 0
    assert df_chk_details_out.filter("dq_execution_date is NULL").count() == 0
    assert df_chk_details_out.filter("generated_by is NULL").count() == 0
    assert df_chk_details_out.filter("generated_date is NULL").count() == 0
    assert df_chk_details_out.filter("primary_key is NULL").count() == 0
    assert df_chk_details_out.filter("snapshotdate is NULL").count() == 0
    assert "0E-15" not in set([val[0] for val in check_attribute_value])


@pytest.mark.usefixtures(
    "spark_session",
    "dq_dataset_metadata_df",
    "dq_dataset_df",
    "dq_checks_dial_json_fixture",
    "dial_metadata_df",
)
def test_output_when_pk_not_present(
    spark_session,
    dq_dataset_metadata_df,
    dq_dataset_df,
    dq_checks_dial_json_fixture,
    dial_metadata_df,
) -> None:
    dq_dataset_df = dq_dataset_df.toDF(*[c.upper() for c in dq_dataset_df.columns])
    att_colname_map = {
        row.data_attribute_uuid: row.column_name.upper()
        for row in dq_dataset_metadata_df.collect()
    }
    output_ = dq_dataset_df.limit(0)
    for check in dq_checks_dial_json_fixture:
        rule_output_cd = -1
        df_hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dq_dataset_df, check, att_colname_map
        )
        dq_check_hit_number_of_records = df_hits.count()
        dq_check_number_of_records = filtered_recs.count()
        snapshot_date_time = "2023-15-01"
        column_name = att_colname_map[
            check["rule"]["data_attribute"]["data_attribute_uuid"]
        ]
        if dq_check_hit_number_of_records == 0:
            df_hits = spark_session.createDataFrame(
                data=[tuple([None] * len(df_hits.columns))], schema=df_hits.schema
            )
            rule_output_cd = 0
        df_hits = (
            df_hits.withColumn(
                "rule_technical_name", F.lit(check["rule"]["technical_name"])
            )
            .withColumn("check_id_dq", F.lit(check["dq_check_id"]))
            .withColumn(
                "dq_check_scope_number_of_records", F.lit(dq_check_number_of_records)
            )
            .withColumn(
                "dq_check_hit_number_of_records", F.lit(dq_check_hit_number_of_records)
            )
            .withColumn("snapshotdate", F.lit(snapshot_date_time))
            .withColumn("dq_execution_date", F.current_timestamp())
            .withColumn("generated_date", F.current_timestamp())
            .withColumn("generated_by", F.lit("unit testing"))
            .withColumn("rule_output_cd", F.lit(rule_output_cd))
            .withColumn(
                "data_attribute_uuid",
                F.lit(check["rule"]["data_attribute"]["data_attribute_uuid"]),
            )
            .withColumn("dq_check_attr_value", df_hits[column_name])
            .withColumn(
                "_check_version", F.lit(check["check_version"]).cast(IntegerType())
            )
        )

        output_ = output_.unionByName(df_hits, allowMissingColumns=True)

    output_ = (
        output_.withColumnRenamed("check_id_dq", "_check_id_dq")
        .withColumnRenamed("rule_technical_name", "_rule_technical_name")
        .withColumnRenamed(
            "dq_check_scope_number_of_records", "_dq_check_scope_number_of_records"
        )
        .withColumnRenamed(
            "dq_check_hit_number_of_records", "_dq_check_hit_number_of_records"
        )
        .withColumnRenamed("snapshotdate", "_snapshotdate")
        .withColumnRenamed("dq_execution_date", "_dq_execution_date")
        .withColumnRenamed("generated_date", "_generated_date")
        .withColumnRenamed("generated_by", "_generated_by")
        .withColumnRenamed("rule_output_cd", "_rule_output_cd")
        .withColumnRenamed("data_attribute_uuid", "_data_attribute_uuid")
        .withColumnRenamed("dq_check_attr_value", "_dq_check_attr_value")
    )

    pk_dict = {}
    check_status_id = [
        "128901234-90ab-cdef-1234-567890abcdef",
        "12345678910-90ab-cdef-1234-567890abcdef3",
    ]
    df_chk_summary_out, df_chk_details_out = output_dqsm(
        output_, pk_dict, check_status_id, dial_metadata_df
    )
    assert df_chk_summary_out.count() == 5
    assert len(df_chk_summary_out.columns) == 9
    assert sorted(df_chk_summary_out.columns) == sorted(summary_columns)
    assert df_chk_summary_out.filter("data_attribute_id is NULL").count() == 0
    assert df_chk_summary_out.filter("dq_check_id is NULL").count() == 0
    assert df_chk_summary_out.filter("dq_execution_date is NULL").count() == 0
    assert df_chk_summary_out.filter("generated_by is NULL").count() == 0
    assert df_chk_summary_out.filter("generated_date is NULL").count() == 0
    assert df_chk_summary_out.filter("snapshotdate is NULL").count() == 0
    assert (
        df_chk_summary_out.filter("dq_check_hit_number_of_records is NULL").count() == 0
    )
    assert (
        df_chk_summary_out.filter("dq_check_scope_number_of_records is NULL").count()
        == 0
    )
    assert df_chk_details_out.count() == 0
    assert len(df_chk_details_out.columns) == 10
    assert sorted(df_chk_details_out.columns) == sorted(outcome_columns)
    assert df_chk_details_out.filter("data_attribute_id is NULL").count() == 0
    assert df_chk_details_out.filter("dq_check_attributes is NULL").count() == 0
    assert df_chk_details_out.filter("dq_check_id is NULL").count() == 0
    assert df_chk_details_out.filter("dq_execution_date is NULL").count() == 0
    assert df_chk_details_out.filter("generated_by is NULL").count() == 0
    assert df_chk_details_out.filter("generated_date is NULL").count() == 0
    assert df_chk_details_out.filter("primary_key is NULL").count() == 0
    assert df_chk_details_out.filter("snapshotdate is NULL").count() == 0


####################################################################################
# UAT output tests
####################################################################################


@pytest.mark.usefixtures(
    "spark_session",
    "dq_dataset_metadata_df",
    "dq_dataset_df",
    "dq_checks_dial_json_fixture",
    "get_pk_data",
)
def test_get_pk_scope_data(
    spark_session,
    dq_dataset_metadata_df,
    dq_dataset_df,
    dq_checks_dial_json_fixture,
    get_pk_data,
) -> None:
    dq_dataset_df = dq_dataset_df.toDF(*[c.upper() for c in dq_dataset_df.columns])
    att_colname_map = {
        row.data_attribute_uuid: row.column_name.upper()
        for row in dq_dataset_metadata_df.collect()
    }
    check = dq_checks_dial_json_fixture[0]
    df_hits, passing_recs, _filtered_recs, out_of_scope_recs = run_check(
        spark_session, dq_dataset_df, check, att_colname_map
    )

    pk_scope_data = get_pk_scope_data(
        df_hits, passing_recs, out_of_scope_recs, ["EMAIL"]
    )
    assert pk_scope_data.collect() == get_pk_data.collect()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_log_check_output(data_frame, spark_session):
    with (
        patch(
            "dq_engine.utils.check_output.AzureFileHandler.instance_from_interface"
        ) as MockAzureFileHandler,
        patch("dq_engine.utils.check_output.DQEData") as _MockDQEData,
        patch("dq_engine.utils.check_output.DQLibrary") as _MockDQLibrary,
    ):
        mock_file_handler_instance = MockAzureFileHandler.return_value

        rule_json = {
            "id": "1",
            "filters": [],
            "status_id": "In Production",
            "rule": {
                "technical_name": "expect_column_values_to_not_be_null",
                "functional_name": "must be filled (automatable)",
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e32",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        att_colname_map = {
            "2c604f1e-392a-43b4-86fa-7c93b21e32": "user_id",
        }

        dbutils = MagicMock()
        # Run the check while patching the datetime
        with patch(
            "dq_engine.utils.check_output.datetime", wraps=datetime
        ) as MockDatetime:
            mock_execution_time = datetime.datetime(2023, 10, 1, 12, 0, 0)
            MockDatetime.datetime.now.return_value = mock_execution_time

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map, dbutils=dbutils
        )
        print(mock_file_handler_instance)
        args, kwargs = mock_file_handler_instance.write_file_to_azure.call_args
        current_datetime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        data = json.loads(kwargs["data"])
        data["rule_json"].update({"execution_datetime": current_datetime})
        return_json = {
            "counts": {
                "total": 1000,
                "filtered": 1000,
                "hit": 0,
                "passing": 1000,
                "out_of_scope": 0,
            },
            "errors": None,
            "rule_json": {
                "id": "1",
                "filters": [],
                "status_id": "In Production",
                "rule": {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "functional_name": "must be filled (automatable)",
                    "parameters": {},
                    "data_attribute": {
                        "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e32",
                        "data_attribute_source": "dsapp",
                    },
                },
                "execution_datetime": current_datetime,
            },
        }
        assert kwargs["filename"].startswith("check_outputs/")
        assert kwargs["filename"].endswith(
            f"/{rule_json['id']}_{rule_json['status_id'].lower().replace(' ', '-')}.json"
        )
        assert data == return_json


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_log_check_output_error_list(data_frame, spark_session):
    with (
        patch(
            "dq_engine.utils.check_output.AzureFileHandler.instance_from_interface"
        ) as MockAzureFileHandler,
        patch("dq_engine.utils.check_output.DQEData") as _MockDQEData,
        patch("dq_engine.utils.check_output.DQLibrary") as _MockDQLibrary,
    ):
        mock_file_handler_instance = MockAzureFileHandler.return_value

        rule_json = {
            "id": "1",
            "filters": [],
            "status_id": "In Production",
            "rule": {
                "technical_name": "expect_column_values_to_not_be_null",
                "functional_name": "must be filled (automatable)",
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e32",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        dbutils = MagicMock()
        # Run the check while patching the datetime
        with patch(
            "dq_engine.utils.check_output.datetime", wraps=datetime
        ) as MockDatetime:
            mock_execution_time = datetime.datetime(2023, 10, 1, 12, 0, 0)
            MockDatetime.datetime.now.return_value = mock_execution_time

        errors = [
            DataAttributeNotFoundValidationException(
                "test_data_attribute",
                "test_filename",
                "test_rule_type",
                "test_attribute_type",
            ),
            DataAttributeNotFoundValidationException(
                "12012-1390-233010-1312-0320432", "some_file", "filter", "regular"
            ),
        ]
        error_list = [get_error_json(error) for error in errors]

        log_check_output(
            spark=spark_session,
            dbutils=dbutils,
            rule_id="1",
            rule_json_dict=rule_json,
            error=errors,
        )

        args, kwargs = mock_file_handler_instance.write_file_to_azure.call_args
        current_datetime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        data = json.loads(kwargs["data"])
        data["rule_json"].update({"execution_datetime": current_datetime})
        return_json = {
            "counts": {
                "total": 0,
                "filtered": 0,
                "hit": 0,
                "passing": 0,
                "out_of_scope": 0,
            },
            "errors": error_list,
            "rule_json": {
                "id": "1",
                "filters": [],
                "status_id": "In Production",
                "rule": {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "functional_name": "must be filled (automatable)",
                    "parameters": {},
                    "data_attribute": {
                        "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e32",
                        "data_attribute_source": "dsapp",
                    },
                },
                "execution_datetime": current_datetime,
            },
        }
        assert kwargs["filename"].startswith("check_outputs/")
        assert kwargs["filename"].endswith(
            f"/{rule_json['id']}_{rule_json['status_id'].lower().replace(' ', '-')}.json"
        )
        assert data == return_json


@pytest.mark.usefixtures(
    "spark_session",
    "dataframe_output",
    "passing_recs_df",
    "hits_df",
    "filtered_df",
    "out_of_scope_df",
    "dummy_dq_check_json",
    "golden_data_element_df",
)
@patch("dq_engine.output_generation.DQEData")
@patch("dq_engine.output_generation.DialRds")
@patch("dq_engine.output_generation.AzureFileHandler")
@patch("dq_engine.output_generation.DialMetadataHandler")
def test_write_uat_files(
    dial_metadata_handler_mock: MagicMock,
    file_handler_mock: MagicMock,
    _,
    dqe_data_mock: MagicMock,
    spark_session: SparkSession,
    dataframe_output: DataFrame,
    passing_recs_df: DataFrame,
    hits_df: DataFrame,
    filtered_df: DataFrame,
    out_of_scope_df: DataFrame,
    dummy_dq_check_json: Dict,
    golden_data_element_df: DataFrame,
):
    """
    Tests the `write_uat_files` functions when records are less than 1M.
    """
    mock = MagicMock()  # Mock overriding some methods of different objects.
    mock.get_golden_element_df.return_value = golden_data_element_df
    mock.default_container_name = "temp_uat"
    dial_metadata_handler_mock.return_value = mock
    dqe_data_mock.return_value = mock

    expected_counts_df = pd.DataFrame(
        [
            {"METRIC": "Total records", "COUNT": "10"},
            {"METRIC": "Scope records", "COUNT": "7"},
            {"METRIC": "Out-of-scope Records", "COUNT": "3"},
            {"METRIC": "No-hits", "COUNT": "2"},
            {"METRIC": "Hits", "COUNT": "5"},
            {"METRIC": "Snapshot Date", "COUNT": "25-11-2020"},
        ],
    ).set_index("METRIC")

    expected_pk_scope_df = pd.DataFrame(
        [
            {"INDEX": 3, "DQ_SCOPE": "hit"},
            {"INDEX": 4, "DQ_SCOPE": "hit"},
            {"INDEX": 5, "DQ_SCOPE": "hit"},
            {"INDEX": 8, "DQ_SCOPE": "hit"},
            {"INDEX": 9, "DQ_SCOPE": "hit"},
            {"INDEX": 1, "DQ_SCOPE": "passing"},
            {"INDEX": 6, "DQ_SCOPE": "passing"},
            {"INDEX": 2, "DQ_SCOPE": "out of scope"},
            {"INDEX": 7, "DQ_SCOPE": "out of scope"},
            {"INDEX": 10, "DQ_SCOPE": "out of scope"},
        ]
    ).set_index("INDEX")

    expected_records_df = pd.DataFrame(
        [
            {"INDEX": 2, "VALUE": "0.0", "DQ_SCOPE": "out of scope"},
            {"INDEX": 7, "VALUE": pd.NA, "DQ_SCOPE": "out of scope"},
            {"INDEX": 10, "VALUE": pd.NA, "DQ_SCOPE": "out of scope"},
            {"INDEX": 1, "VALUE": "0.5", "DQ_SCOPE": "passing"},
            {"INDEX": 6, "VALUE": "0.2", "DQ_SCOPE": "passing"},
            {"INDEX": 3, "VALUE": "1.8", "DQ_SCOPE": "hit"},
            {"INDEX": 4, "VALUE": "1.9", "DQ_SCOPE": "hit"},
            {"INDEX": 5, "VALUE": "São Gonçalo", "DQ_SCOPE": "hit"},
            {"INDEX": 8, "VALUE": "@H@a@s@s@e@l@t", "DQ_SCOPE": "hit"},  # Escaped
            {"INDEX": 9, "VALUE": "H\\ALMELO", "DQ_SCOPE": "hit"},  # Escaped
        ]
    ).set_index("INDEX")

    # Create a temporary directory
    with tempfile.TemporaryDirectory("temp_uat") as temp_dir_name:
        # Mock the `AzureFileHandler.write_file_to_azure` method to write into
        # a temporary directory instead of blob storage.
        def mock_write_file_to_azure(
            container: str,
            data: BinaryIO,
            filename: str,
        ):
            temp_file_path = os.path.join(temp_dir_name, filename)
            Path(temp_file_path).parent.mkdir(parents=True, exist_ok=True)

            with open(temp_file_path, "wb") as f:
                f.write(data.getvalue())

        mock.write_file_to_azure.side_effect = mock_write_file_to_azure
        file_handler_mock.return_value = mock

        write_uat_files(
            spark=spark_session,
            dbutils=MagicMock(),
            df=dataframe_output,
            hits=hits_df,
            passing_recs=passing_recs_df,
            filtered_df=filtered_df,
            out_of_scope_df=out_of_scope_df,
            rule_json=dummy_dq_check_json,
            pk_dict={"INDEX": 3839},
        )

        # Read the Excel file into a dictionary of pandas DataFrames
        expected_file_path = os.path.join(
            temp_dir_name,
            f"uat_data/123_12_value_{datetime.datetime.today().strftime('%d-%m-%Y')}.xlsx",
        )
        sheet_to_df_map = pd.read_excel(
            expected_file_path, sheet_name=None, index_col=0, header=0
        )
        counts_df = sheet_to_df_map["counts"]
        pk_scope_df = sheet_to_df_map["pk_scope"]
        records_df = sheet_to_df_map["records"]

        # Check file content
        assert_frame_equal(counts_df, expected_counts_df)
        assert_frame_equal(pk_scope_df, expected_pk_scope_df)
        assert_frame_equal(records_df, expected_records_df, check_dtype=False)


@pytest.mark.usefixtures(
    "spark_session",
    "dataframe_output",
    "passing_recs_df",
    "hits_df",
    "filtered_df",
    "out_of_scope_df",
    "dummy_dq_check_json",
    "golden_data_element_df",
)
@patch("dq_engine.output_generation.DQEData")
@patch("dq_engine.output_generation.DialRds")
@patch("dq_engine.output_generation.AzureFileHandler")
@patch("dq_engine.output_generation.DialMetadataHandler")
def test_write_uat_files_primary_key_not_present(
    dial_metadata_handler_mock: MagicMock,
    file_handler_mock: MagicMock,
    _,
    dqe_data_mock: MagicMock,
    spark_session: SparkSession,
    dataframe_output: DataFrame,
    passing_recs_df: DataFrame,
    hits_df: DataFrame,
    filtered_df: DataFrame,
    out_of_scope_df: DataFrame,
    dummy_dq_check_json: Dict,
    golden_data_element_df: DataFrame,
):
    """
    Tests the `write_uat_files` functions when records are less than 1M.
    """
    mock = MagicMock()  # Mock overriding some methods of different objects.
    mock.get_golden_element_df.return_value = golden_data_element_df
    mock.default_container_name = "temp_uat"
    dial_metadata_handler_mock.return_value = mock
    dqe_data_mock.return_value = mock

    # Create a temporary directory
    with tempfile.TemporaryDirectory("temp_uat") as temp_dir_name:
        # Mock the `AzureFileHandler.write_file_to_azure` method to write into
        # a temporary directory instead of blob storage.
        def mock_write_file_to_azure(
            container: str,
            data: BinaryIO,
            filename: str,
        ):
            temp_file_path = os.path.join(temp_dir_name, filename)
            Path(temp_file_path).parent.mkdir(parents=True, exist_ok=True)

            with open(temp_file_path, "wb") as f:
                f.write(data.getvalue())

        mock.write_file_to_azure.side_effect = mock_write_file_to_azure
        file_handler_mock.return_value = mock

        with pytest.raises(
            PrimaryKeyColumnNotFoundException,
            match=re.escape(
                "Primary key(s) '['NON_EXISTENT_COLUMN']' does/do not exist in Data Frame, check the validity of the provided primary key(s). Available columns are: ['INDEX', 'VALUE']."
            ),
        ):
            write_uat_files(
                spark=spark_session,
                dbutils=MagicMock(),
                df=dataframe_output,
                hits=hits_df,
                passing_recs=passing_recs_df,
                filtered_df=filtered_df,
                out_of_scope_df=out_of_scope_df,
                rule_json=dummy_dq_check_json,
                pk_dict={"NON_EXISTENT_COLUMN": 3839},
            )


@pytest.mark.usefixtures(
    "spark_session",
    "passing_recs_df",
    "hits_df",
    "filtered_df",
    "out_of_scope_df",
)
def test_prepare_counts_df(
    spark_session: SparkSession,
    passing_recs_df: DataFrame,
    hits_df: DataFrame,
    filtered_df: DataFrame,
    out_of_scope_df: DataFrame,
):
    counts_df = _prepare_counts_df(
        spark_session,
        10,
        filtered_df,
        out_of_scope_df,
        passing_recs_df,
        hits_df,
        "25-11-2020",
    )

    data = [
        ("Total records", 10),
        ("Scope records", 7),
        ("Out-of-scope Records", 3),
        ("No-hits", 2),
        ("Hits", 5),
        ("Snapshot Date", "25-11-2020"),
    ]
    expected_counts_df = spark_session.createDataFrame(data, schema=["METRIC", "COUNT"])

    assert expected_counts_df.collect() == counts_df.collect()


@pytest.mark.usefixtures(
    "spark_session",
    "passing_recs_df",
    "hits_df",
    "out_of_scope_df",
)
def test_prepare_pk_scope_df(
    spark_session: SparkSession,
    passing_recs_df: DataFrame,
    hits_df: DataFrame,
    out_of_scope_df: DataFrame,
):
    pk_scope_df = _prepare_pk_scope_df(
        spark_session, 10, {"INDEX": 1838}, hits_df, passing_recs_df, out_of_scope_df
    )

    data = [
        (3, "hit"),
        (4, "hit"),
        (5, "hit"),
        (8, "hit"),
        (9, "hit"),
        (1, "passing"),
        (6, "passing"),
        (2, "out of scope"),
        (7, "out of scope"),
        (10, "out of scope"),
    ]

    expected_df = spark_session.createDataFrame(data, schema=["INDEX", "DQ_SCOPE"])

    assert expected_df.collect() == pk_scope_df.collect()


@pytest.mark.usefixtures(
    "spark_session",
    "passing_recs_df",
    "hits_df",
    "out_of_scope_df",
)
def test_prepare_pk_scope_df_no_pk_dict(
    spark_session: SparkSession,
    passing_recs_df: DataFrame,
    hits_df: DataFrame,
    out_of_scope_df: DataFrame,
):
    """When `pk_dict` is not provided only a message is displayed."""

    pk_scope_df = _prepare_pk_scope_df(
        spark_session, 10, {}, hits_df, passing_recs_df, out_of_scope_df
    )

    expected_df = spark_session.createDataFrame(
        [
            ("data", "No Primary keys"),
        ]
    )

    assert expected_df.collect() == pk_scope_df.collect()


@pytest.mark.usefixtures(
    "spark_session",
    "passing_recs_df",
    "hits_df",
    "out_of_scope_df",
)
def test_prepare_pk_scope_df_records_1M(
    spark_session: SparkSession,
    passing_recs_df: DataFrame,
    hits_df: DataFrame,
    out_of_scope_df: DataFrame,
):
    """When total records is equal or greater than 1M only a message is displayed."""

    pk_scope_df = _prepare_pk_scope_df(
        spark_session,
        1000000,
        {"index": "INDEX"},
        hits_df,
        passing_recs_df,
        out_of_scope_df,
    )

    expected_df = spark_session.createDataFrame(
        [
            (
                "data",
                "PK Scope data can't be generated because it contains more than 1M records.",
            ),
        ]
    )

    assert expected_df.collect() == pk_scope_df.collect()


@pytest.mark.usefixtures(
    "spark_session",
    "passing_recs_df",
    "hits_df",
    "out_of_scope_df",
)
def test_prepare_records_sample_df(
    spark_session: SparkSession,
    passing_recs_df: DataFrame,
    hits_df: DataFrame,
    out_of_scope_df: DataFrame,
):
    records_sample_df = _prepare_records_sample_df(
        1000, hits_df, passing_recs_df, out_of_scope_df
    )

    data = [
        ("2", "0.0", "out of scope"),
        ("7", None, "out of scope"),
        ("10", None, "out of scope"),
        ("1", "0.5", "passing"),
        ("6", "0.2", "passing"),
        ("3", "1.8", "hit"),
        ("4", "1.9", "hit"),
        ("5", "São Gonçalo", "hit"),
        ("8", "@H@a@s@s@e@l@t", "hit"),
        ("9", "H\\ALMELO", "hit"),
    ]
    expected_df = spark_session.createDataFrame(
        data, schema=["INDEX", "VALUE", "DQ_SCOPE"]
    )

    assert expected_df.collect() == records_sample_df.collect()
