import logging
from unittest.mock import MagicMock, patch
import pytest
from pyspark.sql import DataFrame
import json
import datetime
from dq_engine.lib import log_check_output, run_check


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_log_check_output(data_frame, spark_session):
    with (
        patch(
            "dq_engine.utils.check_output.AzureFileHandler.instance_from_interface"
        ) as MockAzureFileHandler,
        patch("dq_engine.utils.check_output.DQEData") as _MockDQEData,
        patch("dq_engine.utils.check_output.DQLibrary") as _MockDQLibrary,
    ):
        mock_file_handler_instance = MockAzureFileHandler.return_value

        rule_json = {
            "id": "1",
            "filters": [],
            "status_id": "In Production",
            "rule": {
                "technical_name": "expect_column_values_to_not_be_null",
                "functional_name": "must be filled (automatable)",
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e32",
                    "data_attribute_id": 2,
                },
            },
        }
        att_colname_map = {
            "2c604f1e-392a-43b4-86fa-7c93b21e32": "user_id",
        }

        dbutils = MagicMock()
        # Run the check while patching the datetime
        with patch(
            "dq_engine.utils.check_output.datetime", wraps=datetime
        ) as MockDatetime:
            mock_execution_time = datetime.datetime(2023, 10, 1, 12, 0, 0)
            MockDatetime.datetime.now.return_value = mock_execution_time

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map, dbutils=dbutils
        )
        args, kwargs = mock_file_handler_instance.write_file_to_azure.call_args
        current_datetime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        data = json.loads(kwargs["data"])
        data["rule_json"].update({"execution_datetime": current_datetime})
        return_json = {
            "counts": {
                "total": 1000,
                "filtered": 1000,
                "hit": 0,
                "passing": 1000,
                "out_of_scope": 0,
            },
            "errors": None,
            "rule_json": {
                "id": "1",
                "filters": [],
                "status_id": "In Production",
                "rule": {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "functional_name": "must be filled (automatable)",
                    "parameters": {},
                    "data_attribute": {
                        "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e32",
                        "data_attribute_id": 2,
                    },
                },
                "execution_datetime": current_datetime,
            },
        }
        assert kwargs["filename"].startswith("check_outputs/")
        assert kwargs["filename"].endswith(
            f"/{rule_json['id']}_{rule_json['status_id'].lower().replace(' ', '-')}.json"
        )
        assert data == return_json


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_log_check_output_error(data_frame, spark_session):
    with (
        patch(
            "dq_engine.utils.check_output.AzureFileHandler.instance_from_interface"
        ) as MockAzureFileHandler,
        patch("dq_engine.utils.check_output.DQEData") as _MockDQEData,
        patch("dq_engine.utils.check_output.DQLibrary") as _MockDQLibrary,
    ):
        mock_file_handler_instance = MockAzureFileHandler.return_value

        rule_json = {
            "id": "1",
            "filters": [],
            "status_id": "In Production",
            "rule": {
                "technical_name": "expect_column_values_to_not_be_null",
                "functional_name": "must be filled (automatable)",
                "parameters": {},
                "data_attribute": {
                    "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e32",
                    "data_attribute_id": 2,
                },
            },
        }
        att_colname_map = {
            "2c604f1e-392a-43b4-86fa-7c93b21e33": "user_id",
        }

        dbutils = MagicMock()
        # Run the check while patching the datetime
        with patch(
            "dq_engine.utils.check_output.datetime", wraps=datetime
        ) as MockDatetime:
            mock_execution_time = datetime.datetime(2023, 10, 1, 12, 0, 0)
            MockDatetime.datetime.now.return_value = mock_execution_time

        try:
            hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
                spark_session, data_frame, rule_json, att_colname_map, dbutils=dbutils
            )
        except Exception as e:
            log_check_output(
                spark=spark_session,
                dbutils=dbutils,
                rule_id=rule_json["id"],
                df=data_frame,
                hits=None,
                passing_recs=None,
                filtered_df=None,
                error=e,
                rule_json_dict=rule_json,
            )
        args, kwargs = mock_file_handler_instance.write_file_to_azure.call_args
        current_datetime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        data = json.loads(kwargs["data"])
        data["rule_json"].update({"execution_datetime": current_datetime})
        return_json = {
            "counts": {
                "total": 1000,
                "filtered": 0,
                "hit": 0,
                "passing": 0,
                "out_of_scope": 0,
            },
            "errors": [
                {
                    "code": 525,
                    "description": "Data attribute '2c604f1e-392a-43b4-86fa-7c93b21e32' is not defined on the flat file. Please check the validity of the provided data attribute uuid.",
                }
            ],
            "rule_json": {
                "id": "1",
                "filters": [],
                "status_id": "In Production",
                "rule": {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "functional_name": "must be filled (automatable)",
                    "parameters": {},
                    "data_attribute": {
                        "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e32",
                        "data_attribute_id": 2,
                    },
                },
                "execution_datetime": current_datetime,
            },
        }
        assert kwargs["filename"].startswith("check_outputs/")
        assert kwargs["filename"].endswith(
            f"/{rule_json['id']}_{rule_json['status_id'].lower().replace(' ', '-')}.json"
        )
        assert data == return_json


@pytest.mark.usefixtures("spark_session")
def test_log_check_output_logger(spark_session):
    """Test when a logger is provided the info is logged."""
    # Create mock dbutils
    dbutils = MagicMock()

    # Sample inputs
    rule_id = "test_rule"
    rule_json_dict = {"rule": {"parameters": {}}, "status_id": "Test Status"}

    # Create mock DataFrames
    df = MagicMock(DataFrame)
    hits = MagicMock(DataFrame)
    passing_recs = MagicMock(DataFrame)
    filtered_df = MagicMock(DataFrame)
    out_of_scope_df = MagicMock(DataFrame)

    # Define return values for count methods
    df.count.return_value = 100
    hits.count.return_value = 20
    passing_recs.count.return_value = 70
    filtered_df.count.return_value = 10
    out_of_scope_df.count.return_value = 5

    # Create a mock logger
    logger_obj = MagicMock(spec=logging.Logger)

    # Mock datetime to return a fixed time
    fixed_datetime = datetime.datetime(2023, 10, 12, 15, 30)
    with (
        patch("dq_engine.utils.check_output.AzureFileHandler.instance_from_interface"),
        patch("dq_engine.utils.check_output.DQEData"),
        patch("dq_engine.utils.check_output.DQLibrary"),
        patch("datetime.datetime") as mock_datetime,
        patch("dq_engine.utils.check_output.get_spark_logger") as spark_logger,
    ):
        mock_datetime.now.return_value = fixed_datetime
        spark_logger.return_value = logger_obj

        log_check_output(
            spark=spark_session,
            dbutils=dbutils,
            rule_id=rule_id,
            rule_json_dict=rule_json_dict,
            df=df,
            hits=hits,
            passing_recs=passing_recs,
            filtered_df=filtered_df,
            out_of_scope_df=out_of_scope_df,
        )

    # Check that the logger was called with the expected messages
    logger_obj.info.assert_any_call(f"logging check: {rule_id}")

    expected_output_json = {
        "counts": {
            "total": 100,
            "filtered": 10,
            "hit": 20,
            "passing": 70,
            "out_of_scope": 5,
        },
        "errors": None,
        "rule_json": {
            "rule": {"parameters": {}},
            "status_id": "Test Status",
            "execution_datetime": fixed_datetime.strftime("%Y-%m-%d %H:%M"),
        },
    }

    logger_obj.info.assert_any_call(
        json.dumps({"Payload_KPIs": expected_output_json}, indent=4)
    )
