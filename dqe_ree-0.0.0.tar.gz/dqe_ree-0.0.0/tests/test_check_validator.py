from unittest.mock import MagicMock, Mock, call, patch

import pytest

from dq_engine.check_validator import ValidateDQChecks


@pytest.mark.usefixtures("spark_session", "dq_checks_json")
def test_checks_json_parsing(spark_session, dq_checks_json):
    obj = ValidateDQChecks(
        spark=spark_session,
        reader_file_handler=None,
        writer_file_handler=None,
        reader_end_point="",
        check_status_filters=["P"],
        check_source_filters=["A"],
    )
    valid_checks, invalid_checks, errors, checks_validated = obj.validate_checks_list(
        dq_checks_json["checks"]
    )
    assert len(dq_checks_json["checks"]) == 7
    assert len(dq_checks_json["checks"]) == checks_validated
    assert len(valid_checks) == 6
    assert len(invalid_checks) == 1
    assert len(errors) == 1


@pytest.mark.usefixtures("dq_checks", "dq_filters")
def test_checks_validate_log(dq_checks, dq_filters):
    dqe_file_handler_mock = Mock()
    dq_lib_file_handler_mock = Mock()

    spark_mock = Mock()

    with patch("pyspark.sql.DataFrame.write", new_callable=Mock) as mock_write:
        mock_writer = Mock()
        mock_write.return_value = mock_writer

        def side_effect_loading_function(path):
            if "dqchecks" in path:
                return dq_checks
            elif "dqfilters" in path:
                return dq_filters
            else:
                return None

        spark_mock.read.parquet.side_effect = side_effect_loading_function
        dq_lib_file_handler_mock.spark = spark_mock
        dq_lib_file_handler_mock.list_files_in_container_folder.return_value = [
            "dqlibrary_dqlibrary_dqchecks_v2_2024-12-02_20241202085243.parquet",
            "dqlibrary_dqlibrary_dqchecks_v2_2024-12-02_20241201085243.parquet",
        ]
        obj = ValidateDQChecks(
            spark=spark_mock,
            reader_file_handler=dq_lib_file_handler_mock,
            writer_file_handler=dqe_file_handler_mock,
            reader_end_point="abfss://main@env.dfs.core.windows.net/",
            check_status_filters=["P"],
            check_source_filters=["A"],
        )
        obj.validate_and_log_v2(
            "data",
            out_checks_path="abfss://dqe-data@env.dfs.core.windows.net/DQ_Library/validated_checks/dq_checks",
            out_filters_path="abfss://dqe-data@env.dfs.core.windows.net/DQ_Library/validated_checks/dq_filters",
        )

    spark_mock.read.parquet.assert_has_calls(
        [
            call(
                "abfss://main@env.dfs.core.windows.net/dqlibrary_dqlibrary_dqchecks_v2_2024-12-02_20241202085243.parquet"
            ),
            call(
                "abfss://main@env.dfs.core.windows.net/dqlibrary_dqlibrary_dqfilters_v2_2024-12-02_20241202085243.parquet"
            ),
        ]
    )
    dq_lib_file_handler_mock.list_files_in_container_folder.assert_called()
    dqe_file_handler_mock.write_file_to_azure.assert_called()


@pytest.mark.usefixtures("spark_session", "dq_checks", "dq_filters")
def test_checks_json_parsing_v3(spark_session, dq_checks, dq_filters):
    status_filters = ["In Production", "Approval Pending"]
    source_filters = ["A"]
    obj = ValidateDQChecks(
        spark=spark_session,
        reader_file_handler=None,
        writer_file_handler=None,
        reader_end_point="",
        check_source_filters=source_filters,
        check_status_filters=status_filters,
    )
    (valid_checks, invalid_checks, errors, checks_validated, valid_checks_df) = (
        obj.validate_checks_parquets(dq_checks=dq_checks, dq_filters=dq_filters)
    )
    assert dq_checks.count() == 7
    assert dq_checks.count() == checks_validated
    assert len(valid_checks) == 6
    assert len(valid_checks) == valid_checks_df.count()
    assert len(invalid_checks) == 1
    assert len(errors) == 1


@pytest.mark.usefixtures("spark_session")
@patch("dq_engine.check_validator.AzureFileHandler")
@patch("pyspark.sql.DataFrameWriter.parquet")
def test_validate_and_log_v2(_, _writer, dq_checks, dq_filters, spark_session):
    def mock_load_latest_dq_checks_and_filters(self, *args, **kwargs):
        return dq_checks, dq_filters

    with patch.object(
        ValidateDQChecks,
        "load_latest_dq_checks_and_filters",
        new=mock_load_latest_dq_checks_and_filters,
    ):
        validator = ValidateDQChecks(
            spark=spark_session,
            reader_file_handler=MagicMock(),
            writer_file_handler=MagicMock(),
            reader_end_point="",
            check_status_filters=["In Production"],
            check_source_filters=["A"],
        )

        (valid_checks, invalid_checks, check_errors_dict, checks_validated) = (
            validator.validate_and_log_v2("dq_checks_parquet_path", "path2", "path3")
        )

        assert len(valid_checks) == 6
        assert len(invalid_checks) == 1
        assert len(check_errors_dict) == 1
        assert checks_validated == 7
