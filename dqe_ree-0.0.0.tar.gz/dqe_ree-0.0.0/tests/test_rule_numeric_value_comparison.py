import pytest
from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import DatatypeException
from pyspark.sql import functions as F

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "phone",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
    "bd5cce48-424e-4158-a046-c149625e5910": "is_male",
}

DATATYPE_EXCEPTION_MESSAGE = "Column DATE_OF_BIRTH datatype is not string or numeric."
NON_NUMERIC_PARAMETER_VALUE_MESSAGE = "Comparison value is not numeric"


class TestValuesToBeGreaterThanRule:
    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_no_null_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_greater_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 900
        assert passing_count == 100
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_null_values(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_greater_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 900
        assert passing_count == 100
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_column(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_greater_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(DatatypeException, match=DATATYPE_EXCEPTION_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_string_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_greater_than_given_number",
                "parameters": {"value": "1.A"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_boolean_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_greater_than_given_number",
                "parameters": {"value": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_numeric_string_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_greater_than_given_number",
                "parameters": {"value": "1"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 2
        assert passing_count == 998
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_decimal_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_greater_than_given_number",
                "parameters": {"value": "900.0"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert hits_count == 900
        assert passing_count == 100
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_invalid_decimal_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_greater_than_given_number",
                "parameters": {"value": "900.0.0"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Comparison value is not numeric"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)


class TestValuesToBeEqualOrGreaterThanRule:
    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_no_null_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_greater_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 899
        assert passing_count == 101
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_null_values(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_greater_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 899
        assert passing_count == 101
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_column(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_greater_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(DatatypeException, match=DATATYPE_EXCEPTION_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_string_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_greater_than_given_number",
                "parameters": {"value": "1.A"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_boolean_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_greater_than_given_number",
                "parameters": {"value": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_numeric_string_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_greater_than_given_number",
                "parameters": {"value": "1"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 1
        assert passing_count == 999
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_decimal_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_greater_than_given_number",
                "parameters": {"value": "899.9"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 899
        assert passing_count == 101
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


class TestValuesToBeLessThanRule:
    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_no_null_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_less_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 101
        assert passing_count == 899
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_null_values(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_less_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 102
        assert passing_count == 898
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_string_numeric_column(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_less_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 102
        assert passing_count == 898
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_column(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_less_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(DatatypeException, match=DATATYPE_EXCEPTION_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_string_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_less_than_given_number",
                "parameters": {"value": "1.A"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_boolean_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_less_than_given_number",
                "parameters": {"value": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_numeric_string_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_less_than_given_number",
                "parameters": {"value": "15"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 987
        assert passing_count == 13
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_decimal_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_less_than_given_number",
                "parameters": {"value": "14.9"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 987
        assert passing_count == 13
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


class TestValuesToBeEqualOrLessThanRule:
    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_no_null_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_less_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 100
        assert passing_count == 900
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_null_values(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_less_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 101
        assert passing_count == 899
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_column(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_less_than_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(DatatypeException, match=DATATYPE_EXCEPTION_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_string_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_less_than_given_number",
                "parameters": {"value": "1.A"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_boolean_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_less_than_given_number",
                "parameters": {"value": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_numeric_string_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_less_than_given_number",
                "parameters": {"value": "15"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 986
        assert passing_count == 14
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_decimal_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_or_less_than_given_number",
                "parameters": {"value": "899.9"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 102
        assert passing_count == 898
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


class TestValuesToBeEqualToRule:
    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_no_null_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_to_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 999
        assert passing_count == 1
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_null_values(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_to_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 999
        assert passing_count == 1
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_string_numeric_column(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_to_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 999
        assert passing_count == 1
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_column(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_to_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(DatatypeException, match=DATATYPE_EXCEPTION_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_string_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_to_given_number",
                "parameters": {"value": "1.A"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_boolean_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_to_given_number",
                "parameters": {"value": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_numeric_string_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_to_given_number",
                "parameters": {"value": "15"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 999
        assert passing_count == 1
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_decimal_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_equal_to_given_number",
                "parameters": {"value": 15.0},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 999
        assert passing_count == 1
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


class TestValuesToBeNotEqualToRule:
    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_no_null_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_not_equal_to_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 1
        assert passing_count == 999
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_null_values(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_not_equal_to_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 1
        assert passing_count == 999
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_column(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_not_equal_to_given_number",
                "parameters": {"value": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(DatatypeException, match=DATATYPE_EXCEPTION_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_string_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_not_equal_to_given_number",
                "parameters": {"value": "1.A"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_boolean_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_not_equal_to_given_number",
                "parameters": {"value": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=NON_NUMERIC_PARAMETER_VALUE_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_numeric_string_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_not_equal_to_given_number",
                "parameters": {"value": "15"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 1
        assert passing_count == 999
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_decimal_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_not_equal_to_given_number",
                "parameters": {"value": 14.9},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


class TestValuesToBeWithinGivenRangeRule:
    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_no_null_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": 900, "lower_bound": 5},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 104
        assert passing_count == 896
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_null_values(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": 900, "lower_bound": 5},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert passing_count + hits_count == total_count
        assert total_count - passing_count == hits_count
        assert hits_count == 105
        assert passing_count == 895
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_string_numeric_column(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": 900, "lower_bound": 100},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 199
        assert passing_count == 801
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_column(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": 900, "lower_bound": 100},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(DatatypeException, match=DATATYPE_EXCEPTION_MESSAGE):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_non_numeric_string_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": 900, "lower_bound": "5>"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Parameter 'lower_bound' should be a valid number."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_boolean_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": 900, "lower_bound": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Parameter 'lower_bound' should be a valid number."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_numeric_string_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": "900", "lower_bound": 100},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 199
        assert passing_count == 801
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_lowerbound_more_than_upperbound(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": "900", "lower_bound": 1000},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="lower_bound should be less than upper bound."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_decimal_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": "900.8", "lower_bound": 99.5},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 199
        assert passing_count == 801
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_invalid_decimal_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": "900.8.1", "lower_bound": 99.5},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Parameter 'upper_bound' should be a valid number."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_negative_lowerbound_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": "900", "lower_bound": "-99"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_count = filtered_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert filtered_count == hits_count + passing_count
        assert filtered_count == 1000
        assert hits_count == 101
        assert passing_count == 899
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_on_negative_upperbound_parameter(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "index",
            F.when(data_frame["index"] == 10, None).otherwise(data_frame["index"]),
        )
        data_frame = data_frame.withColumn("index", data_frame["index"].cast("string"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_within_given_range",
                "parameters": {"upper_bound": "-900", "lower_bound": "99"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="lower_bound should be less than upper bound."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)
