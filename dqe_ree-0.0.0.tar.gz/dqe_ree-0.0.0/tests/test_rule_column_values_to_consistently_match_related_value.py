import pytest
from dq_engine.lib import run_check
from pyspark.sql.session import SparkSession

rule_name = "expect_column_values_to_consistently_match_related_value"

att_colname = {
    "bd5cce48-424e-4158-a046-c149625e5901": "id",
    "bd5cce48-424e-4158-a046-c149625e5902": "first",
    "bd5cce48-424e-4158-a046-c149625e5903": "second",
    "bd5cce48-424e-4158-a046-c149625e5904": "hit",
}


@pytest.mark.usefixtures("spark_session")
def test_expect_column_values_to_consistently_match_related_value(
    spark_session: SparkSession,
) -> None:
    test_data_frame = spark_session.createDataFrame(
        [
            (1, "X", "A", "Hit"),  # create your data here, be consistent in the types.
            (2, "X", "A", "Hit"),
            (3, "X", "B", "Hit"),
            (3, "X", "C", "Hit"),
            (3, "Y", "A", "No Hit"),
            (4, "Y", "A", "No Hit"),
            (5, "Z", "B", "No Hit"),
        ],
        ["id", "first", "second", "hit"],  # add your column names here
    )

    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "related_value_attribute": "bd5cce48-424e-4158-a046-c149625e5903"
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, test_data_frame, rule_json, att_colname
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == test_data_frame.count()
    assert hits_count == 4
    assert test_data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("spark_session")
def test_expect_column_types_to_be_same(spark_session: SparkSession) -> None:
    test_data_frame = spark_session.createDataFrame(
        [
            (1, "X", "A", "Hit"),  # create your data here, be consistent in the types.
            (2, "X", "A", "Hit"),
            (3, "X", "B", "Hit"),
            (3, "X", "C", "Hit"),
            (3, "Y", "A", "No Hit"),
            (4, "Y", "A", "No Hit"),
            (5, "Z", "B", "No Hit"),
        ],
        ["id", "first", "second", "hit"],  # add your column names here
    )

    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "related_value_attribute": "bd5cce48-424e-4158-a046-c149625e5903"
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ValueError, match="Column ID is not of same data type as a Column SECOND"
    ):
        run_check(spark_session, test_data_frame, rule_json, att_colname)
