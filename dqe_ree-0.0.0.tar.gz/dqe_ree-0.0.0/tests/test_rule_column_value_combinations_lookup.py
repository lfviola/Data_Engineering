import pytest
from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import InvalidParameterException
from pyspark.sql import SparkSession, DataFrame
import unittest.mock as mock
from dq_engine.rules.rule_column_value_combinations_lookup import (
    ColumnValueCombinationAgainstLookupTable,
)
from unittest.mock import patch


@pytest.fixture
def helper_functions() -> dict:
    return {
        "get_latest_file": mock.Mock(
            return_value="tests/resources/df_reference_data.csv"
        )
    }


@pytest.mark.usefixtures("spark_session", "metadata_df")
class TestColumnValueCombinationAgainstLookupTable:
    def test_trim_columns_whitespaces(self, spark_session):
        columns = [
            "REASON_CODE_REFERENCE",
            "REASON_DESCRIPTION_REFERENCE",
            "NUM",
            "OTHER",
        ]
        data = [
            ("A", "Reason A", 1, "Other A  "),
            (" B", "  Reason B", 2, " Other B"),
            ("C ", "Reason   C", 3, "Other A  "),
            ("D ", "Reason D  ", 4, " Other B"),
        ]
        df = spark_session.createDataFrame(data, columns)

        trim_df = ColumnValueCombinationAgainstLookupTable._trim_columns_whitespaces(
            df, columns=["REASON_CODE_REFERENCE", "REASON_DESCRIPTION_REFERENCE", "NUM"]
        )

        expected_data = [
            ("A", "Reason A", 1, "Other A  "),
            ("B", "Reason B", 2, " Other B"),
            ("C", "Reason   C", 3, "Other A  "),
            ("D", "Reason D", 4, " Other B"),
        ]
        expected_df = spark_session.createDataFrame(expected_data, columns)

        assert trim_df.collect() == expected_df.collect()

    def test_parameter_parsing_parameters_length(self, spark_session, metadata_df):
        with patch.multiple(
            ColumnValueCombinationAgainstLookupTable,
            __abstractmethods__=set(),
            presence_operator=classmethod(lambda cls: None),
        ):
            with pytest.raises(
                InvalidParameterException,
                match="'source_attributes' and 'lookup_attributes' parameters should be of same length.",
            ):
                ColumnValueCombinationAgainstLookupTable(
                    spark=spark_session,
                    data_attribute_uuid="bd5cce48-424e-4158-a046-c149625e5926",
                    parameters={
                        "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                        "lookup_attributes": ["bd5cce48-424e-4158-a046-c149625e5928"],
                        "source_attributes": [
                            "bd5cce48-424e-4158-a046-c149625e5926",
                            "bd5cce48-424e-4158-a046-c149625e5927",
                        ],
                    },
                    att_colname_map=None,
                    metadata_dataframe=metadata_df,
                )

            with pytest.raises(
                InvalidParameterException,
                match="'source_attributes' and 'lookup_attributes' parameters should be of same length.",
            ):
                ColumnValueCombinationAgainstLookupTable(
                    spark=spark_session,
                    data_attribute_uuid="bd5cce48-424e-4158-a046-c149625e5926",
                    parameters={
                        "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                        "lookup_attributes": [
                            "bd5cce48-424e-4158-a046-c149625e5928",
                            "bd5cce48-424e-4158-a046-c149625e5929",
                        ],
                        "source_attributes": ["bd5cce48-424e-4158-a046-c149625e5926"],
                    },
                    att_colname_map=None,
                    metadata_dataframe=metadata_df,
                )

    def test_parameter_parsing_source_attributes_count(
        self, spark_session, metadata_df
    ):
        with patch.multiple(
            ColumnValueCombinationAgainstLookupTable,
            __abstractmethods__=set(),
            presence_operator=classmethod(lambda cls: None),
        ):
            with pytest.raises(
                InvalidParameterException,
                match="'source_attributes' cannot be less than 2.",
            ):
                ColumnValueCombinationAgainstLookupTable(
                    spark=spark_session,
                    data_attribute_uuid="bd5cce48-424e-4158-a046-c149625e5926",
                    parameters={
                        "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                        "lookup_attributes": ["bd5cce48-424e-4158-a046-c149625e5928"],
                        "source_attributes": ["bd5cce48-424e-4158-a046-c149625e5926"],
                    },
                    att_colname_map=None,
                    metadata_dataframe=metadata_df,
                )


@pytest.mark.usefixtures(
    "spark_session", "df_value_lookup", "metadata_df", "helper_functions"
)
class TestExpectColumnValueCombinationsToExistInLookupTable:
    rule_name = "expect_column_value_combinations_to_exist_in_lookup_table"

    def test_column_values_to_consistently_match_related_value(
        self, spark_session, df_value_lookup, metadata_df, helper_functions
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "lookup_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5928",
                        "bd5cce48-424e-4158-a046-c149625e5929",
                    ],
                    "source_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5926",
                        "bd5cce48-424e-4158-a046-c149625e5927",
                    ],
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark=spark_session,
            df=df_value_lookup,
            rule_json=rule_json,
            attributeid_colname_map=None,
            helper_func_dict=helper_functions,
            testing=True,
            metadata_table=metadata_df,
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 7
        assert passing_count == 6
        assert (
            df_value_lookup.count() == out_of_scope_recs_count + filtered_recs.count()
        )

    def test_column_values_to_consistently_match_related_value_dq_dataset(
        self, spark_session, df_value_lookup, metadata_df, helper_functions
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "lookup_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5928",
                        "bd5cce48-424e-4158-a046-c149625e5929",
                    ],
                    "source_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5941",
                        "bd5cce48-424e-4158-a046-c149625e5942",
                    ],
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
                "dq_dataset_data": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5941",
                    "data_attribute_source": "dqdataset",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark=spark_session,
            df=df_value_lookup,
            rule_json=rule_json,
            attributeid_colname_map=None,
            helper_func_dict=helper_functions,
            testing=True,
            metadata_table=metadata_df,
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 7
        assert passing_count == 6
        assert (
            df_value_lookup.count() == out_of_scope_recs_count + filtered_recs.count()
        )

    def test_column_values_to_consistently_match_related_value_trim_white_spaces(
        self, spark_session, df_value_lookup, metadata_df, helper_functions
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "lookup_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5928",
                        "bd5cce48-424e-4158-a046-c149625e5929",
                    ],
                    "source_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5926",
                        "bd5cce48-424e-4158-a046-c149625e5927",
                    ],
                    "trim_whitespace": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark=spark_session,
            df=df_value_lookup,
            rule_json=rule_json,
            attributeid_colname_map=None,
            helper_func_dict=helper_functions,
            testing=True,
            metadata_table=metadata_df,
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 5
        assert passing_count == 8
        assert (
            df_value_lookup.count() == out_of_scope_recs_count + filtered_recs.count()
        )

    def test_parameter_parsing(
        self, spark_session, df_value_lookup, metadata_df, helper_functions
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "lookup_attributes": ["bd5cce48-424e-4158-a046-c149625e5928"],
                    "source_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5926",
                        "bd5cce48-424e-4158-a046-c149625e5927",
                    ],
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            InvalidParameterException,
            match="'source_attributes' and 'lookup_attributes' parameters should be of same length.",
        ):
            run_check(
                spark=spark_session,
                df=df_value_lookup,
                rule_json=rule_json,
                attributeid_colname_map=None,
                helper_func_dict=helper_functions,
                testing=True,
                metadata_table=metadata_df,
            )

        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "lookup_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5928",
                        "bd5cce48-424e-4158-a046-c149625e5929",
                    ],
                    "source_attributes": ["bd5cce48-424e-4158-a046-c149625e5926"],
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            InvalidParameterException,
            match="'source_attributes' and 'lookup_attributes' parameters should be of same length.",
        ):
            run_check(
                spark=spark_session,
                df=df_value_lookup,
                rule_json=rule_json,
                attributeid_colname_map=None,
                helper_func_dict=helper_functions,
                testing=True,
                metadata_table=metadata_df,
            )

        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "lookup_attributes": ["bd5cce48-424e-4158-a046-c149625e5928"],
                    "source_attributes": ["bd5cce48-424e-4158-a046-c149625e5926"],
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            InvalidParameterException,
            match="'source_attributes' cannot be less than 2.",
        ):
            run_check(
                spark=spark_session,
                df=df_value_lookup,
                rule_json=rule_json,
                attributeid_colname_map=None,
                helper_func_dict=helper_functions,
                testing=True,
                metadata_table=metadata_df,
            )

    def test_parameter_validation_for_attributes_in_same_file(
        self, spark_session, df_value_lookup, metadata_df, helper_functions
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "lookup_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5928",
                        "bd5cce48-424e-4158-a046-c149625e5929",
                    ],
                    "source_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5926",
                        "bd5cce48-424e-4158-a046-c149625e5902",
                    ],
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            InvalidParameterException,
            match="'source_attributes' columns are not present in source file.",
        ):
            run_check(
                spark=spark_session,
                df=df_value_lookup,
                rule_json=rule_json,
                attributeid_colname_map=None,
                helper_func_dict=helper_functions,
                testing=True,
                metadata_table=metadata_df,
            )

        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "lookup_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5928",
                        "bd5cce48-424e-4158-a046-c149625e5902",
                    ],
                    "source_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5926",
                        "bd5cce48-424e-4158-a046-c149625e5927",
                    ],
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            InvalidParameterException,
            match="'lookup_attributes' columns are not present in reference file.",
        ):
            run_check(
                spark=spark_session,
                df=df_value_lookup,
                rule_json=rule_json,
                attributeid_colname_map=None,
                helper_func_dict=helper_functions,
                testing=True,
                metadata_table=metadata_df,
            )


@pytest.mark.usefixtures(
    "spark_session", "df_value_lookup", "metadata_df", "helper_functions"
)
class TestColumnValueCombinationNotInLookupTable:
    rule_name = "ColumnValueCombinationNotInLookupTable"

    def test_column_values_to_consistently_match_related_value(
        self,
        spark_session: SparkSession,
        df_value_lookup: DataFrame,
        metadata_df: DataFrame,
        helper_functions: dict,
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "lookup_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5928",
                        "bd5cce48-424e-4158-a046-c149625e5929",
                    ],
                    "source_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5926",
                        "bd5cce48-424e-4158-a046-c149625e5927",
                    ],
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark=spark_session,
            df=df_value_lookup,
            rule_json=rule_json,
            attributeid_colname_map=None,
            helper_func_dict=helper_functions,
            testing=True,
            metadata_table=metadata_df,
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 6
        assert passing_count == 7
        assert (
            df_value_lookup.count() == out_of_scope_recs_count + filtered_recs.count()
        )

    def test_column_values_to_consistently_match_related_value_dq_dataset(
        self, spark_session, df_value_lookup, metadata_df, helper_functions
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "lookup_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5928",
                        "bd5cce48-424e-4158-a046-c149625e5929",
                    ],
                    "source_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5941",
                        "bd5cce48-424e-4158-a046-c149625e5942",
                    ],
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
                "dq_dataset_data": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5941",
                    "data_attribute_source": "dqdataset",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark=spark_session,
            df=df_value_lookup,
            rule_json=rule_json,
            attributeid_colname_map=None,
            helper_func_dict=helper_functions,
            testing=True,
            metadata_table=metadata_df,
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 6
        assert passing_count == 7
        assert (
            df_value_lookup.count() == out_of_scope_recs_count + filtered_recs.count()
        )

    def test_column_values_to_consistently_match_related_value_trim_whitespaces(
        self,
        spark_session: SparkSession,
        df_value_lookup: DataFrame,
        metadata_df: DataFrame,
        helper_functions: dict,
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "reference_data_attribute_id": "bd5cce48-424e-4158-a046-c149625e5928",
                    "trim_whitespace": True,
                    "lookup_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5928",
                        "bd5cce48-424e-4158-a046-c149625e5929",
                    ],
                    "source_attributes": [
                        "bd5cce48-424e-4158-a046-c149625e5926",
                        "bd5cce48-424e-4158-a046-c149625e5927",
                    ],
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5926",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark=spark_session,
            df=df_value_lookup,
            rule_json=rule_json,
            attributeid_colname_map=None,
            helper_func_dict=helper_functions,
            testing=True,
            metadata_table=metadata_df,
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 8
        assert passing_count == 5
        assert (
            df_value_lookup.count() == out_of_scope_recs_count + filtered_recs.count()
        )
