import pytest

from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import ParameterNotFoundException

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "seq_number",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
    "bd5cce48-424e-4158-a046-c149625e5910": "sex_2",
    "bd5cce48-424e-4158-a046-c149625e5911": "sex_decimal",
}


class TestInListRule:
    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_string_values(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": ["Male"]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 494
        assert passing_count == 506
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_integer_values(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": [4, 5, 6, 7, 8, 9]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 994
        assert passing_count == 6
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.parametrize("allowed_values", [([1.0]), ([1])])
    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_decimal_values(
        self, data_frame_2, spark_session, allowed_values
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": allowed_values},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5911",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 494
        assert passing_count == 506
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_rule_as_filter(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_be_in_list",
                    "parameters": {"allowed_values": ["Male"]},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": ["Female"]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 506
        assert passing_count == 0
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_rule_with_wrong_parameter_name(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowe_values": ["Female"]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ParameterNotFoundException, match="Parameter not found."):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_rule_with_wrong_parameter_type(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": "Female"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Parameter should be an array type"):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_rule_with_wrong_datatype_type(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": "01/Oct/2023"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Parameter should be an array type"):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_rule_with_decimal_values(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": [139.8, 145.9]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5907",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 998
        assert passing_count == 2
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_whitespaces(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": ["Male "], "trim_whitespace": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 494
        assert passing_count == 506
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_invalid_parameter_value(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": ["Male "], "trim_whitespace": "True"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError,
            match="Invalid value for 'trim_whitespace' parameter. Only boolean values allowed.",
        ):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_null_values_positive(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {
                    "allowed_values": ["Male "],
                    "trim_whitespace": True,
                    "allow_null_values": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 493
        assert passing_count == 507
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_null_values_negative(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {
                    "allowed_values": ["Male "],
                    "trim_whitespace": True,
                    "allow_null_values": False,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 494
        assert passing_count == 506
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_invalid_null_parameter_value(
        self, data_frame_2, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {
                    "allowed_values": ["Male "],
                    "trim_whitespace": True,
                    "allow_null_values": "False",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError,
            match="Invalid value for 'allow_null_values' parameter. Only boolean values allowed.",
        ):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_invalid_parameter(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {
                    "allowed_values": ["Male "],
                    "trim_whitespace": True,
                    "disallow_null_values": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError,
            match="Parameter 'disallow_null_values' can not be set for this rule.",
        ):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_string_values_ignore_case(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": ["MAle"], "ignore_case": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 494
        assert passing_count == 506
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_string_values_ignore_case_invalid_datatype(
        self, data_frame_2, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_be_in_list",
                "parameters": {"allowed_values": ["MAle"], "ignore_case": "True"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError,
            match="Invalid value for 'ignore_case' parameter. Only boolean values allowed.",
        ):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)


class TestNotInListRules:
    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_string_values(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {"allowed_values": ["Male"]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 506
        assert passing_count == 494
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_integer_values(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {"allowed_values": [4, 5, 6, 7, 8, 9]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 6
        assert passing_count == 994
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_rule_as_filter(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_in_list",
                    "parameters": {"allowed_values": ["Male"]},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {"allowed_values": ["Female"]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 494
        assert passing_count == 0

        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_rule_with_wrong_parameter(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {"allowe_values": ["Female"]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ParameterNotFoundException, match="Parameter not found."):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_rule_with_wrong_parameter_type(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {"allowed_values": "Female"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Parameter should be an array type"):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_exception_values_parameter(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {"exception_values": ["Male"]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 506
        assert passing_count == 494
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_parameter_parsing(self, data_frame_2, spark_session):
        rule_json = {
            "description": "L_LEGLY_CAPABLE should be filled with YES/NO",
            "filters": [],
            "golden_data_element_id": 202591,
            "id": "55acc12e-a97c-4ef2-8d92-fcff0684746f",
            "metric_name": "",
            "rule": {
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "_dq_dataset": None,
                    "additional_attributes": None,
                    "allowed_values": None,
                    "column_to_compare": None,
                    "comparison": None,
                    "date_format": None,
                    "length": None,
                    "lower_bound": None,
                    "number": None,
                    "number_of_days": None,
                    "reference_data_attribute_id": None,
                    "regex": None,
                    "upper_bound": None,
                    "value": None,
                    "values": ["YES", "NO"],
                },
                "technical_name": "expect_column_values_to_be_in_list",
            },
            "scorecard_name": "",
            "source_id": "A",
            "status_id": "P",
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 1000
        assert passing_count == 0

        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_whitespaces(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {"allowed_values": ["Male "], "trim_whitespace": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 506
        assert passing_count == 494
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_null_values_positive(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {
                    "allowed_values": ["Male "],
                    "trim_whitespace": True,
                    "disallow_null_values": False,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 506
        assert passing_count == 494
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_null_values_negative(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {
                    "allowed_values": ["Male "],
                    "trim_whitespace": True,
                    "disallow_null_values": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 507
        assert passing_count == 493
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_invalid_null_parameter_value(
        self, data_frame_2, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {
                    "allowed_values": ["Male "],
                    "trim_whitespace": True,
                    "disallow_null_values": "True",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError,
            match="Invalid value for 'disallow_null_values' parameter. Only boolean values allowed.",
        ):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_invalid_parameter(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {
                    "allowed_values": ["Male "],
                    "trim_whitespace": True,
                    "allow_null_values": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError,
            match="Parameter 'allow_null_values' can not be set for this rule.",
        ):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_string_values_ignore_case(self, data_frame_2, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {"allowed_values": ["MAle"], "ignore_case": True},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame_2, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame_2.count()
        assert hits_count == 506
        assert passing_count == 494
        assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame_2", "spark_session")
    def test_column_with_string_values_ignore_case_invalid_datatype(
        self, data_frame_2, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": "expect_column_values_to_not_be_in_list",
                "parameters": {"allowed_values": ["MAle"], "ignore_case": "True"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError,
            match="Invalid value for 'ignore_case' parameter. Only boolean values allowed.",
        ):
            run_check(spark_session, data_frame_2, rule_json, att_colname_map)
