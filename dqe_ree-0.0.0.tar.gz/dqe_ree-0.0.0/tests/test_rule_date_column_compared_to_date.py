import pytest
from dq_engine.lib import run_check
from pyspark.sql import SparkSession, DataFrame
from dq_engine.rules.custom_exceptions import (
    ParameterNotFoundException,
)

att_col_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "date",
    "bd5cce48-424e-4158-a046-c149625e5903": "date_str",
    "bd5cce48-424e-4158-a046-c149625e5904": "timestamp",
    "bd5cce48-424e-4158-a046-c149625e5905": "date_integer",
    "bd5cce48-424e-4158-a046-c149625e5906": "date_long",
    "bd5cce48-424e-4158-a046-c149625e5907": "date_double",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_decimal",
}


@pytest.mark.usefixtures("dates_dataframe", "spark_session")
class TestDateColumnComparedToDateRule:
    rule_name = "DateColumnComparedToDateRule"

    @pytest.mark.parametrize(
        "data_attribute_uuid,date_format",
        [
            ("bd5cce48-424e-4158-a046-c149625e5902", "dd-MM-yyyy"),
            ("bd5cce48-424e-4158-a046-c149625e5903", "dd-MM-yyyy"),
            ("bd5cce48-424e-4158-a046-c149625e5904", "dd-MM-yyyy"),
            ("bd5cce48-424e-4158-a046-c149625e5905", "ddMMyyyy"),
            ("bd5cce48-424e-4158-a046-c149625e5906", "ddMMyyyy"),
            ("bd5cce48-424e-4158-a046-c149625e5907", "ddMMyyyy"),
            ("bd5cce48-424e-4158-a046-c149625e5908", "ddMMyyyy"),
        ],
    )
    def test_is_operator(
        self,
        dates_dataframe: DataFrame,
        spark_session: SparkSession,
        data_attribute_uuid: str,
        date_format: str,
    ):
        """
        Sucessful test case with strings, dates and timestamps.
        """
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": data_attribute_uuid,
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "27-01-2014",
                    "comparison_type": "is",
                    "date_format": date_format,
                },
            },
            "filters": [],
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dates_dataframe, param_json, att_col_map
        )

        assert (
            dates_dataframe.count() == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == dates_dataframe.count()
        assert passing_recs.count() == 3

    def test_is_operator_no_match(
        self, dates_dataframe: DataFrame, spark_session: SparkSession
    ):
        """Passing is 0."""
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "30-01-2014",
                    "comparison_type": "is",
                },
            },
            "filters": [],
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dates_dataframe, param_json, att_col_map
        )
        assert (
            dates_dataframe.count() == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == dates_dataframe.count()
        assert passing_recs.count() == 0

    @pytest.mark.usefixtures("dates_dataframe_bars")
    def test_is_operator_string_dates_other_format(
        self, dates_dataframe_bars: DataFrame, spark_session: SparkSession
    ):
        """Test using dataset with different date format."""
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "27-01-2014",
                    "comparison_type": "is",
                    "date_format": "yyyy/MM/dd",
                },
            },
            "filters": [],
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dates_dataframe_bars, param_json, att_col_map
        )
        assert (
            dates_dataframe_bars.count()
            == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == dates_dataframe_bars.count()
        assert passing_recs.count() == 3

    def test_is_not_operator(
        self, dates_dataframe: DataFrame, spark_session: SparkSession
    ):
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "27-01-2014",
                    "comparison_type": "is not",
                },
            },
            "filters": [],
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dates_dataframe, param_json, att_col_map
        )
        assert (
            dates_dataframe.count() == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == dates_dataframe.count()
        assert passing_recs.count() == 8

    def test_less_than_operator(
        self, dates_dataframe: DataFrame, spark_session: SparkSession
    ):
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "27-01-2014",
                    "comparison_type": "less than",
                },
            },
            "filters": [],
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dates_dataframe, param_json, att_col_map
        )
        assert (
            dates_dataframe.count() == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == dates_dataframe.count()
        assert passing_recs.count() == 1

    def test_less_than_or_equal_operator(
        self, dates_dataframe: DataFrame, spark_session: SparkSession
    ):
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "27-01-2014",
                    "comparison_type": "less than or equal",
                },
            },
            "filters": [],
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dates_dataframe, param_json, att_col_map
        )
        assert (
            dates_dataframe.count() == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == dates_dataframe.count()
        assert passing_recs.count() == 4

    def test_greater_than_operator(
        self, dates_dataframe: DataFrame, spark_session: SparkSession
    ):
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "27-01-2014",
                    "comparison_type": "greater than",
                },
            },
            "filters": [],
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dates_dataframe, param_json, att_col_map
        )
        assert (
            dates_dataframe.count() == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == dates_dataframe.count()
        assert passing_recs.count() == 7

    def test_greater_than_or_equal_operator(
        self, dates_dataframe: DataFrame, spark_session: SparkSession
    ):
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "27-01-2014",
                    "comparison_type": "greater than or equal",
                },
            },
            "filters": [],
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dates_dataframe, param_json, att_col_map
        )
        assert (
            dates_dataframe.count() == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == dates_dataframe.count()
        assert passing_recs.count() == 10

    @pytest.mark.parametrize(
        "comparison_date", ["2020/22/11", "22/11/2020", "2020-11-22"]
    )
    def test_invalid_parameter_comparison_date(
        self,
        dates_dataframe: DataFrame,
        spark_session: SparkSession,
        comparison_date: str,
    ):
        """Comparison date given in wrong format."""
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": comparison_date,  # expected format 'dd-MM-yyyy'
                    "comparison_type": "is",
                    "date_format": "dd-MM-yyyy",
                },
            },
            "filters": [],
        }
        with pytest.raises(
            ValueError,
            match=f"time data '{comparison_date}' does not match format '%d-%m-%Y'",
        ):
            run_check(spark_session, dates_dataframe, param_json, att_col_map)

    @pytest.mark.usefixtures("dates_dataframe_bars")
    def test_unmatching_parameter_date_format(
        self, dates_dataframe_bars: DataFrame, spark_session: SparkSession
    ):
        """
        The attribute contains values not according to the defined 'date_format'
        parameter, leading into 0 passing records.
        """
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "22-11-2020",
                    "comparison_type": "is",
                    "date_format": "dd-MM-yyyy",
                },
            },
            "filters": [],
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dates_dataframe_bars, param_json, att_col_map
        )
        assert (
            dates_dataframe_bars.count()
            == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == dates_dataframe_bars.count()
        assert passing_recs.count() == 0
        assert hits.count() == 13

    def test_not_date_format_when_required(
        self, dates_dataframe: DataFrame, spark_session: SparkSession
    ):
        """
        Test error is raised when column is of type string
        and 'date_format' parameter is not provided.
        """
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "22-11-2020",
                    "comparison_type": "is",
                },
            },
            "filters": [],
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(spark_session, dates_dataframe, param_json, att_col_map)

    def test_invalid_parameter_comparison_type(
        self, dates_dataframe: DataFrame, spark_session: SparkSession
    ):
        """Not supported comparison"""
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "comparison_date": "27-01-2014",
                    "comparison_type": "other",
                    "date_format": "dd-MM-yyyy",
                },
            },
            "filters": [],
        }
        with pytest.raises(ValueError, match=r"Unknown operator type 'other'"):
            run_check(spark_session, dates_dataframe, param_json, att_col_map)

    def test_mandatory_parameter_not_provided(
        self, dates_dataframe: DataFrame, spark_session: SparkSession
    ):
        param_json = {
            "rule": {
                "technical_name": self.rule_name,
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "date_format": "dd-MM-yyyy",
                    "comparison_date": "27-01-2014",
                },
            },
            "filters": [],
        }
        with pytest.raises(
            ParameterNotFoundException,
            match=r"Required parameter 'comparison_type' not found.",
        ):
            run_check(spark_session, dates_dataframe, param_json, att_col_map)
