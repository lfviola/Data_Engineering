import pytest
from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import ParameterNotFoundException

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "phone",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
    "bd5cce48-424e-4158-a046-c149625e5910": "is_male",
    "bd5cce48-424e-4158-a046-c149625e5911": "average",
    "bd5cce48-424e-4158-a046-c149625e5912": "big_int",
}

rule_equality = "expect_column_values_to_be_equal_to_value"
rule_non_equality = "expect_column_values_to_be_not_equal_to_value"


class TestEqualityRules:
    # -------TESTS parse_parameters -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_wrong_parameter_key(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"input": "Male"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException, match="Parameter 'value' not found"
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_empty_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": ""},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value cannot be empty"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_invalid_parameter_list(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": [1, 2, 3]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value cannot be of type tuple or array"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_invalid_parameter_tuple(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": (1, 2, 3)},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value cannot be of type tuple or array"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    # -------TESTS validate_parameters UNSUPPORTED DATATYPES -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_unsupported_datatypes(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": 1.1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5911",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Exact matches can't be made against floats"
        ):
            data_frame = data_frame.withColumn(
                "average", data_frame["average"].cast("float")
            )
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    # -------TESTS validate_parameters STRING -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_string_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": "Male"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 494
        assert passing_count == 506
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    # -------TESTS validate_parameters INTEGER -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_int_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": 111},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 999
        assert passing_count == 1
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_bigint_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": 9223372036854775807},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5912",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 999
        assert passing_count == 1
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_int_value_not_numeric(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": "Male"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value is not numeric"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_int_datatype_mismatch_with_parameter_value(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": "1.23"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Datatype mismatch between value and column datatype"
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    # -------TESTS validate_parameters DECIMAL/DOUBLE -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_double_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": 4.9542},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5911",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 999
        assert passing_count == 1
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_decimal_value_not_numeric(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": "Male"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5911",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value is not numeric"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_double_datatype_mismatch_with_parameter_value(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": "1"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5911",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Datatype mismatch between value and column datatype"
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    # -------TESTS validate_parameters BOOLEAN -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_boolean_values(self, data_frame, spark_session):
        # Test input string "TRUE", convert to lower and to True
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": "TRUE"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 495
        assert passing_count == 505
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

        # Test input string "true", convert to True
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": "true"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 495
        assert passing_count == 505
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

        # Test input integer 1, convert to True
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": 1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 495
        assert passing_count == 505
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

        # no boolean value
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": "TRUEFALSE"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value is not boolean"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    ## -------TESTS date values -----------
    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_date_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": "16-03-2014"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits.count() == 999
        assert passing_recs.count() == 1
        assert filtered_recs.count() == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_wrong_date_format_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_equality,
                "parameters": {"value": "2014-16-3"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Value does not match format 'dd-mm-yyyy'"
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)


class TestNonEqualityRules:
    ## -------TESTS parse_parameters -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_wrong_parameter_key(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"input": "Male"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException, match="Parameter 'value' not found"
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_empty_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": ""},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value cannot be empty"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_invalid_parameter_list(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": [1, 2, 3]},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value cannot be of type tuple or array"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_invalid_parameter_tuple(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": (1, 2, 3)},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value cannot be of type tuple or array"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    # -------TESTS validate_parameters UNSUPPORTED DATATYPES -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_unsupported_datatypes(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": 1.1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5911",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Exact matches can't be made against floats"
        ):
            data_frame = data_frame.withColumn(
                "average", data_frame["average"].cast("float")
            )
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    # -------TESTS validate_parameters STRING -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_string_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": "Female"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 494
        assert passing_count == 506
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    # -------TESTS validate_parameters INTEGER -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_int_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": 111},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 1
        assert passing_count == 999
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_bigint_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": 9223372036854775807},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5912",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 1
        assert passing_count == 999
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_int_value_not_numeric(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": "Male"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value is not numeric"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_int_datatype_mismatch_with_parameter_value(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": "1.23"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Datatype mismatch between value and column datatype"
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    # -------TESTS validate_parameters DECIMAL/DOUBLE -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_double_values(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": 4.9542},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5911",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 1
        assert passing_count == 999
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_decimal_value_not_numeric(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": "Male"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5911",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value is not numeric"):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_double_datatype_mismatch_with_parameter_value(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": "1"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5911",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Datatype mismatch between value and column datatype"
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    # -------TESTS validate_parameters BOOLEAN -----------

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_boolean_values(self, data_frame, spark_session):
        # Test input string "FALSE", convert to lower and to False
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": "FALSE"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 493
        assert passing_count == 507
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

        # Test input string "false", convert to False
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": "false"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 493
        assert passing_count == 507
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

        # Test input integer 0, convert to False
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": 0},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        total_count = data_frame.count()
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert total_count == (hits_count + passing_count)
        assert total_count - passing_count == hits_count
        assert hits_count == 493
        assert passing_count == 507
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

        # no boolean value
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": "TRUEFALSE"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match="Value is not boolean"):
            hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
                spark_session, data_frame, rule_json, att_colname_map
            )

    ## -------TESTS date values -----------
    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_date_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": "16-03-2014"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits.count() == 1
        assert passing_recs.count() == 999
        assert filtered_recs.count() == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_with_wrong_date_format_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": rule_non_equality,
                "parameters": {"value": "2014-16-3"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Value does not match format 'dd-mm-yyyy'"
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)
