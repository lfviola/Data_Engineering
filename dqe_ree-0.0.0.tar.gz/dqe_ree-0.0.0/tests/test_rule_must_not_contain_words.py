import pytest
from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import DatatypeException

rule_name = "expect_column_string_values_to_not_contain_words"

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "phone",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
}


@pytest.mark.usefixtures("data_frame_2", "spark_session")
def test_column_with_string_values(data_frame_2, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "disallowed_words": ["ev", "e/v", "pv", "p/v"],
                "case_sensitive": True,
                "strip_characters": "",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame_2, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame_2.count()
    assert hits_count == 40
    assert passing_count == 960
    assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame_2", "spark_session")
def test_column_with_email(data_frame_2, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "disallowed_words": ["ev", "pv"],
                "case_sensitive": True,
                "strip_characters": "",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5906",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame_2, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame_2.count()
    assert hits_count == 0
    assert passing_count == 1000
    assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame_2", "spark_session")
def test_column_with_id(data_frame_2, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "disallowed_words": ["ev", "pv"],
                "case_sensitive": True,
                "strip_characters": "",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame_2, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame_2.count()
    assert hits_count == 0
    assert passing_count == 1000
    assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame_2", "spark_session")
def test_column_with_date(data_frame_2, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "disallowed_words": ["ev"],
                "case_sensitive": True,
                "strip_characters": "",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ValueError,
        match=f"Column {att_colname_map['bd5cce48-424e-4158-a046-c149625e5908'].upper()} datatype is not string.",
    ):
        run_check(spark_session, data_frame_2, rule_json, att_colname_map)


@pytest.mark.usefixtures("data_frame_2", "spark_session")
def test_column_with_int_parameter(data_frame_2, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "disallowed_words": [8],
                "case_sensitive": True,
                "strip_characters": "",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        DatatypeException,
        match="Only string values accepted in parameter array.",
    ):
        run_check(spark_session, data_frame_2, rule_json, att_colname_map)


@pytest.mark.usefixtures("data_frame_2", "spark_session")
def test_column_with_wrong_parameter_type_word(data_frame_2, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "disallowed_words": "ev",
                "case_sensitive": True,
                "strip_characters": "",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ValueError,
        match="Parameter should be an array type.",
    ):
        run_check(spark_session, data_frame_2, rule_json, att_colname_map)


@pytest.mark.usefixtures("data_frame_2", "spark_session")
def test_column_with_wrong_parameter_type_case(data_frame_2, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "disallowed_words": ["ev"],
                "case_sensitive": "Yes",
                "strip_characters": "",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ValueError,
        match="Invalid value for 'case_sensitive' parameter. Only boolean values allowed.",
    ):
        run_check(spark_session, data_frame_2, rule_json, att_colname_map)


@pytest.mark.usefixtures("data_frame_2", "spark_session")
def test_column_with_string_upper_case(data_frame_2, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "disallowed_words": ["ev", "pv"],
                "case_sensitive": True,
                "strip_characters": "",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame_2, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame_2.count()
    assert hits_count == 10
    assert passing_count == 990
    assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame_2", "spark_session")
def test_column_with_wrong_parameter_type_strip(data_frame_2, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "disallowed_words": ["ev"],
                "case_sensitive": True,
                "strip_characters": False,
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ValueError,
        match="Parameter should be a string type.",
    ):
        run_check(spark_session, data_frame_2, rule_json, att_colname_map)


@pytest.mark.usefixtures("data_frame_2", "spark_session")
def test_column_with_parameter_strip(data_frame_2, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {
                "disallowed_words": ["ev"],
                "case_sensitive": True,
                "strip_characters": " ",
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5909",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame_2, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame_2.count()
    assert hits_count == 0
    assert passing_count == 1000
    assert data_frame_2.count() == out_of_scope_recs_count + filtered_recs.count()
