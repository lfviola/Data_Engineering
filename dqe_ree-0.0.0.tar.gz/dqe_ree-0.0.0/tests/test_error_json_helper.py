from dq_engine.rules.custom_exceptions import *  # noqa
from dq_engine.rules.custom_exceptions import get_error_json


def test_get_error_json():
    description = "Column 'test' does not exist in Data Frame, check the validity of the provided column name or data attribute uuid. Available columns are: ['abc', 'def']."
    error_json = get_error_json(
        ColumnNotFoundException(column_name="test", available_columns=["abc", "def"])  # noqa
    )
    assert error_json["description"] == description
    assert error_json["code"] == 501

    error_json = get_error_json(ParameterNotFoundException(message="test"))  # noqa
    assert error_json["description"] == "test"
    assert error_json["code"] == 502

    error_json = get_error_json(Exception())
    assert error_json["description"] == GENERIC_ERROR_MESSAGE  # noqa
    assert error_json["code"] == 500
