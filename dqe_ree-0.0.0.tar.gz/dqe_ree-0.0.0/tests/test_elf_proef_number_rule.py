import pytest
from dq_engine.lib import run_check

att_colname = {
    "bd5cce48-424e-4158-a046-c149625e5901": "8_digits",
    "bd5cce48-424e-4158-a046-c149625e5902": "9_digits",
    "bd5cce48-424e-4158-a046-c149625e5903": "invalid_bsn",
    "bd5cce48-424e-4158-a046-c149625e5904": "invalid_string",
    "bd5cce48-424e-4158-a046-c149625e5905": "date",
    "bd5cce48-424e-4158-a046-c149625e5906": "decimal",
}

rule_name = "expect_column_to_be_valid_BSN"


@pytest.mark.usefixtures("data_frame_3", "spark_session")
def test_column_with_8_digits(data_frame_3, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame_3, rule_json, att_colname
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame_3.count()
    assert hits_count == 446
    assert data_frame_3.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame_3", "spark_session")
def test_column_with_9_digits(data_frame_3, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame_3, rule_json, att_colname
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame_3.count()
    assert hits_count == 15
    assert data_frame_3.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame_3", "spark_session")
def test_column_with_invalid_bsn(data_frame_3, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame_3, rule_json, att_colname
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame_3.count()
    assert hits_count == 457
    assert data_frame_3.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame_3", "spark_session")
def test_column_with_letters(data_frame_3, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame_3, rule_json, att_colname
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame_3.count()
    assert hits_count == 501
    assert hits_count == data_frame_3.count()
    assert data_frame_3.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame_3", "spark_session")
def test_column_with_wrong_length_value(data_frame_3, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame_3, rule_json, att_colname
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame_3.count()
    assert hits_count == 446
    assert data_frame_3.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame_3", "spark_session")
def test_column_with_date(data_frame_3, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ValueError,
        match=f"Column {att_colname['bd5cce48-424e-4158-a046-c149625e5905'].upper()} is not a number or a string.",
    ):
        run_check(spark_session, data_frame_3, rule_json, att_colname)


@pytest.mark.usefixtures("data_frame_3", "spark_session")
def test_column_with_decimal(data_frame_3, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": rule_name,
            "parameters": {},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5906",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        ValueError,
        match=f"Column {att_colname['bd5cce48-424e-4158-a046-c149625e5906'].upper()} is not a number or a string.",
    ):
        run_check(spark_session, data_frame_3, rule_json, att_colname)
