import pytest
from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import ParameterNotFoundException

att_colname = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "phone",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
    "bd5cce48-424e-4158-a046-c149625e5910": "index_2",
    "bd5cce48-424e-4158-a046-c149625e5911": "first_name_capital",
    "bd5cce48-424e-4158-a046-c149625e5912": "first_name_whitespace",
}
accent_characters = "áãâàéêèíîìóöõôòúûùç"
replacement_characters = "aaaaeeeiiiooooouuuc"


class TestColumnValuesToBeEqualToOtherColumnRule:
    rule_name = "expect_column_values_to_be_equal_to_other_column"

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_execution(self, data_frame: DataFrame, spark_session):
        data_frame = data_frame.withColumn(
            "index_2",
            F.when(data_frame["index"].isin(list(range(900, 950))), None).otherwise(
                data_frame["index"]
            ),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert (hits_count + passing_count) == data_frame.count()
        assert hits_count == 50
        assert passing_count == 950
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_execution_null_values(self, data_frame: DataFrame, spark_session):
        data_frame = data_frame.withColumn(
            "index_2",
            F.when(data_frame["index"].isin(list(range(900, 950))), None).otherwise(
                data_frame["index"]
            ),
        ).withColumn(
            "index",
            F.when(data_frame["index"].isin(list(range(900, 950))), None).otherwise(
                data_frame["index"]
            ),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert (hits_count + passing_count) == data_frame.count()
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_execution_empty_string_values(
        self, data_frame: DataFrame, spark_session
    ):
        data_frame = data_frame.withColumn(
            "index_2",
            F.when(data_frame["index"].isin(list(range(900, 950))), "").otherwise(
                data_frame["index"]
            ),
        ).withColumn(
            "index",
            F.when(data_frame["index"].isin(list(range(900, 950))), None).otherwise(
                data_frame["index"]
            ),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert (hits_count + passing_count) == data_frame.count()
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_parameter_validation(self, data_frame: DataFrame, spark_session):
        data_frame = data_frame.withColumn(
            "index_2",
            F.when(data_frame["index"].isin(list(range(900, 950))), None).otherwise(
                data_frame["index"]
            ),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_comparwe": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'column_to_compare' not found.",
        ):
            hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
                spark_session, data_frame, rule_json, att_colname
            )

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_as_filter(self, data_frame: DataFrame, spark_session):
        data_frame = data_frame.withColumn(
            "index_2",
            F.when(data_frame["index"].isin(list(range(900, 950))), None).otherwise(
                data_frame["index"]
            ),
        )
        rule_json = {
            "filters": [
                {
                    "technical_name": self.rule_name,
                    "parameters": {
                        "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                    },
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_recs_count = filtered_recs.count()
        assert (hits_count + passing_count) == filtered_recs_count
        assert filtered_recs_count == 950
        assert hits_count == 0
        assert passing_count == 950

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_case_insensitive(self, data_frame, spark_session):
        data_frame = data_frame.withColumn("first_name_capital", F.upper("first_name"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5911"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_recs_count = filtered_recs.count()

        assert hits_count == 1000
        assert passing_count == 0
        assert hits_count + passing_count == filtered_recs_count
        rule_json_ignore_case = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5911",
                    "ignore_case": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        (
            hits_ignore_case,
            passing_recs_ignore_case,
            filtered_recs_ignore_case,
            out_of_scope_recs_ignore_case,
        ) = run_check(spark_session, data_frame, rule_json_ignore_case, att_colname)
        hits_ignore_case_count = hits_ignore_case.count()
        passing_recs_ignore_case_count = passing_recs_ignore_case.count()
        filtered_recs_ignore_case_count = filtered_recs_ignore_case.count()
        assert hits_ignore_case_count == 0
        assert passing_recs_ignore_case_count == 1000
        assert (
            hits_ignore_case_count + passing_recs_ignore_case_count
            == filtered_recs_ignore_case_count
        )

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_trim_whitespace(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "first_name_whitespace",
            F.concat_ws("", data_frame["first_name"], F.lit("     ")),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5912"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_recs_count = filtered_recs.count()

        assert hits_count == 1000
        assert passing_count == 0
        assert hits_count + passing_count == filtered_recs_count
        rule_json_trim_whitespace = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5912",
                    "trim_whitespace": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        (
            hits_trim_whitespace,
            passing_recs_trim_whitespace,
            filtered_recs_trim_whitespace,
            out_of_scope_recs_trim_whitespace,
        ) = run_check(spark_session, data_frame, rule_json_trim_whitespace, att_colname)
        hits_trim_whitespace_count = hits_trim_whitespace.count()
        passing_recs_trim_whitespace_count = passing_recs_trim_whitespace.count()
        filtered_recs_trim_whitespace_count = filtered_recs_trim_whitespace.count()
        assert hits_trim_whitespace_count == 0
        assert passing_recs_trim_whitespace_count == 1000
        assert (
            hits_trim_whitespace_count + passing_recs_trim_whitespace_count
            == filtered_recs_trim_whitespace_count
        )

    @pytest.mark.usefixtures("dataframe_dates", "spark_session")
    def test_dataframe_dates(self, dataframe_dates, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5902"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        att_colname_map = {
            "bd5cce48-424e-4158-a046-c149625e5901": "timestamp_date",
            "bd5cce48-424e-4158-a046-c149625e5902": "string_date",
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dataframe_dates, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_recs_count = filtered_recs.count()
        assert (hits_count + passing_count) == filtered_recs_count
        assert hits_count == 19
        assert passing_count == 0

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_dataframe_accents(self, data_frame: DataFrame, spark_session):
        data_frame = data_frame.withColumn(
            "first_name_accent",
            F.translate("first_name", replacement_characters, accent_characters),
        )
        att_colname_map = {
            "bd5cce48-424e-4158-a046-c149625e5901": "first_name",
            "bd5cce48-424e-4158-a046-c149625e5902": "first_name_accent",
        }
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5902",
                    "ignore_accents": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_recs_count = filtered_recs.count()
        assert (hits_count + passing_count) == filtered_recs_count
        assert hits_count == 0
        assert passing_count == 1000


class TestColumnValuesToBeNotEqualToOtherColumnRule:
    rule_name = "expect_column_values_to_be_not_equal_to_other_column"

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_execution(self, data_frame: DataFrame, spark_session):
        data_frame = data_frame.withColumn(
            "index_2",
            F.when(data_frame["index"].isin(list(range(900, 950))), 1).otherwise(
                data_frame["index"]
            ),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert (hits_count + passing_count) == data_frame.count()
        assert hits_count == 950
        assert passing_count == 50
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_execution_null_values(self, data_frame: DataFrame, spark_session):
        data_frame = data_frame.withColumn(
            "index_2",
            F.when(data_frame["index"].isin(list(range(900, 950))), None).otherwise(
                data_frame["index"]
            ),
        ).withColumn(
            "index",
            F.when(data_frame["index"].isin(list(range(900, 950))), None).otherwise(
                data_frame["index"]
            ),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert (hits_count + passing_count) == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_execution_empty_string_values(
        self, data_frame: DataFrame, spark_session
    ):
        data_frame = data_frame.withColumn(
            "index_2",
            F.when(data_frame["index"].isin(list(range(900, 950))), "").otherwise(
                data_frame["index"]
            ),
        ).withColumn(
            "index",
            F.when(data_frame["index"].isin(list(range(900, 950))), None).otherwise(
                data_frame["index"]
            ),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert (hits_count + passing_count) == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_rule_as_filter(self, data_frame: DataFrame, spark_session):
        data_frame = data_frame.withColumn(
            "index_2",
            F.when(data_frame["index"].isin(list(range(900, 950))), 1).otherwise(
                data_frame["index"]
            ),
        )
        rule_json = {
            "filters": [
                {
                    "technical_name": self.rule_name,
                    "parameters": {
                        "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                    },
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        filtered_recs_count = filtered_recs.count()
        assert (hits_count + passing_count) == filtered_recs_count
        assert hits_count == 0
        assert passing_count == 50
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs_count

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_case_insensitive(self, data_frame, spark_session):
        data_frame = data_frame.withColumn("first_name_capital", F.upper("first_name"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5911",
                    "ignore_case": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_recs_count = filtered_recs.count()

        assert hits_count == 1000
        assert passing_count == 0
        assert hits_count + passing_count == filtered_recs_count
        rule_json_ignore_case = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5911"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        (
            hits_ignore_case,
            passing_recs_ignore_case,
            filtered_recs_ignore_case,
            out_of_scope_recs_ignore_case,
        ) = run_check(spark_session, data_frame, rule_json_ignore_case, att_colname)
        hits_ignore_case_count = hits_ignore_case.count()
        passing_recs_ignore_case_count = passing_recs_ignore_case.count()
        filtered_recs_ignore_case_count = filtered_recs_ignore_case.count()
        assert hits_ignore_case_count == 0
        assert passing_recs_ignore_case_count == 1000
        assert (
            hits_ignore_case_count + passing_recs_ignore_case_count
            == filtered_recs_ignore_case_count
        )

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_trim_whitespace(self, data_frame, spark_session):
        data_frame = data_frame.withColumn(
            "first_name_whitespace",
            F.concat_ws("", data_frame["first_name"], F.lit("     ")),
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5912",
                    "trim_whitespace": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_recs_count = filtered_recs.count()

        assert hits_count == 1000
        assert passing_count == 0
        assert hits_count + passing_count == filtered_recs_count
        rule_json_trim_whitespace = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5912",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        (
            hits_trim_whitespace,
            passing_recs_trim_whitespace,
            filtered_recs_trim_whitespace,
            out_of_scope_recs_trim_whitespace,
        ) = run_check(spark_session, data_frame, rule_json_trim_whitespace, att_colname)
        hits_trim_whitespace_count = hits_trim_whitespace.count()
        passing_recs_trim_whitespace_count = passing_recs_trim_whitespace.count()
        filtered_recs_trim_whitespace_count = filtered_recs_trim_whitespace.count()
        assert hits_trim_whitespace_count == 0
        assert passing_recs_trim_whitespace_count == 1000
        assert (
            hits_trim_whitespace_count + passing_recs_trim_whitespace_count
            == filtered_recs_trim_whitespace_count
        )

    @pytest.mark.usefixtures("dataframe_dates", "spark_session")
    def test_dataframe_dates(self, dataframe_dates, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5902"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        att_colname_map = {
            "bd5cce48-424e-4158-a046-c149625e5901": "timestamp_date",
            "bd5cce48-424e-4158-a046-c149625e5902": "string_date",
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, dataframe_dates, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_recs_count = filtered_recs.count()
        assert (hits_count + passing_count) == filtered_recs_count
        assert hits_count == 0
        assert passing_count == 19

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_dataframe_accents(self, data_frame: DataFrame, spark_session):
        data_frame = data_frame.withColumn(
            "first_name_accent",
            F.translate("first_name", replacement_characters, accent_characters),
        )
        att_colname_map = {
            "bd5cce48-424e-4158-a046-c149625e5901": "first_name",
            "bd5cce48-424e-4158-a046-c149625e5902": "first_name_accent",
        }
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5902",
                    "ignore_accents": True,
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_recs_count = filtered_recs.count()
        assert (hits_count + passing_count) == filtered_recs_count
        assert hits_count == 1000
        assert passing_count == 0
