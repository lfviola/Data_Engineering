from copy import deepcopy

import pytest
from dq_engine.lib import run_check
from dq_engine.rules.rule_column_equality import (
    expect_column_values_to_be_equal_to_other_column,
)
from dq_engine.rules.rule_completeness import expect_column_values_to_not_be_null
from dq_engine.rules.rule_equality import expect_column_values_to_be_equal_to_value
from dq_engine.rules.rule_uniqueness import expect_column_values_to_be_unique


def get_att_colname_map(data_attribute_df) -> dict[int, str]:
    att_colname_map = {
        row.data_attribute_uuid: row.column_name.upper()
        for row in data_attribute_df.collect()
    }
    return att_colname_map


@pytest.mark.usefixtures("spark_session", "dq_dataset_df", "dial_metadata_df")
def test_rule_column_equality_on_dq_dataset(
    spark_session, dq_dataset_df, dial_metadata_df
) -> None:
    """tests dq dataset parameters are being used to override the attribute parameters when provided"""
    dq_dataset_df = dq_dataset_df.toDF(*[c.upper() for c in dq_dataset_df.columns])
    check_json = {
        "dq_check_id": "12345678-90ab-cdef-1234-567890abcdef",
        "rule": {
            "technical_name": "expect_column_values_to_be_equal_to_other_column",
            "parameters": {
                "column_to_compare": "2c604f1e-392a-43b4-86fa-7c93b21e3124",
            },
            "data_attribute": {
                "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3124",
                "data_attribute_source": "dq_dataset",
            },
            "dq_dataset_data_attribute": {
                "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3123"
            },
        },
        "status_id": "P",
        "filters": [
            {
                "technical_name": "expect_column_values_to_be_equal_to_value",
                "parameters": {
                    "value": "Biomedical engineer",
                },
                "data_attribute": {
                    "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3138",
                    "data_attribute_source": "dq_dataset",
                },
                "dq_dataset_data_attribute": {
                    "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3139"
                },
            }
        ],
    }
    att_colname_map = get_att_colname_map(dial_metadata_df)
    parameters = deepcopy(check_json["rule"]["parameters"])
    rule_obj = expect_column_values_to_be_equal_to_other_column(
        spark=spark_session,
        data_attribute_uuid=check_json["rule"]["data_attribute"]["data_attribute_uuid"],
        parameters=parameters,
        att_colname_map=att_colname_map,
        dq_dataset_data_attribute_uuid=check_json["rule"]["dq_dataset_data_attribute"][
            "data_attribute_uuid"
        ],
    )

    # testing if the column names are overriden successfully by dq dataset parameters in the check
    assert rule_obj.column_name == "id".upper()
    assert rule_obj.column_to_compare == "user_id".upper()
    assert (
        rule_obj.column_name
        != att_colname_map[check_json["rule"]["data_attribute"]["data_attribute_uuid"]]
    )

    filter_obj = expect_column_values_to_be_equal_to_value(
        spark=spark_session,
        data_attribute_uuid=check_json["filters"][0]["data_attribute"][
            "data_attribute_uuid"
        ],
        parameters=deepcopy(check_json["filters"][0]["parameters"]),
        att_colname_map=att_colname_map,
        dq_dataset_data_attribute_uuid=check_json["filters"][0][
            "dq_dataset_data_attribute"
        ]["data_attribute_uuid"],
    )

    # testing if the column names are overriden successfully by dq dataset parameters in the filter part of check
    assert filter_obj.column_name == "job_title".upper()
    assert (
        filter_obj.column_name
        != att_colname_map[
            check_json["filters"][0]["data_attribute"]["data_attribute_uuid"]
        ]
    )

    # testing overall check execution
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, dq_dataset_df, check_json, att_colname_map
    )
    assert hits.count() + passing_recs.count() == filtered_recs.count()
    assert hits.count() == 1
    assert passing_recs.count() == 0
    assert filtered_recs.count() == 1
    assert dq_dataset_df.count() == out_of_scope_recs.count() + filtered_recs.count()


@pytest.mark.usefixtures("spark_session", "dq_dataset_df", "dial_metadata_df")
def test_rule_values_to_be_not_null_on_dq_dataset(
    spark_session, dq_dataset_df, dial_metadata_df
) -> None:
    dq_dataset_df = dq_dataset_df.toDF(*[c.upper() for c in dq_dataset_df.columns])
    att_colname_map = get_att_colname_map(dial_metadata_df)
    check_json = {
        "dq_check_id": "12345678-90ab-1234-567890abcdef",
        "rule": {
            "data_attribute": {
                "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3134",
                "data_attribute_source": "dq_dataset",
            },
            "dq_dataset_data_attribute": {
                "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3133"
            },
            "parameters": {},
            "technical_name": "expect_column_values_to_not_be_null",
        },
        "status_id": "P",
        "filters": [
            {
                "technical_name": "expect_column_values_to_be_equal_to_value",
                "parameters": {
                    "value": "Counselling psychologist",
                },
                "data_attribute": {
                    "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3138",
                    "data_attribute_source": "dq_dataset",
                },
                "dq_dataset_data_attribute": {
                    "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3139"
                },
            }
        ],
    }

    parameters = deepcopy(check_json["rule"]["parameters"])
    rule_obj = expect_column_values_to_not_be_null(
        spark=spark_session,
        data_attribute_uuid=check_json["rule"]["data_attribute"]["data_attribute_uuid"],
        parameters=parameters,
        att_colname_map=att_colname_map,
        dq_dataset_data_attribute_uuid=check_json["rule"]["dq_dataset_data_attribute"][
            "data_attribute_uuid"
        ],
    )

    # testing if the column names are overriden successfully by dq dataset parameters in the check
    assert rule_obj.column_name == "given_name".upper()
    assert (
        rule_obj.column_name
        != att_colname_map[check_json["rule"]["data_attribute"]["data_attribute_uuid"]]
    )

    filter_obj = expect_column_values_to_be_equal_to_value(
        spark=spark_session,
        data_attribute_uuid=check_json["filters"][0]["data_attribute"][
            "data_attribute_uuid"
        ],
        parameters=deepcopy(check_json["filters"][0]["parameters"]),
        att_colname_map=att_colname_map,
        dq_dataset_data_attribute_uuid=check_json["filters"][0][
            "dq_dataset_data_attribute"
        ]["data_attribute_uuid"],
    )

    # testing if the column names are overriden successfully by dq dataset parameters in the filter part of check
    assert filter_obj.column_name == "job_title".upper()
    assert (
        filter_obj.column_name
        != att_colname_map[
            check_json["filters"][0]["data_attribute"]["data_attribute_uuid"]
        ]
    )

    # testing overall check execution
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, dq_dataset_df, check_json, att_colname_map
    )
    assert hits.count() + passing_recs.count() == filtered_recs.count()
    assert hits.count() == 0
    assert passing_recs.count() == 1
    assert filtered_recs.count() == 1
    assert dq_dataset_df.count() == out_of_scope_recs.count() + filtered_recs.count()


@pytest.mark.usefixtures("spark_session", "dq_dataset_df", "dial_metadata_df")
def test_rule_column_values_to_be_equal_to_other_column_on_dq_dataset(
    spark_session, dq_dataset_df, dial_metadata_df
) -> None:
    dq_dataset_df = dq_dataset_df.toDF(*[c.upper() for c in dq_dataset_df.columns])
    att_colname_map = get_att_colname_map(dial_metadata_df)
    check_json = {
        "dq_check_id": "12345678-90ab-cdef-1234-567890abcdef2",
        "rule": {
            "technical_name": "expect_column_values_to_be_equal_to_other_column",
            "data_attribute": {
                "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3124",
                "data_attribute_source": "dq_dataset",
            },
            "dq_dataset_data_attribute": {
                "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3123",
            },
            "parameters": {
                "column_to_compare": "2c604f1e-392a-43b4-86fa-7c93b21e3124",
            },
        },
        "status_id": "P",
        "filters": [],
    }
    parameters = deepcopy(check_json["rule"]["parameters"])
    rule_obj = expect_column_values_to_be_equal_to_other_column(
        spark=spark_session,
        data_attribute_uuid=check_json["rule"]["data_attribute"]["data_attribute_uuid"],
        parameters=parameters,
        att_colname_map=att_colname_map,
        dq_dataset_data_attribute_uuid=check_json["rule"]["dq_dataset_data_attribute"][
            "data_attribute_uuid"
        ],
    )

    # testing if the column names are overriden successfully by dq dataset parameters in the check
    assert rule_obj.column_name == "id".upper()
    assert rule_obj.column_to_compare == "user_id".upper()
    assert rule_obj.column_name != att_colname_map.get(
        check_json["rule"]["data_attribute"]["data_attribute_uuid"]
    )

    # check 4, rule: expect_column_values_to_be_equal_to_other_column without filer
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, dq_dataset_df, check_json, att_colname_map
    )
    assert hits.count() + passing_recs.count() == filtered_recs.count()
    assert hits.count() == 11
    assert passing_recs.count() == 0
    assert filtered_recs.count() == 11
    assert dq_dataset_df.count() == out_of_scope_recs.count() + filtered_recs.count()


@pytest.mark.usefixtures("spark_session", "dq_dataset_df", "dial_metadata_df")
def test_rule_column_values_to_be_unique_on_dq_dataset(
    spark_session, dq_dataset_df, dial_metadata_df
) -> None:
    dq_dataset_df = dq_dataset_df.toDF(*[c.upper() for c in dq_dataset_df.columns])
    att_colname_map = get_att_colname_map(dial_metadata_df)
    check_json = {
        "dq_check_id": "12345678-90ab-cdef-1234-567890abcdef2",
        "rule": {
            "technical_name": "expect_column_values_to_be_unique",
            "data_attribute": {
                "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3124",
                "data_attribute_source": "dq_dataset",
            },
            "dq_dataset_data_attribute": {
                "data_attribute_uuid": "2c604f1e-392a-43b4-86fa-7c93b21e3123"
            },
            "parameters": {
                "additional_attributes": [
                    "2c604f1e-392a-43b4-86fa-7c93b21e3124",
                    "2c604f1e-392a-43b4-86fa-7c93b21e3123",
                ],
            },
        },
        "status_id": "P",
        "filters": [],
    }

    parameters = deepcopy(check_json["rule"]["parameters"])
    rule_obj = expect_column_values_to_be_unique(
        spark=spark_session,
        data_attribute_uuid=check_json["rule"]["data_attribute"]["data_attribute_uuid"],
        parameters=parameters,
        att_colname_map=att_colname_map,
        dq_dataset_data_attribute_uuid=check_json["rule"]["dq_dataset_data_attribute"][
            "data_attribute_uuid"
        ],
    )

    # testing if the column names are overriden successfully by dq dataset parameters in the check
    assert rule_obj.column_name == "id".upper()
    assert set(rule_obj.additional_attributes) == {"id".upper(), "user_id".upper()}
    assert (
        rule_obj.column_name
        != att_colname_map[check_json["rule"]["data_attribute"]["data_attribute_uuid"]]
    )

    # check 5, rule: expect_column_values_to_be_unique without filter
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, dq_dataset_df, check_json, att_colname_map
    )
    assert hits.count() + passing_recs.count() == filtered_recs.count()
    assert hits.count() == 0
    assert passing_recs.count() == 11
    assert filtered_recs.count() == 11
    assert dq_dataset_df.count() == out_of_scope_recs.count() + filtered_recs.count()
