import datetime

import pytest

from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import ParameterNotFoundException

att_col_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "phone",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
    "bd5cce48-424e-4158-a046-c149625e5910": "float_col",
}


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_on_operator_less_than(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "less than",
                "number_of_days": 100,
            },
        },
        "filters": [],
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, param_json, att_col_map
    )
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()
    assert (hits.count() + passing_recs.count()) == data_frame.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_on_operator_greater_than(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "greater than",
                "number_of_days": 100,
            },
        },
        "filters": [],
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, param_json, att_col_map
    )
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert (hits.count() + passing_recs.count()) == data_frame.count()
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_on_operator_is(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "is",
                "number_of_days": 100,
            },
        },
        "filters": [],
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, param_json, att_col_map
    )
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert (hits.count() + passing_recs.count()) == data_frame.count()
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_on_operator_is_not(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "is not",
                "number_of_days": 100,
            },
        },
        "filters": [],
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, param_json, att_col_map
    )
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert (hits.count() + passing_recs.count()) == data_frame.count()
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_on_operator_less_than_or_equal(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "less than or equal",
                "number_of_days": 100,
            },
        },
        "filters": [],
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, param_json, att_col_map
    )
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert (hits.count() + passing_recs.count()) == data_frame.count()
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_on_operator_greater_than_or_equal(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "greater than or equal",
                "number_of_days": 100,
            },
        },
        "filters": [],
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, param_json, att_col_map
    )
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert (hits.count() + passing_recs.count()) == data_frame.count()
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_with_wrong_comparison_parameter(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "isnt",
                "number_of_days": 100,
            },
        },
        "filters": [],
    }
    with pytest.raises(
        ValueError,
    ):
        run_check(spark_session, data_frame, param_json, att_col_map)


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_with_no_day_diff(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "is",
                "number_of_days": "",
            },
        },
        "filters": [],
    }
    with pytest.raises(
        ParameterNotFoundException,
        match="Required parameter 'number_of_days' not found.",
    ):
        run_check(spark_session, data_frame, param_json, att_col_map)


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_with_incorrect_day_diff_value(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "is",
                "number_of_days": "--19",
            },
        },
        "filters": [],
    }
    with pytest.raises(
        ValueError, match="Invalid value for parameter 'number_of_days'"
    ):
        run_check(spark_session, data_frame, param_json, att_col_map)


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_with_incorrect_day_diff_type(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "is",
                "number_of_days": 10.0,
            },
        },
        "filters": [],
    }
    with pytest.raises(ValueError, match="Invalid type for parameter 'number_of_days'"):
        run_check(spark_session, data_frame, param_json, att_col_map)


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_with_negative_day_diff(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "is",
                "number_of_days": -19,
            },
        },
        "filters": [],
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, param_json, att_col_map
    )

    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 1000
    assert passing_count == 0
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_with_wrong_datatype(data_frame, spark_session):
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "is",
                "date_format": "yyyyMMdd",
                "number_of_days": 100,
            },
        },
        "filters": [],
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, param_json, att_col_map
    )

    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 1000
    assert passing_count == 0
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_days_difference_zero(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("date")
    )
    snapshot_date = datetime.date(2014, 1, 28)
    param_json = {
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "snapshot_date": snapshot_date,
                "operator": "is",
                "number_of_days": 0,
            },
        },
        "filters": [],
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, param_json, att_col_map
    )
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert (hits.count() + passing_recs.count()) == filtered_recs.count()
    assert hits.count() == 1000
    assert hits.columns == passing_recs.columns
    assert passing_recs.columns == filtered_recs.columns
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_comparing_against_days_difference(data_frame, spark_session):
    snapshot_date = datetime.date(2024, 9, 12)
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "parameters": {
                "number_of_days": 0,
                "operator": "less than or equal",
                "date_format": "y-M-d",
                "snapshot_date": snapshot_date,
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_col_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 1000
    assert passing_count == 0
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_comparing_against_days_differenc_incorrect_format(data_frame, spark_session):
    data_frame = data_frame.withColumn(
        "date_of_birth", data_frame["date_of_birth"].cast("string")
    )
    snapshot_date = datetime.date(2024, 9, 12)
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "must_be_compared_against_days_difference_from_snapshot_date",
            "parameters": {
                "number_of_days": 0,
                "operator": "less than or equal",
                "date_format": "y/M/d",
                "snapshot_date": snapshot_date,
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_col_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 1000
    assert passing_count == 0
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()
