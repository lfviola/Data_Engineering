import pytest
from pyspark.sql import functions as F, DataFrame, SparkSession
from datetime import datetime
import types
from unittest.mock import create_autospec
from pyspark.sql.functions import regexp_replace
from pyspark.sql.types import IntegerType, LongType, DecimalType, DoubleType, FloatType

from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import (
    AttributeIDNotFoundException,
    InvalidParameterException,
    ParameterNotFoundException,
)
from dq_engine.rules.rule_date_column_comparison import (
    compare_column_dates_difference_with_period,
    DateColumnComparisonRule,
)

# Create SparkSession from builder

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "phone",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
    "bd5cce48-424e-4158-a046-c149625e5910": "test_date_compare",
    "f47ac10b-58cc-4372-a567-0e02b2c3d479": "days_difference",
}


class TestDateColumnComparisonRule:
    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_invalid_pre_process_output_format(
        self, date_comparison_data_frame, spark_session
    ):
        mock_instance = create_autospec(DateColumnComparisonRule, instance=True)
        mock_instance.pre_process = types.MethodType(
            DateColumnComparisonRule.pre_process, mock_instance
        )
        mock_instance.column_name = "date_of_birth"
        mock_instance.column_to_compare = "test_date_compare"

        with pytest.raises(
            ValueError, match="Internal error: Incorrect output type defined"
        ):
            mock_instance.pre_process(
                data_frame=date_comparison_data_frame, output_type="unknown"
            )


class TestColumnDatesToBeGreaterThanOtherColumn:
    rule_name = "expect_column_dates_to_be_greater_than_other_column"

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_string_type_date_columns(
        self, date_comparison_data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 9
        assert passing_count == 2
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.parametrize(
        "datatype_str,datatype",
        [
            ("int", IntegerType()),
            ("long", LongType()),
            ("double", DoubleType()),
            ("decimal", DecimalType(10, 2)),
            ("float", FloatType()),
        ],
    )
    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_numeric_type_columns(
        self, date_comparison_data_frame, spark_session, datatype_str, datatype
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            f"date_of_birth_{datatype_str}",
            regexp_replace("date_of_birth", "-", "").cast(datatype),
        ).withColumn(
            f"test_date_compare_{datatype_str}",
            regexp_replace("test_date_compare", "-", "").cast(datatype),
        )
        colname_map = {}
        colname_map["bd5cce48-424e-4158-a046-c149625e5910"] = (
            f"test_date_compare_{datatype_str}"
        )
        colname_map["bd5cce48-424e-4158-a046-c149625e5908"] = (
            f"date_of_birth_{datatype_str}"
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "main_date_format": "yyyyMMdd",
                    "comparison_date_format": "ddMMyyyy",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 9
        assert passing_count == 2
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_date_type_columns(self, date_comparison_data_frame, spark_session):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        ).withColumn("test_date_compare", F.to_date("test_date_compare", "d-M-y"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 9
        assert passing_count == 2
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_other_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'comparison_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_main_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "test_date_compare", F.to_date("test_date_compare", "d-M-y")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'main_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_with_wrong_att_uuid(self, date_comparison_data_frame, spark_session):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "test_date_compare", F.to_date("test_date_compare", "d-M-y")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5911"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            AttributeIDNotFoundException,
            match="attribute bd5cce48-424e-4158-a046-c149625e5911 could not be mapped to a column name on the dataset",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )


class TestColumnDatesToBeEqualorGreaterThanOtherColumn:
    rule_name = "expect_column_dates_to_be_equal_or_greater_than_other_column"

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_string_type_date_columns(
        self, date_comparison_data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 8
        assert passing_count == 3
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_date_type_columns(self, date_comparison_data_frame, spark_session):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        ).withColumn("test_date_compare", F.to_date("test_date_compare", "d-M-y"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 8
        assert passing_count == 3
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_other_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'comparison_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_main_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "test_date_compare", F.to_date("test_date_compare", "d-M-y")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'main_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_with_wrong_att_id(self, date_comparison_data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5913"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            AttributeIDNotFoundException,
            match="attribute bd5cce48-424e-4158-a046-c149625e5913 could not be mapped to a column name on the dataset",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )


class TestColumnDatesToBeLessThanOtherColumn:
    rule_name = "expect_column_dates_to_be_less_than_other_column"

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_string_type_date_columns(
        self, date_comparison_data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 6
        assert passing_count == 5
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_date_type_columns(self, date_comparison_data_frame, spark_session):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        ).withColumn("test_date_compare", F.to_date("test_date_compare", "d-M-y"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 6
        assert passing_count == 5
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_other_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'comparison_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_main_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "test_date_compare", F.to_date("test_date_compare", "d-M-y")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'main_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_with_wrong_att_id(self, date_comparison_data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5945"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            AttributeIDNotFoundException,
            match="attribute bd5cce48-424e-4158-a046-c149625e5945 could not be mapped to a column name on the dataset",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )


class TestColumnDatesToBeEqualOrLessThanOtherColumn:
    rule_name = "expect_column_dates_to_be_equal_or_less_than_other_column"

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_string_type_date_columns(
        self, date_comparison_data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 5
        assert passing_count == 6
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_date_type_columns(self, date_comparison_data_frame, spark_session):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        ).withColumn("test_date_compare", F.to_date("test_date_compare", "d-M-y"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 5
        assert passing_count == 6
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_other_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'comparison_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_main_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "test_date_compare", F.to_date("test_date_compare", "d-M-y")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'main_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_with_wrong_att_id(self, date_comparison_data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5923"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            AttributeIDNotFoundException,
            match="attribute bd5cce48-424e-4158-a046-c149625e5923 could not be mapped to a column name on the dataset",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )


class TestColumnDatesToBeEqualToOtherColumn:
    rule_name = "expect_column_dates_to_be_equal_to_other_column"

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_string_type_date_columns(
        self, date_comparison_data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 10
        assert passing_count == 1
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_date_type_columns(self, date_comparison_data_frame, spark_session):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        ).withColumn("test_date_compare", F.to_date("test_date_compare", "d-M-y"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 10
        assert passing_count == 1
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_other_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'comparison_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_main_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "test_date_compare", F.to_date("test_date_compare", "d-M-y")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'main_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_with_wrong_att_id(self, date_comparison_data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5933"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            AttributeIDNotFoundException,
            match="attribute bd5cce48-424e-4158-a046-c149625e5933 could not be mapped to a column name on the dataset",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )


class TestColumnDatesToBeNotEqualToOtherColumn:
    rule_name = "expect_column_dates_to_be_not_equal_to_other_column"

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_string_type_date_columns(
        self, date_comparison_data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 4
        assert passing_count == 7
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_date_type_columns(self, date_comparison_data_frame, spark_session):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        ).withColumn("test_date_compare", F.to_date("test_date_compare", "d-M-y"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 4
        assert passing_count == 7
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_other_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'comparison_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_on_one_string_date_col_and_main_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "test_date_compare", F.to_date("test_date_compare", "d-M-y")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'main_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_with_wrong_att_id(self, date_comparison_data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5942"
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            AttributeIDNotFoundException,
            match="attribute bd5cce48-424e-4158-a046-c149625e5942 could not be mapped to a column name on the dataset",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )


class TestColumnDatesDifferencePeriodComparison:
    rule_name = "compare_column_dates_difference_with_period"

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_period_difference_on_string_type_date_columns(
        self, date_comparison_data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "d-M-y",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5908",
                    "comparison_date_format": "y-M-d",
                    "operator": "greater than",
                    "period": "P5DT30M",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()

        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 4
        assert passing_count == 7
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_period_difference_on_string_type_date_columns_long_difference(
        self, date_comparison_data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "d-M-y",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5908",
                    "comparison_date_format": "y-M-d",
                    "operator": "greater than",
                    "period": "P1Y3M5DT30M",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()

        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 4
        assert passing_count == 7
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_period_difference_on_date_type_columns(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        ).withColumn("test_date_compare", F.to_date("test_date_compare", "d-M-y"))
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5908",
                    "operator": "greater than",
                    "period": "P5DT30M",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 4
        assert passing_count == 7
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_period_difference_on_one_string_date_col_and_other_datetype_col(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "d-M-y",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5908",
                    "operator": "greater than",
                    "period": "P5DT30M",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5910",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 4
        assert passing_count == 7
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_period_difference_on_one_string_date_col_and_other_datetype_col_negative(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_date("date_of_birth", "y-M-d")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "operator": "greater than",
                    "period": "PT1H",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'comparison_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_period_difference_on_one_string_date_col_and_other_datetype_col_negative_two(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "test_date_compare", F.to_date("test_date_compare", "d-M-y")
        )
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "operator": "greater than",
                    "period": "PT1H",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException,
            match="Required parameter 'main_date_format' not found. This parameter is required when the date is not a date value.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_period_difference_negative_period(
        self, date_comparison_data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "operator": "greater than",
                    "period": "period",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            InvalidParameterException,
            match="Period 'period' does not adhere to the ISO 8601 duration format. Please update this parameter according to https://www.digi.com/resources/documentation/digidocs//90001488-13/reference/r_iso_8601_duration_format.htm",
        ):
            run_check(
                spark_session, date_comparison_data_frame, rule_json, att_colname_map
            )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_period_difference_on_one_string_date_col_and_other_timestamp_col_positive(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "date_of_birth", F.to_timestamp("date_of_birth", "y-M-d")
        )
        new_val = (
            "12",
            "44FAA9C3CE8DB2C",
            "Dasey",
            "Ayala",
            "Male",
            "dcantu@example.com",
            "8629884038",
            datetime.strptime("2022-06-14 00:50:00", "%Y-%m-%d %H:%M:%S"),
            "Scientist, water quality",
            "14-06-2022",
            8,
        )
        newRow = spark_session.createDataFrame(
            [new_val], date_comparison_data_frame.columns
        )
        date_comparison_data_frame = date_comparison_data_frame.union(newRow)

        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "comparison_date_format": "d-M-y",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "operator": "greater than",
                    "period": "PT1H",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )

        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 5
        assert passing_count == 7
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    @pytest.mark.usefixtures("date_comparison_data_frame", "spark_session")
    def test_period_difference_on_one_timestamp_col_and_other_string_col_positive(
        self, date_comparison_data_frame, spark_session
    ):
        date_comparison_data_frame = date_comparison_data_frame.withColumn(
            "test_date_compare", F.to_timestamp("test_date_compare", "d-M-y")
        )
        new_val = (
            "12",
            "44FAA9C3CE8DB2C",
            "Dasey",
            "Ayala",
            "Male",
            "dcantu@example.com",
            "8629884038",
            "2022-06-14",
            "Scientist, water quality",
            datetime.strptime("2022-06-14 00:50:00", "%Y-%m-%d %H:%M:%S"),
            8,
        )
        newRow = spark_session.createDataFrame(
            [new_val], schema=date_comparison_data_frame.columns
        )
        date_comparison_data_frame = date_comparison_data_frame.union(newRow)

        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "operator": "greater than",
                    "period": "PT1H",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, rule_json, att_colname_map
        )
        print(hits.show())
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == date_comparison_data_frame.count()
        assert hits_count == 5
        assert passing_count == 7
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs_count + filtered_recs.count()
        )

    def test_period_durations(self):
        test_rule = compare_column_dates_difference_with_period
        assert test_rule.parse_period("P3Y6M4DT12H30M5S") == 110842205
        assert test_rule.parse_period("P4DT12H30M") == 390600
        assert test_rule.parse_period("P6M") == 15778800
        assert test_rule.parse_period("PT1H") == 3600
        assert test_rule.parse_period("P1Y2M3DT4H5M6S") == 37091106

    def test_valid_iso_durations(self):
        test_rule = compare_column_dates_difference_with_period
        assert test_rule.is_iso8601_duration("P3Y6M4DT12H30M5S")
        assert test_rule.is_iso8601_duration("P4DT12H30M")
        assert test_rule.is_iso8601_duration("P6M")
        assert test_rule.is_iso8601_duration("PT1H")
        assert test_rule.is_iso8601_duration("P1Y2M3DT4H5M6S")

    def test_invalid_iso_durations(self):
        test_rule = compare_column_dates_difference_with_period
        assert not test_rule.is_iso8601_duration("3Y6M4DT12H30M5S")
        assert not test_rule.is_iso8601_duration("P-3Y6M4DT12H30M5S")
        assert not test_rule.is_iso8601_duration("P3Y6M4DT12H30M5")
        assert not test_rule.is_iso8601_duration("P3Y6M4D12H30M5S")
        assert not test_rule.is_iso8601_duration("P3Y6M4DT12H30M5SZ")


@pytest.mark.usefixtures("spark_session", "date_comparison_data_frame")
class TestDaysDifferenceDateColumnComparisonRule:
    rule_name = "DaysDifferenceDateColumnComparisonRule"

    def test_is_operator(
        self,
        spark_session: SparkSession,
        date_comparison_data_frame: DataFrame,
    ):
        """
        Successful test case.
        """
        check_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                    "days_difference_column": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
                    "comparison_type": "is",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, check_json, att_colname_map
        )
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == date_comparison_data_frame.count()
        assert passing_recs.count() == 3

    def test_is_not_operator(
        self,
        spark_session: SparkSession,
        date_comparison_data_frame: DataFrame,
    ):
        check_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                    "days_difference_column": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
                    "comparison_type": "is not",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, check_json, att_colname_map
        )
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == date_comparison_data_frame.count()
        assert passing_recs.count() == 4

    def test_less_than_or_equal_operator(
        self,
        spark_session: SparkSession,
        date_comparison_data_frame: DataFrame,
    ):
        check_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                    "days_difference_column": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
                    "comparison_type": "less than or equal",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, check_json, att_colname_map
        )
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == date_comparison_data_frame.count()
        assert passing_recs.count() == 6

    def test_less_than_operator(
        self,
        spark_session: SparkSession,
        date_comparison_data_frame: DataFrame,
    ):
        check_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                    "days_difference_column": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
                    "comparison_type": "less than",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, check_json, att_colname_map
        )
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == date_comparison_data_frame.count()
        assert passing_recs.count() == 3

    def test_greater_than_operator(
        self,
        spark_session: SparkSession,
        date_comparison_data_frame: DataFrame,
    ):
        check_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                    "days_difference_column": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
                    "comparison_type": "greater than",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, check_json, att_colname_map
        )
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == date_comparison_data_frame.count()
        assert passing_recs.count() == 1

    def test_greater_than_or_equal_operator(
        self,
        spark_session: SparkSession,
        date_comparison_data_frame: DataFrame,
    ):
        check_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                    "days_difference_column": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
                    "comparison_type": "greater than or equal",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, date_comparison_data_frame, check_json, att_colname_map
        )
        assert (
            date_comparison_data_frame.count()
            == out_of_scope_recs.count() + filtered_recs.count()
        )
        assert hits.count() + passing_recs.count() == date_comparison_data_frame.count()
        assert passing_recs.count() == 4

    def test_required_parameter_days_difference_column_not_found(
        self, spark_session: SparkSession, date_comparison_data_frame: DataFrame
    ):
        check_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                    "comparison_type": "is",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        with pytest.raises(
            ParameterNotFoundException,
            match=r"Required parameter 'days_difference_column' not found.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, check_json, att_colname_map
            )

    def test_required_parameter_column_to_compare_not_found(
        self, spark_session: SparkSession, date_comparison_data_frame: DataFrame
    ):
        check_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "comparison_date_format": "d-M-y",
                    "days_difference_column": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
                    "comparison_type": "is",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        with pytest.raises(
            ParameterNotFoundException,
            match=r"Required parameter 'column_to_compare' not found.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, check_json, att_colname_map
            )

    def test_required_parameter_comparison_type_not_found(
        self, spark_session: SparkSession, date_comparison_data_frame: DataFrame
    ):
        check_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {
                    "main_date_format": "y-M-d",
                    "column_to_compare": "bd5cce48-424e-4158-a046-c149625e5910",
                    "comparison_date_format": "d-M-y",
                    "days_difference_column": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
                },
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }

        with pytest.raises(
            ParameterNotFoundException,
            match=r"Required parameter 'comparison_type' not found.",
        ):
            run_check(
                spark_session, date_comparison_data_frame, check_json, att_colname_map
            )
