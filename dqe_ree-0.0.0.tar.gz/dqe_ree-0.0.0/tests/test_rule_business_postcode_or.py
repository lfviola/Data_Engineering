import pytest
from pyspark.errors.exceptions.base import AnalysisException

from dq_engine.lib import run_check

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "HOUSENUMBER_P",
}


@pytest.mark.usefixtures("business_rule_postcode_dataframe", "spark_session")
def test_filter_business_postcode_or(business_rule_postcode_dataframe, spark_session):
    rule_json = {
        "filters": [
            {
                "parameters": {},
                "description": "business filter",
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
                "technical_name": "expect_column_value_to_not_match_postcode_condition",
            }
        ],
        "rule": {
            "technical_name": "expect_column_values_to_not_be_null",
            "parameters": {},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, business_rule_postcode_dataframe, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert (
        hits_count + passing_count + out_of_scope_recs_count
        == business_rule_postcode_dataframe.count()
    )
    assert (
        out_of_scope_recs_count + filtered_recs.count()
        == business_rule_postcode_dataframe.count()
    )
    assert out_of_scope_recs_count == 6
    assert hits_count == 1
    assert passing_count == 9


@pytest.mark.usefixtures("business_rule_postcode_dataframe", "spark_session")
def test_filter_business_postcode_or_parameters(
    business_rule_postcode_dataframe, spark_session
):
    rule_json = {
        "filters": [
            {
                "parameters": {"postcode_official": "some_random_column_name"},
                "description": "business filter",
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
                "technical_name": "expect_column_value_to_not_match_postcode_condition",
            }
        ],
        "rule": {
            "technical_name": "expect_column_values_to_not_be_null",
            "parameters": {},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                "data_attribute_source": "dsapp",
            },
        },
    }
    with pytest.raises(
        AnalysisException,
        match=r".* A column or function parameter with name `SOME_RANDOM_COLUMN_NAME` cannot be resolved. .*",
    ):
        _hits, _passing_recs, _filtered_recs, _out_of_scope_recs = run_check(
            spark_session, business_rule_postcode_dataframe, rule_json, att_colname_map
        )


@pytest.mark.usefixtures("business_rule_postcode_dataframe", "spark_session")
def test_business_postcode_rule(business_rule_postcode_dataframe, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "parameters": {},
            "description": "business filter",
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                "data_attribute_id": 1,
            },
            "technical_name": "expect_column_value_to_not_match_postcode_condition",
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, business_rule_postcode_dataframe, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    filtered_recs_count = filtered_recs.count()
    assert hits_count + passing_count == filtered_recs_count
    assert (
        hits_count + passing_count + out_of_scope_recs_count
        == business_rule_postcode_dataframe.count()
    )
    assert (
        out_of_scope_recs_count + filtered_recs.count()
        == business_rule_postcode_dataframe.count()
    )
    assert out_of_scope_recs_count == 0
    assert hits_count == 6
    assert passing_count == 10
