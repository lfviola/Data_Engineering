import pytest
from dq_engine.lib import run_check

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5901": "index",
    "bd5cce48-424e-4158-a046-c149625e5902": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5903": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5905": "sex",
    "bd5cce48-424e-4158-a046-c149625e5906": "email",
    "bd5cce48-424e-4158-a046-c149625e5907": "phone",
    "bd5cce48-424e-4158-a046-c149625e5908": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5909": "job_title",
}


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_column_with_unique_values(data_frame, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_be_unique",
            "parameters": {"additional_attributes": []},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 0
    assert passing_count == data_frame.count()
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_multiple_columns_to_have_unique_values(data_frame, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_be_unique",
            "parameters": {
                "additional_attributes": [
                    "bd5cce48-424e-4158-a046-c149625e5902",
                    "bd5cce48-424e-4158-a046-c149625e5906",
                ]
            },
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert passing_count == data_frame.count()
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_column_with_unique_values_without_parameters(data_frame, spark_session):
    rule_json = {
        "filters": [],
        "rule": {
            "technical_name": "expect_column_values_to_be_unique",
            "parameters": {},
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
        },
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 0
    assert passing_count == data_frame.count()
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()


@pytest.mark.usefixtures("data_frame", "spark_session")
def test_parameters_parsing(data_frame, spark_session):
    rule_json = {
        "description": "MRD Identifier if filled must be unique",
        "filters": [],
        "golden_data_element_id": 186579,
        "id": "c8d3bd9b-c228-4b2c-a573-46bbb7baf16f",
        "metric_name": "",
        "rule": {
            "data_attribute": {
                "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                "data_attribute_source": "dsapp",
            },
            "parameters": {
                "_dq_dataset": None,
                "additional_attributes": None,
                "allowed_values": None,
                "column_to_compare": None,
                "comparison": None,
                "date_format": None,
                "length": None,
                "lower_bound": None,
                "number": None,
                "number_of_days": None,
                "reference_data_attribute_id": None,
                "regex": None,
                "upper_bound": None,
                "value": None,
                "values": None,
            },
            "technical_name": "expect_column_values_to_be_unique",
        },
        "scorecard_name": "",
        "source_id": "A",
        "status_id": "P",
    }
    hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
        spark_session, data_frame, rule_json, att_colname_map
    )
    hits_count = hits.count()
    passing_count = passing_recs.count()
    out_of_scope_recs_count = out_of_scope_recs.count()
    assert hits_count + passing_count == data_frame.count()
    assert hits_count == 0
    assert passing_count == data_frame.count()
    assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()
