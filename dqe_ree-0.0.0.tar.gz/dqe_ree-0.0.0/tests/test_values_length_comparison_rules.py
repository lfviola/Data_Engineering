import pytest

from dq_engine.lib import run_check
from dq_engine.rules.custom_exceptions import (
    InvalidColumnDatatypeException,
    ParameterNotFoundException,
)

att_colname_map = {
    "bd5cce48-424e-4158-a046-c149625e5900": "index",
    "bd5cce48-424e-4158-a046-c149625e5901": "user_id",
    "bd5cce48-424e-4158-a046-c149625e5902": "first_name",
    "bd5cce48-424e-4158-a046-c149625e5903": "last_name",
    "bd5cce48-424e-4158-a046-c149625e5904": "sex",
    "bd5cce48-424e-4158-a046-c149625e5905": "email",
    "bd5cce48-424e-4158-a046-c149625e5906": "phone",
    "bd5cce48-424e-4158-a046-c149625e5907": "date_of_birth",
    "bd5cce48-424e-4158-a046-c149625e5908": "job_title",
}
parameter_validation_value_error = (
    "Parameter 'length' should be a valid positive integer."
)
lower_bound_validation_value_error = (
    "Parameter 'lower_bound' should be a valid positive integer."
)
upper_bound_validation_value_error = (
    "Parameter 'upper_bound' should be a valid positive integer."
)
datatype_validation_value_error = "Column datatype is not a string."


class TestToBeBetweenRule:
    rule_name = "expect_column_value_lengths_to_be_between"

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_number_and_letters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 1, "upper_bound": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_number_and_not_null_filter(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 1, "upper_bound": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_string_and_not_null_filter(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 1, "upper_bound": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_multiple_columns_with_only_string_and_not_null_filter(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {
                        "additional_attributes": "bd5cce48-424e-4158-a046-c149625e5903"
                    },
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 1, "upper_bound": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 458
        assert passing_count == 542
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_string_and_special_characters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 1, "upper_bound": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 615
        assert passing_count == 385
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_upper_parameters(self, data_frame, spark_session):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {"lower_bound": 5, "upper_bound": 900},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 5, "uppe_bound": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException, match="Parameter 'upper_bound' not found."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_lower_parameters(self, data_frame, spark_session):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {"lower_bound": 5, "upper_bound": 900},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lowe_bound": 5, "upper_bound": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException, match="Parameter 'lower_bound' not found."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_lower_type_parameters(self, data_frame, spark_session):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {"lower_bound": 5, "upper_bound": 900},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": "5r", "upper_bound": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=lower_bound_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_upper_type_parameters(self, data_frame, spark_session):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {"lower_bound": 5, "upper_bound": 900},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 5, "upper_bound": "900o"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=upper_bound_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_lower_higher_than_upper(self, data_frame, spark_session):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {"lower_bound": 5, "upper_bound": 900},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 900, "upper_bound": 5},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ValueError, match="Upper bound should be higher than lower bound."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_negative_lower_bound(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": -5, "upper_bound": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=lower_bound_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_negative_upper_bound(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 5, "upper_bound": -900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=upper_bound_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_datatype(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 5, "upper_bound": 900},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            InvalidColumnDatatypeException, match=datatype_validation_value_error
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_zero_length_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": 0, "upper_bound": 1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_length_parameter_as_null(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"lower_bound": None, "upper_bound": None},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=lower_bound_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)


class TestToBeEqualsOrLessthanRule:
    rule_name = "expect_column_values_length_to_be_equals_or_lessthan"

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_number_and_letters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 3},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_string(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 9},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 26
        assert passing_count == 974
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_string_and_not_null_filter(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 6},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_string_and_special_characters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 615
        assert passing_count == 385
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_parameters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"value": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException, match="Parameter 'length' not found."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_parameters_datatype(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": "90a"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=parameter_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_zero_length(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": -1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=parameter_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_datatype(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5907",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            InvalidColumnDatatypeException, match=datatype_validation_value_error
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_string_and_special_characters_length_decimal(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 1.1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=parameter_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_parameter_parsing(self, data_frame, spark_session):
        rule_json = {
            "description": "Length must be at most 10 characters.",
            "filters": [],
            "golden_data_element_id": 53836,
            "id": "7fb868ae-bde7-48bf-9f8b-bf7d595012d7",
            "metric_name": "",
            "rule": {
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
                "parameters": {
                    "additional_attributes": None,
                    "allowed_values": None,
                    "column_to_compare": None,
                    "comparison": None,
                    "date_format": None,
                    "length": None,
                    "lower_bound": None,
                    "number": 50,
                    "number_of_days": None,
                    "reference_data_attribute_id": None,
                    "regex": None,
                    "upper_bound": None,
                    "value": None,
                    "values": None,
                },
                "technical_name": "expect_column_values_length_to_be_equal_or_less_than_given_number",
            },
            "scorecard_name": "",
            "source_id": "A",
            "status_id": "P",
        }
        with pytest.raises(ValueError, match=parameter_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)


class TestToBeEqualToNumberRule:
    rule_name = "expect_column_values_length_to_be_equal_to_number"

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_number_and_letters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 3},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 1000
        assert passing_count == 0
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_string(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 9},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 954
        assert passing_count == 46
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_string_and_not_null_filter(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 4},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 494
        assert passing_count == 506
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_string_and_special_characters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 864
        assert passing_count == 136
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_number_and_special_characters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5908",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 952
        assert passing_count == 48
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_parameters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"value": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException, match="Parameter 'length' not found."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_parameters_datatype(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": "90a"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=parameter_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_zero_length(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": -1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=parameter_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_datatype(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5907",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            InvalidColumnDatatypeException, match=datatype_validation_value_error
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)


class TestToBeAtLeastNumberRule:
    rule_name = "expect_column_values_length_to_be_at_least_number"

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_number_and_letters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 3},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_number_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"number": 3},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5901",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_string(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 9},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5903",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 929
        assert passing_count == 71
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_only_string_and_not_null_filter(
        self, data_frame, spark_session
    ):
        rule_json = {
            "filters": [
                {
                    "technical_name": "expect_column_values_to_not_be_null",
                    "parameters": {},
                    "data_attribute": {
                        "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                        "data_attribute_source": "dsapp",
                    },
                }
            ],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 2},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5904",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == filtered_recs.count()
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_string_and_special_characters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 251
        assert passing_count == 749
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_parameters(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"value": 20},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5905",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            ParameterNotFoundException, match="Parameter 'length' not found."
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_parameters_datatype(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": "90a"},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5900",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=parameter_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_zero_length(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": -1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=parameter_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_wrong_datatype(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 1},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5907",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(
            InvalidColumnDatatypeException, match=datatype_validation_value_error
        ):
            run_check(spark_session, data_frame, rule_json, att_colname_map)

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_zero_length_parameter(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": 0},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        hits, passing_recs, filtered_recs, out_of_scope_recs = run_check(
            spark_session, data_frame, rule_json, att_colname_map
        )
        hits_count = hits.count()
        passing_count = passing_recs.count()
        out_of_scope_recs_count = out_of_scope_recs.count()
        assert hits_count + passing_count == data_frame.count()
        assert hits_count == 0
        assert passing_count == 1000
        assert data_frame.count() == out_of_scope_recs_count + filtered_recs.count()

    @pytest.mark.usefixtures("data_frame", "spark_session")
    def test_column_with_length_parameter_as_null(self, data_frame, spark_session):
        rule_json = {
            "filters": [],
            "rule": {
                "technical_name": self.rule_name,
                "parameters": {"length": None},
                "data_attribute": {
                    "data_attribute_uuid": "bd5cce48-424e-4158-a046-c149625e5902",
                    "data_attribute_source": "dsapp",
                },
            },
        }
        with pytest.raises(ValueError, match=parameter_validation_value_error):
            run_check(spark_session, data_frame, rule_json, att_colname_map)
