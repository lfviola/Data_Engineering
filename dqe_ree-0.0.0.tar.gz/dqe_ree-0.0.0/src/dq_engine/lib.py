import inspect
from copy import deepcopy
from typing import Optional

from pyspark.sql import DataFrame, SparkSession

from dq_engine.rules import *  # noqa: F403
from dq_engine.rules import rule
from dq_engine.rules.custom_exceptions import (
    HelperFunctionDictNotFoundException,
    HelperFunctionNotFoundException,
    HelperMetadataTableNotFoundException,
)
from dq_engine.utils.check_output import log_check_output
from dq_engine.utils.spark_logger import get_spark_logger

from .output_generation import create_pk_data, output_dqsm, write_uat_files  # noqa


def all_subclasses(cls):
    """helper function(recursive) to return set of all subclasses of a given class"""
    if cls.__subclasses__() is not None:
        return set(cls.__subclasses__()).union(
            [s for c in cls.__subclasses__() for s in all_subclasses(c)]
        )


def get_all_rules():
    """this function returns list of all classes which are child classes of Rule abstract class"""
    return [
        cls
        for cls in all_subclasses(rule.Rule)
        if ((not inspect.isabstract(cls)) and (not cls.__name__.startswith("_")))
    ]  # noqa: F405


def get_reference_data_attribute_parameter_dict():
    """this function returns a dictionary with all technical rule names that contain reference parameters as keys and the reference parameters per rule as values."""
    all_classes_list = get_all_rules()
    rule_list = {}
    for cls_obj in all_classes_list:
        parameters = cls_obj.parameter_definitions()
        for parameter in parameters:
            if parameter.is_reference_data_attribute:
                reference_parameter_list = [
                    parameter.technical_name
                    for parameter in parameters
                    if parameter.is_reference_data_attribute
                ]
                if len(reference_parameter_list) > 1:
                    rule_list[cls_obj.technical_name()] = reference_parameter_list
                break
    return rule_list


def get_data_attribute_parameter_dict():
    """this function returns a dictionary with all technical rule names that contain non reference data attribute parameters as keys and the parameters per rule as values."""
    all_classes_list = get_all_rules()
    rule_list = {}
    for cls_obj in all_classes_list:
        parameters = cls_obj.parameter_definitions()
        for parameter in parameters:
            if (not parameter.is_reference_data_attribute) and (
                parameter.value_type == "data-attribute"
            ):
                rule_list[cls_obj.technical_name()] = [
                    parameter.technical_name
                    for parameter in parameters
                    if (
                        (not parameter.is_reference_data_attribute)
                        and (parameter.value_type == "data-attribute")
                    )
                ]
                break
    return rule_list


def get_rule_dict():
    """this function returns a dictionary of technical names and their class objects which can be used to call the
    classes"""
    all_classes_list = get_all_rules()
    class_name_object_dict = {}

    for cls_obj in all_classes_list:
        class_name_object_dict[cls_obj.technical_name()] = cls_obj
        for alias in cls_obj.aliases():
            class_name_object_dict[alias] = cls_obj

    return class_name_object_dict


def get_rule_dict_v2():
    all_classes_list = get_all_rules()
    class_name_object_dict = {
        cls_obj.functional_name(): cls_obj for cls_obj in all_classes_list
    }

    return class_name_object_dict


def rule_json_export():
    """This function returns rule json with parameter details as well."""
    return [rule_obj.rule_json() for rule_obj in get_all_rules()]


class DQEngine:
    def __init__(
        self,
        spark: SparkSession,
        df: DataFrame,
        attributeid_colname_map: dict,
        logger=None,
        helper_func_dict: Optional[dict] = None,
        metadata_table: Optional[DataFrame] = None,
        testing: bool = False,
    ):
        self.spark = spark
        self.df = df
        self.attributeid_colname_map = attributeid_colname_map
        self.logger = logger
        self.helper_func_dict: Optional[dict] = helper_func_dict
        self.metadata_table = metadata_table
        self.testing = testing

    def create_rule_instance(self, json_data, all_classes_dict):
        """function to create rule object instance based on check json
        check if the check requests any supporting dfs. if yes then call the loader function and pass it to
        the rule class"""
        technical_name = json_data["technical_name"]
        if technical_name not in all_classes_dict:
            raise NotImplementedError(f"{technical_name} rule not implemented yet.")

        parameters = json_data.get("parameters", {})
        rule_instance = all_classes_dict[technical_name](
            spark=self.spark,
            data_attribute_uuid=json_data["data_attribute"]["data_attribute_uuid"],
            parameters=parameters,
            att_colname_map=self.attributeid_colname_map,
            dq_dataset_data_attribute_uuid=json_data.get(
                "dq_dataset_data_attribute", {}
            ).get("data_attribute_uuid"),
            logger=self.logger,
            metadata_dataframe=self.metadata_table,
        )
        rule_supporting_data = rule_instance.supporting_data()
        supporting_data = self.get_supporting_dataframes(rule_supporting_data)
        rule_instance.set_supporting_data(supporting_data)
        return rule_instance

    def apply_filters(
        self, filters_json: dict, filter_rule_dict: dict
    ) -> tuple[DataFrame, DataFrame]:
        """this function returns filtered dataframe based on check json
        loop through all the filters and apply the filter logic one by one on the dataframe and return the resulting
         dataframe at the end.
        """
        out_of_scope_recs = self.df.limit(0)
        for filter_conf in filters_json:
            filter_obj = self.create_rule_instance(filter_conf, filter_rule_dict)
            if filter_obj.scope() not in ["filter", "both"]:
                raise ValueError(
                    f"{filter_conf['technical_name']} cannot be used as a filter."
                )
            filter_obj.validate(self.df)
            pre_processed_df = filter_obj.pre_process(self.df)
            self.df = filter_obj.post_process(filter_obj.passing(pre_processed_df))
            out_of_scope_recs = out_of_scope_recs.unionByName(
                filter_obj.post_process(filter_obj.failing(pre_processed_df))
            )
        return self.df, out_of_scope_recs

    def apply_check(
        self, rule_json: dict, rule_dict: dict
    ) -> tuple[DataFrame, DataFrame]:
        """this function applies the check on the given data frame"""
        rule_obj = self.create_rule_instance(rule_json, rule_dict)
        if rule_obj.scope() not in ["check", "both"]:
            raise ValueError(
                f"{rule_json['technical_name']} cannot be used as a check."
            )
        rule_obj.validate(self.df)
        pre_processed_df = rule_obj.pre_process(self.df)
        failing_recs = rule_obj.post_process(rule_obj.failing(pre_processed_df))
        passing_recs = rule_obj.post_process(rule_obj.passing(pre_processed_df))
        return failing_recs, passing_recs

    def get_supporting_dataframes(self, rule_supporting_data):
        if not rule_supporting_data:
            return
        if not self.helper_func_dict:
            raise HelperFunctionDictNotFoundException
        if not self.helper_func_dict.get("get_latest_file"):
            raise HelperFunctionNotFoundException("get_latest_file")
        if not self.metadata_table:
            raise HelperMetadataTableNotFoundException
        ret_data = {}
        for name, col_id in rule_supporting_data.items():
            ref_check_filename, ref_check_column_name = (
                self.metadata_table.select("file_name", "column_name")
                .filter(self.metadata_table.data_attribute_uuid == col_id)
                .collect()[0]
            )
            ref_check_file_path = self.helper_func_dict["get_latest_file"](
                ref_check_filename
            )
            if self.testing:
                if "ref_df" in self.helper_func_dict:
                    ref_check_file_df = self.helper_func_dict["ref_df"]
                else:
                    ref_check_file_df = self.spark.read.option("header", True).csv(
                        ref_check_file_path
                    )
            else:
                ref_check_file_df = self.spark.read.parquet(ref_check_file_path)
            ref_check_file_df = ref_check_file_df.toDF(
                *[c.upper() for c in ref_check_file_df.columns]
            )
            ret_data[name] = ref_check_file_df
        return ret_data


def run_check(
    spark: SparkSession,
    df: DataFrame,
    rule_json: dict,
    attributeid_colname_map: Optional[dict] = None,
    helper_func_dict: Optional[dict] = None,
    metadata_table: Optional[DataFrame] = None,
    testing: bool = False,
    dbutils=None,
    uat_status=["Approval Pending"],
    pk_dict: Optional[dict] = None,
    logs_dir: str = "check_outputs",
    dq_lib_logs_directory: str = "check_outputs",
) -> tuple[
    DataFrame,
    DataFrame,
    DataFrame,
    DataFrame,
]:
    """this function runs a single check on the given dataframe

    Args:
        spark (SparkSession): spark session
        df (DataFrame): Pyspark dataframe on which we want to run the check.
        rule_json (_type_): _description_
        attributeid_colname_map (_type_): _description_
        logger (_type_, optional): _description_. Defaults to None.
        helper_func_dict (_type_, optional): _description_. Defaults to None.
        metadata_table (_type_, optional): _description_. Defaults to None.
        testing (bool, optional): _description_. Defaults to False.
        dbutils (_type_, optional): _description_. Defaults to None.

    Raises:
        ValueError: _description_

    Returns:
        _type_: _description_
    """
    logger = get_spark_logger(spark)

    if not pk_dict:
        pk_dict = {}
    rule_json_dict = deepcopy(rule_json)
    if not attributeid_colname_map:
        attributeid_colname_map = {}
    if rule_json["rule"] == {}:
        raise ValueError("Rule cannot be empty.")
    all_rule_classes = get_rule_dict()
    df = df.toDF(*[c.upper() for c in df.columns])
    engine_obj = DQEngine(
        spark=spark,
        df=df,
        attributeid_colname_map=attributeid_colname_map,
        logger=logger,
        helper_func_dict=helper_func_dict,
        metadata_table=metadata_table,
        testing=testing,
    )
    filtered_df, out_of_scope_df = engine_obj.apply_filters(
        filters_json=rule_json["filters"], filter_rule_dict=all_rule_classes
    )
    hits, passing_recs = engine_obj.apply_check(
        rule_json=rule_json["rule"], rule_dict=all_rule_classes
    )
    if dbutils:
        log_check_output(
            spark=spark,
            dbutils=dbutils,
            rule_id=rule_json["id"],
            df=df,
            hits=hits,
            passing_recs=passing_recs,
            filtered_df=filtered_df,
            out_of_scope_df=out_of_scope_df,
            rule_json_dict=rule_json_dict,
            logs_directory=logs_dir,
            dq_lib_logs_directory=dq_lib_logs_directory,
        )
    if rule_json_dict.get("status_id", "") in uat_status:
        if not metadata_table:
            print("cannot write UAT files as metadata table not available.")
        else:
            write_uat_files(
                spark,
                dbutils,
                df,
                hits,
                passing_recs,
                filtered_df,
                out_of_scope_df,
                rule_json_dict,
                pk_dict=pk_dict,
            )
    return hits, passing_recs, filtered_df, out_of_scope_df
