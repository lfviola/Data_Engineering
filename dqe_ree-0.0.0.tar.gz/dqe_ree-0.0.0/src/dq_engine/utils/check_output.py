import datetime
import json
import logging
from copy import deepcopy
from typing import Optional

from pyspark.sql import DataFrame, SparkSession

from dq_engine.rules.custom_exceptions import get_error_json
from dq_engine.utils.helpers import AzureFileHandler
from dq_engine.utils.interfaces import DQEData, DQLibrary
from dq_engine.utils.spark_logger import get_spark_logger

from dq_engine.output_generation import create_pk_data, output_dqsm, write_uat_files  # noqa

logger = logging.getLogger(__name__)


def log_check_output(
    spark: SparkSession,
    rule_id: str,
    rule_json_dict: dict,
    dbutils=None,
    df: Optional[DataFrame] = None,
    hits: Optional[DataFrame] = None,
    passing_recs: Optional[DataFrame] = None,
    filtered_df: Optional[DataFrame] = None,
    out_of_scope_df: Optional[DataFrame] = None,
    error: Optional[Exception] = None,
    logs_directory: str = "check_outputs",
    dq_lib_logs_directory: str = "check_outputs",
    logger_obj: Optional[logging.Logger] = None,
    file_handler_dqe: Optional[AzureFileHandler] = None,
    dqe_container_name: Optional[str] = None,
    file_handler_dq_lib_obj: Optional[AzureFileHandler] = None,
    dq_lib_container_name: Optional[str] = None,
):
    """Logs the output of a check to our storage account.

    Log contains counts if check ran, and an error message if it was not able to run.
    """
    logger = get_spark_logger(spark)

    rule_json = deepcopy(rule_json_dict)
    if rule_json["rule"]["parameters"].get("snapshot_date"):
        rule_json["rule"]["parameters"]["snapshot_date"] = str(
            rule_json["rule"]["parameters"]["snapshot_date"]
        )

    error_string = None
    if error:
        output_json = {
            "counts": {
                "total": df.count() if df else 0,
                "filtered": 0,
                "hit": 0,
                "passing": 0,
                "out_of_scope": 0,
            },
            "rule_json": rule_json,
        }
        if isinstance(error, list):
            output_json["errors"] = [
                get_error_json(individual_error) for individual_error in error
            ]
            output_json["technical_error_message"] = None
        else:
            error_string = str(error)
            output_json["errors"] = [get_error_json(error)]
            output_json["technical_error_message"] = error_string

    else:
        hits_count = hits.count()
        passing_count = passing_recs.count()
        filtered_recs_count = filtered_df.count()
        total_recs_count = df.count()
        out_of_scope_count = out_of_scope_df.count()
        output_json = {
            "counts": {
                "total": total_recs_count,
                "filtered": filtered_recs_count,
                "hit": hits_count,
                "passing": passing_count,
                "out_of_scope": out_of_scope_count,
            },
            "errors": None,
            "rule_json": rule_json,
            "technical_error_message": error_string,
        }
    output_json["rule_json"].update(
        {"execution_datetime": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}
    )
    rule_status = rule_json["status_id"]
    blob_name = f"{rule_id}_{rule_status.lower().replace(' ', '-')}.json"
    run_date = datetime.datetime.now().strftime("%d-%m-%Y")
    file_path = f"{logs_directory}/{run_date}/{blob_name}"

    if (not file_handler_dqe) and (not dqe_container_name):
        dqe_obj = DQEData(spark=spark, dbutils=dbutils)
        file_handler_dqe = AzureFileHandler.instance_from_interface(
            interface_obj=dqe_obj, logger_obj=logger_obj
        )
        file_handler_dqe.write_file_to_azure(
            filename=file_path,
            data=json.dumps(output_json, indent=4),
            container=dqe_obj.default_container_name,
        )
    else:
        file_handler_dqe.write_file_to_azure(
            filename=file_path,
            data=json.dumps(output_json, indent=4),
            container=dqe_container_name,
        )

    output_json.pop("technical_error_message")
    if (not file_handler_dq_lib_obj) and (not dq_lib_container_name):
        dq_lib_obj = DQLibrary(spark=spark, dbutils=dbutils)
        file_handler_dq_lib_obj = AzureFileHandler.instance_from_interface(
            interface_obj=dq_lib_obj, logger_obj=logger_obj
        )
        file_handler_dq_lib_obj.write_file_to_azure(
            filename=f"{dq_lib_logs_directory}/{blob_name}",
            container=dq_lib_obj.default_container_name,
            data=json.dumps(output_json, indent=4),
        )
    else:
        file_handler_dq_lib_obj.write_file_to_azure(
            filename=f"{dq_lib_logs_directory}/{blob_name}",
            container=dq_lib_container_name,
            data=json.dumps(output_json, indent=4),
        )

    if logger:
        logger.info(f"logging check: {rule_id}")
        logger.info(json.dumps({"Payload_KPIs": output_json}, indent=4))
