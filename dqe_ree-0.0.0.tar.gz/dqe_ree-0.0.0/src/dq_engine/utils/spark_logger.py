from pyspark.sql import SparkSession


def get_spark_logger(spark: SparkSession):
    """Retrieves the Log4j logger."""
    sc = spark.sparkContext
    spark_log4j = sc._jvm.org.apache.log4j
    logger = spark_log4j.LogManager.getLogger(__name__)

    return logger
