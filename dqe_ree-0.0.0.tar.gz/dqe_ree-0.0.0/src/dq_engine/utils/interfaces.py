from abc import ABC

from dq_engine.rules.custom_exceptions import UnknownInstanceException

# Constants for repeated literals
AZURE_AUTH_TYPE = "fs.azure.account.auth.type"
AZURE_OAUTH_PROVIDER_TYPE = "fs.azure.account.oauth.provider.type"
AZURE_CLIENT_CREDS_PROVIDER = (
    "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider"
)
AZURE_OAUTH_CLIENT_ID = "fs.azure.account.oauth2.client.id"
AZURE_OAUTH_CLIENT_SECRET = "fs.azure.account.oauth2.client.secret"
AZURE_OAUTH_CLIENT_ENDPOINT = "fs.azure.account.oauth2.client.endpoint"


class Environment(ABC):
    """An abstract class representing the environment (DEV, TEST, ACC or PROD) and its variables."""

    def __init__(self, spark, dbutils):
        self.dbricks_instance_ID = spark.conf.get("spark.databricks.workspaceUrl")
        self.tenant_id = "3a15904d-3fd9-4256-a753-beb05cdf0c6d"
        self.kv_scope_name = "dqe-kv-scope"
        self.spark = spark
        self.dbutils = dbutils

        if self.dbricks_instance_ID == "adb-8724507640336375.15.azuredatabricks.net":
            self.env_name = "DEV"
            self.env_code = "d"
            self.env_type = "new"
        elif self.dbricks_instance_ID == "adb-6002442032765286.6.azuredatabricks.net":
            self.env_name = "TEST"
            self.env_code = "t"
            self.env_type = "new"
        elif self.dbricks_instance_ID == "adb-6039118803582054.14.azuredatabricks.net":
            self.env_name = "ACC"
            self.env_code = "a"
            self.env_type = "new"
        elif self.dbricks_instance_ID == "adb-647480779061657.17.azuredatabricks.net":
            self.env_name = "PROD"
            self.env_code = "p"
            self.env_type = "new"
        else:
            raise UnknownInstanceException(
                "Unknown environment. Should you update the Databricks instance ID?"
            )
        self.dqe_account_url = f"https://dqe3{self.env_code}01sa.blob.core.windows.net"


class ServicePrincipal(Environment, ABC):
    def __init__(self, spark, dbutils) -> None:
        super().__init__(spark, dbutils)
        self.spn_appid = dbutils.secrets.get(
            self.kv_scope_name, f"dqe-{self.env_code}-adb-spn-appID"
        )
        self.app_psswd = dbutils.secrets.get(
            self.kv_scope_name, f"dqe-{self.env_code}-adb-spn-pwd"
        )


class DialRds(ServicePrincipal):
    def __init__(self, spark, dbutils, regression_test=None):
        super().__init__(spark, dbutils)
        self.regression_test = regression_test
        if self.regression_test or self.env_code in ["d", "t"]:
            spark.conf.set(AZURE_AUTH_TYPE, "OAuth")
            spark.conf.set(AZURE_OAUTH_PROVIDER_TYPE, AZURE_CLIENT_CREDS_PROVIDER)
            spark.conf.set(AZURE_OAUTH_CLIENT_ID, self.spn_appid)
            spark.conf.set(AZURE_OAUTH_CLIENT_SECRET, self.app_psswd)
            spark.conf.set(
                AZURE_OAUTH_CLIENT_ENDPOINT,
                f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/token",
            )
        else:
            spark.conf.set(
                f"{AZURE_AUTH_TYPE}.rdsa01{self.env_code}storage.dfs.core.windows.net",
                "OAuth",
            )
            spark.conf.set(
                f"{AZURE_OAUTH_PROVIDER_TYPE}.rdsa01{self.env_code}storage.dfs.core.windows.net",
                AZURE_CLIENT_CREDS_PROVIDER,
            )
            spark.conf.set(
                f"{AZURE_OAUTH_CLIENT_ID}.rdsa01{self.env_code}storage.dfs.core.windows.net",
                self.spn_appid,
            )
            spark.conf.set(
                f"{AZURE_OAUTH_CLIENT_SECRET}.rdsa01{self.env_code}storage.dfs.core.windows.net",
                self.app_psswd,
            )
            spark.conf.set(
                f"{AZURE_OAUTH_CLIENT_ENDPOINT}.rdsa01{self.env_code}storage.dfs.core.windows.net",
                f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/token",
            )

    def end_point(self):
        if self.regression_test or self.env_code in ["d", "t"]:
            return f"abfss://dialrdsazure@dqe3{self.env_code}01sa.dfs.core.windows.net/data/readdatazone"
        return f"abfss://readzonecontainer@rdsa01{self.env_code}storage.dfs.core.windows.net/gds"

    def file_path(self, file_path):
        return f"{self.end_point()}/{file_path}"


class DQEData(ServicePrincipal):
    def __init__(self, spark, dbutils):
        super().__init__(spark, dbutils)
        spark.conf.set(AZURE_AUTH_TYPE, "OAuth")
        spark.conf.set(AZURE_OAUTH_PROVIDER_TYPE, AZURE_CLIENT_CREDS_PROVIDER)
        spark.conf.set(AZURE_OAUTH_CLIENT_ID, self.spn_appid)
        spark.conf.set(AZURE_OAUTH_CLIENT_SECRET, self.app_psswd)
        spark.conf.set(
            AZURE_OAUTH_CLIENT_ENDPOINT,
            f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/token",
        )
        self.default_container_name = "dqe-data"
        self.default_url = f"https://dqe3{self.env_code}01sa.blob.core.windows.net"

    def end_point(self, container_name=None):
        if not container_name:
            container_name = "dqe-data"
        return f"abfss://{container_name}@dqe3{self.env_code}01sa.dfs.core.windows.net"

    def file_path(self, file_path):
        return f"{self.end_point()}/{file_path}"


class DQLibrary(ServicePrincipal):
    """Class to interact with the DQ Library storage account."""

    def __init__(self, spark, dbutils):
        super().__init__(spark, dbutils)
        spark.conf.set(AZURE_AUTH_TYPE, "OAuth")
        spark.conf.set(AZURE_OAUTH_PROVIDER_TYPE, AZURE_CLIENT_CREDS_PROVIDER)
        spark.conf.set(AZURE_OAUTH_CLIENT_ID, self.spn_appid)
        spark.conf.set(AZURE_OAUTH_CLIENT_SECRET, self.app_psswd)
        spark.conf.set(
            AZURE_OAUTH_CLIENT_ENDPOINT,
            f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/token",
        )
        self.default_url = (
            f"https://dqlb02{self.env_code}automationst.blob.core.windows.net"
        )
        self.default_container_name = "main"

    def end_point(self, container_name=None):
        """Constructs and returns the full ABFS URL for a specified container. Defaults to the "main" container if none is specified."""
        if not container_name:
            container_name = "main"
        return f"abfss://{container_name}@dqlb02{self.env_code}automationst.dfs.core.windows.net/"

    def file_path(self, file_path):
        """Constructs and returns the full file path for a specified file within the default container."""
        return f"{self.end_point()}/{file_path}"


class EPRInterface(ServicePrincipal):
    def __init__(self, spark, dbutils):
        super().__init__(spark, dbutils)
        if self.env_code in ["d"]:
            spark.conf.set(AZURE_AUTH_TYPE, "OAuth")
            spark.conf.set(AZURE_OAUTH_PROVIDER_TYPE, AZURE_CLIENT_CREDS_PROVIDER)
            spark.conf.set(AZURE_OAUTH_CLIENT_ID, self.spn_appid)
            spark.conf.set(AZURE_OAUTH_CLIENT_SECRET, self.app_psswd)
            spark.conf.set(
                AZURE_OAUTH_CLIENT_ENDPOINT,
                f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/token",
            )
            self.default_container_name = "dqe-data"
            self.default_url = f"https://dqe3{self.env_code}01sa.blob.core.windows.net"
        else:
            spark.conf.set(
                f"{AZURE_AUTH_TYPE}.epr1{self.env_code}adls.dfs.core.windows.net",
                "OAuth",
            )
            spark.conf.set(
                f"{AZURE_OAUTH_PROVIDER_TYPE}.epr1{self.env_code}adls.dfs.core.windows.net",
                AZURE_CLIENT_CREDS_PROVIDER,
            )
            spark.conf.set(
                f"{AZURE_OAUTH_CLIENT_ID}.epr1{self.env_code}adls.dfs.core.windows.net",
                self.spn_appid,
            )
            spark.conf.set(
                f"{AZURE_OAUTH_CLIENT_SECRET}.epr1{self.env_code}adls.dfs.core.windows.net",
                self.app_psswd,
            )
            spark.conf.set(
                f"{AZURE_OAUTH_CLIENT_ENDPOINT}.epr1{self.env_code}adls.dfs.core.windows.net",
                "https://login.microsoftonline.com/3a15904d-3fd9-4256-a753-beb05cdf0c6d/oauth2/token",
            )
            self.default_container_name = "epr-dq-dataset"
            self.default_url = f"https://epr1{self.env_code}adls.blob.core.windows.net/"

    def end_point(self):
        if self.env_code in ["d"]:
            return f"abfss://dqe-data@dqe3{self.env_code}01sa.dfs.core.windows.net"
        return f"abfss://epr-dq-dataset@epr1{self.env_code}adls.dfs.core.windows.net"

    def file_path(self, file_path):
        return f"{self.end_point()}/{file_path}"
