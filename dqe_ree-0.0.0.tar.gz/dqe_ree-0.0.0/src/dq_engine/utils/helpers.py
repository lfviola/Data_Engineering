import datetime
import logging
import os
from functools import reduce
from typing import IO, Optional, Union

from azure import identity
from azure.storage.blob import BlobServiceClient
from dateutil.parser import parse
from pyspark.sql import DataFrame

from dq_engine.rules.custom_exceptions import (
    FileNotFoundException,
    FileReadException,
)
from dq_engine.utils.interfaces import DQEData, DQLibrary, EPRInterface


class DatabricksHelperFunctions:
    """
    This class contains all the helper functions which need dbutils utility
    """

    def __init__(
        self,
        spark,
        dbutils_obj,
        dial_path: Optional[str] = None,
        dq_dataset_paths: Optional[list[str]] = None,
    ) -> None:
        self.spark = spark
        self.dbutils_obj = dbutils_obj
        self.filename_path_dict_dial = self.filename_path_dict(dial_path)
        if dq_dataset_paths:
            self.filename_path_dict_dataset = self.filename_path_dict_dataset = reduce(
                lambda d1, d2: d1 | d2,
                (
                    self.filename_path_dict(i)
                    for i in (
                        [dq_dataset_paths]
                        if isinstance(dq_dataset_paths, str)
                        else dq_dataset_paths
                    )
                ),
            )
        else:
            self.filename_path_dict_dataset = {}

    def filename_path_dict(self, base_path, file_identifier=None) -> dict[str, str]:
        """function to create mapping of filename and their path on storage account.

        Args:
            base_path (str): base folder name where all files are stored in DIAL storage format.
            file_identifier (str, optional): in case of dq datasets the file names have different identifiers. Defaults to None.

        Returns:
            dict[str, str]: dictionary with filename as key and its location as value.
        """
        if not base_path:
            return {}
        folder_names = [x.path for x in self.dbutils_obj.fs.ls(base_path)]
        return_dict = {}
        for _filename in folder_names:
            try:
                if file_identifier:
                    file_folder_names = [
                        x.path
                        for x in self.dbutils_obj.fs.ls(_filename)
                        if file_identifier in x.path
                    ]
                else:
                    file_folder_names = [
                        x.path for x in self.dbutils_obj.fs.ls(_filename)
                    ]
            except Exception:
                print(f"cant read: {_filename}")
                continue
            for file_folder in file_folder_names:
                if file_identifier:
                    filename = (
                        file_folder.split("/")[-2].replace("_parquet", "").lower()
                    )
                else:
                    filename = file_folder.split("/")[-2].lower()
                return_dict[filename] = file_folder
        return return_dict

    def get_latest_snapshot_path(self, file_path: str, file_name: str) -> str:
        """Gets latest snapshot for a given filepath."""
        FILE_STARTING_STRING = "="
        try:
            dial_snapshots = [path.path for path in self.dbutils_obj.fs.ls(file_path)]
        except Exception:
            raise FileReadException(file_name)
        all_snapshots = [
            snapshot for snapshot in dial_snapshots if "snapshotdate=" in snapshot
        ]
        return sorted(
            all_snapshots,
            key=lambda x: parse(x.split("/")[-2].split(FILE_STARTING_STRING)[-1]),
            reverse=True,
        )[0]

    def get_latest_snapshot_file_path(self, file_name, location):
        """Constructs filepath for given filename and returns path."""
        if location == "dial":
            file_path = self.filename_path_dict_dial.get(file_name.lower(), None)
        elif location == "dqrem":
            file_path = self.filename_path_dict_dataset.get(file_name.lower(), None)
        else:
            raise ValueError("Location of file to search unknown.")

        if not file_path:
            raise FileNotFoundException(file_name=file_name, file_type=location)
        else:
            return self.get_latest_snapshot_path(file_path, file_name)

    def read_latest_snapshot_file_to_dataframe(
        self, file_name, locatoion="dial"
    ) -> DataFrame:
        """Reads latest snapshot for a given filename and returns dataframe."""
        latest_snapshot_dataframe = self.spark.read.parquet(
            self.get_latest_snapshot_file_path(file_name, locatoion)
        )
        return latest_snapshot_dataframe

    def check_file_exists(self, file_path):
        try:
            self.dbutils_obj.fs.ls(file_path)
            return True
        except Exception:
            return False

    def write_text_files(self, path: str, contents: str, overwrite: bool):
        self.dbutils_obj.fs.put(file=path, contents=contents, overwrite=overwrite)


class AzureFileHandler:
    def __init__(
        self,
        spn_app_id: str,
        spn_password: str,
        tenant_id: str,
        account_url: str,
        logger_obj: Optional[logging.Logger] = None,
    ) -> None:
        self.spn_app_id = spn_app_id
        self.spn_password = spn_password
        self.tenant_id = tenant_id
        self.account_url = account_url
        self.logger = logger_obj
        self.credential = identity.ClientSecretCredential(
            tenant_id=self.tenant_id,
            client_id=self.spn_app_id,
            client_secret=self.spn_password,
        )
        self.blob_service_client = BlobServiceClient(
            account_url=self.account_url, credential=self.credential
        )

    def read_file_from_container_azure(
        self,
        container: str,
        file_path: str,
    ) -> bytes:
        if self.logger:
            self.logger.info(f"Reading file: {file_path}, from container: {container}")
        container_client = self.blob_service_client.get_container_client(
            container=container
        )
        blob_client = container_client.get_blob_client(file_path)
        blob_data = blob_client.download_blob().readall()
        return blob_data

    def write_file_to_azure(
        self,
        container: str,
        data: Union[str, IO],
        filename: str,
    ):
        if self.logger:
            self.logger.info(
                f"sending file '{os.path.basename(filename)}' to account: '{self.account_url}'"
            )
        container_client = self.blob_service_client.get_container_client(
            container=container
        )
        blob_client = container_client.get_blob_client(blob=filename)
        blob_client.upload_blob(data, overwrite=True)

    def write_csv_file_from_df(self, container: str, df: DataFrame, file_path: str):
        if self.logger:
            self.logger.info(f"writing dataframe as csv to location: {file_path}")
        headers = df.columns
        data = [[rec[col] for col in headers] for rec in df.collect()]
        out_data = ",".join(headers) + "\n"
        for rec in data:
            out_data += ",".join(list(map(str, rec))) + "\n"
        self.write_file_to_azure(container=container, data=out_data, filename=file_path)

    def list_files_in_container_folder(
        self,
        container: str,
        starts_with: Optional[str] = None,
        ends_with: Optional[str] = None,
    ):
        """
        Lists all files in a container folder that optionally start or end with specified strings.

        :param container: The name of the container to search.
        :param starts_with: Optional prefix string to filter blobs by. If None, no prefix filter is applied.
        :param ends_with: Optional suffix string to filter blobs by. If None, no suffix filter is applied.
        :return: A list of blob names that match the specified criteria.
        """
        if self.logger:
            self.logger.info(
                f"listing files from container: {container}, optional parameters- starts_with: {starts_with}, ends_with: {ends_with}"
            )
        container_client = self.blob_service_client.get_container_client(
            container=container
        )
        all_paths = []
        for blob in container_client.list_blobs(name_starts_with=starts_with):
            if ends_with is None or blob.name.endswith(ends_with):
                all_paths.append(blob.name)
        return all_paths

    @classmethod
    def instance_from_interface(
        cls,
        interface_obj: DQEData | DQLibrary | EPRInterface,
        logger_obj: Optional[logging.Logger] = None,
    ):
        return cls(
            spn_app_id=interface_obj.spn_appid,
            spn_password=interface_obj.app_psswd,
            tenant_id=interface_obj.tenant_id,
            account_url=interface_obj.default_url,
            logger_obj=logger_obj,
        )

    def delete_files_container_folder(
        self,
        container_name: str,
        file_path_list: list[str],
    ):
        """Function to delete files from a given folder asynchronously

        Args:
            container_name (str): container name on the storage account
            file_path_list (list[str]): file path on the container to be deleted
        """
        for file_path in file_path_list:
            blob_client = self.blob_service_client.get_blob_client(
                container=container_name, blob=file_path
            )
            blob_client.delete_blob()


def delete_old_files_from_container_folder(
    interface_obj: DQEData,
    container: str,
    folder_list: list[str],
    threshold_number_of_days: int = 15,
    dry_run=True,
    recursive=True,
):
    """_summary_

    Args:
        interface_obj (DQEData): Interface object for DQE storage account.
        container (str): container name on storage account.
        folder_list (list[str]): list of folders to scan.
        threshold_number_of_days (int, optional): Value in number of days. Any file older than this value will be deleted. Defaults to 15.
        dry_run (bool, optional): If False, then actully delete the file. Defaults to True.
        recursive (bool, optional): Do recursive search inside given folder.
    Returns:
        list: List of paths of files which were/will be deleted
    """
    azure_handler_obj = AzureFileHandler.instance_from_interface(interface_obj)
    threshold_date = datetime.datetime.now().date() - datetime.timedelta(
        days=threshold_number_of_days
    )
    blobs_to_delete = []
    for folder in folder_list:
        if folder[-1] != "/":
            folder_path = folder + "/"
        else:
            folder_path = folder
        container_client = azure_handler_obj.blob_service_client.get_container_client(
            container=container
        )
        blob_list = [
            blob
            for blob in container_client.list_blobs(name_starts_with=folder_path)
            if blob.last_modified.date() < threshold_date
        ]
        if not recursive:
            blob_list = [
                blob
                for blob in blob_list
                if folder_path[:-1] == os.path.dirname(blob.name)
            ]
        blobs_to_delete.extend(
            [blob.name for blob in blob_list if blob.size > 0]
        )  # delete only files which take space as it is not easy to tell if given blob is file or folder.

    if not dry_run:
        azure_handler_obj.delete_files_container_folder(
            container_name=container, file_path_list=blobs_to_delete
        )
    return blobs_to_delete


def get_reference_att_uuids(checks: list[dict]) -> list[str]:
    """
    Returns a list of reference data attribute uuids
    from the given `checks`.

    Args:
        checks: checks

    Returns:
        List of uuids.

    """
    reference_att_uuids = set()
    reference_keys_to_extract = [
        "reference_data_attribute_id",
        "reference_regex_attribute_id",
    ]

    for check in checks:
        parameters = check["rule"].get("parameters", {})
        _extract_reference_ids(
            parameters, reference_keys_to_extract, reference_att_uuids
        )

        for rule_filter in check.get("filters", []):
            filter_parameters = rule_filter.get("parameters", {})
            _extract_reference_ids(
                filter_parameters, reference_keys_to_extract, reference_att_uuids
            )

    return list(reference_att_uuids)


def _extract_reference_ids(parameters, reference_keys_to_extract, reference_att_uuids):
    """
    Returns a list of reference data attribute uuids
    from the given dictionary.

    Args:
        parameters: dict of parameter values
        reference_keys_to_extract: list of keys to look for in the dict
        reference_att_uuids: set to keep track of uuids

    Returns:
        List of uuids.

    """
    # Extract values from specified keys
    for key in reference_keys_to_extract:
        reference_id = parameters.get(key)
        if reference_id is not None:
            reference_att_uuids.add(reference_id)

    # Extract values from 'lookup_attributes' if it is a list
    lookup_values = parameters.get("lookup_attributes")
    if isinstance(lookup_values, list):
        reference_att_uuids.update(lookup_values)
