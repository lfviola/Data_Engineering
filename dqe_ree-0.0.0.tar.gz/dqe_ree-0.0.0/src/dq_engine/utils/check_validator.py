from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StringType

ERROR_ID_NOT_FOUND = "Check ID not found."
ERROR_GOLDEN_DATA_ELEMENT_ID_NOT_FOUND = "Golden Data Element id not found."
ERROR_RULE_NOT_FOUND = "rule not found."
ERROR_FILTER_NOT_FOUND = "filters key not found."


def validate_rule(
    rule_data: dict, rule_data_type: str, valid_rulenames: list[str]
) -> list:
    errors = []
    technical_name = None
    if "technical_name" not in rule_data or str(
        rule_data["technical_name"]
    ).strip() in ["", "None"]:
        errors.append(f"technical_name not found in rule data. In {rule_data_type}.")
    else:
        technical_name = rule_data["technical_name"]
    if technical_name and technical_name not in valid_rulenames:
        errors.append(
            f"technical_name '{rule_data['technical_name']}' not supported yet. In {rule_data_type}."
        )
    if "data_attribute_uuid" not in rule_data:
        errors.append(f"data_attribute_uuid not found in rule. In {rule_data_type}.")
    else:
        data_atribute_uuid = rule_data["data_attribute_uuid"]

    if not data_atribute_uuid:
        errors.append(
            f"data_attrubute_id value missing in rule data. In {rule_data_type}."
        )
    if "parameters" not in rule_data or rule_data["parameters"] is None:
        errors.append(
            f"parameters missing or not present in rule data. In {rule_data_type}."
        )
    return errors


def validate_check_keys(check) -> list:
    errors = []
    if "id" not in check:
        errors.append(ERROR_ID_NOT_FOUND)
    if (
        "golden_data_element_id" not in check
        or not str(check["golden_data_element_id"]).strip()
    ):
        errors.append(ERROR_GOLDEN_DATA_ELEMENT_ID_NOT_FOUND)
    if "rule" not in check:
        errors.append(ERROR_RULE_NOT_FOUND)
    if "filters" not in check:
        errors.append(ERROR_FILTER_NOT_FOUND)

    return errors


def validate_check(check: dict, valid_rulenames) -> str:
    # validations on whole check
    errors = validate_check_keys(check)

    rule_data = check["rule"]
    filters = check["filters"]

    # validations on rule key
    errors.extend(validate_rule(rule_data, "Rule", valid_rulenames))
    # validating all filters
    for _filter in filters:
        errors.extend(validate_rule(_filter, "Filter", valid_rulenames))

    return "\n".join(errors)


def validate_checks(
    checks_df: DataFrame, valid_rulenames: list[str]
) -> tuple[DataFrame, DataFrame]:
    validation_udf = F.udf(lambda z: validate_check(z, valid_rulenames), StringType())
    checks_with_validation = checks_df.withColumn(
        "validation_output", validation_udf(checks_df["check_json"])
    )
    valid_checks = checks_with_validation.filter(
        F.trim(checks_with_validation["validation_output"]) == ""
    )
    invalid_checks = checks_with_validation.filter(
        F.trim(checks_with_validation["validation_output"]) != ""
    )
    return valid_checks, invalid_checks


def validate_checks_v2(
    checks_json_list: list[dict], valid_rulenames: list[str]
) -> tuple[list, list]:
    valid_checks, invalid_checks = [], []
    for check in checks_json_list:
        validation_output = validate_check(check=check, valid_rulenames=valid_rulenames)
        if not validation_output:
            valid_checks.append({"id": check["id"], "json_data": check, "errors": None})
        else:
            invalid_checks.append(
                {
                    "id": check["id"],
                    "json_data": check,
                    "errors": validation_output.split("\n"),
                }
            )
    return valid_checks, invalid_checks
