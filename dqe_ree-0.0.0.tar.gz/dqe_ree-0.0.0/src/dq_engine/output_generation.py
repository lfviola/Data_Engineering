from io import BytesIO
from typing import Optional, Tuple
from datetime import datetime

import pandas as pd
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StringType,
    StructField,
    StructType,
)

from dq_engine.metadata_handlers.dial_metadata_handler import DialMetadataHandler
from dq_engine.rules.custom_exceptions import PrimaryKeyColumnNotFoundException
from dq_engine.utils.helpers import (
    AzureFileHandler,
)
from dq_engine.utils.interfaces import DialRds, DQEData


def create_pk_data(
    file_name: str,
    file_type: str,
    metadata: DataFrame,
) -> dict:
    """
    Create primary key dictionary for technical file name.

    Args:
        file_name: File name of dataframe.
        file_type: if file is dial or DQ dataset.
        metadata: DIAL or DQ Dataset metadata. When `file_type` is `dq_dataset` provide the DQ dataset metadata.

    Returns:
        Dictionary containing the primary key columns and their attribute ids.

    Raises:
        Value error if File type is not valid.

    """
    # TODO Unify behaviour for different file types. This requires metadata to be structured more similarly.
    pk_dict = {}

    if file_type == "dsapp":
        pk_lst = (
            metadata.filter(
                (metadata.file_name == file_name)
                & (F.lower(metadata.primary_key) == "true")
            )
            .select("column_name", "data_attribute_id", "primary_key")
            .collect()
        )
    elif file_type == "dq_dataset":
        pk_lst = (
            metadata.filter(
                (F.lower(metadata.dq_dataset_name) == file_name.lower())
                & (F.lower(metadata.primary_key) == "true")
            )
            .select("column_name", "data_attribute_id", "primary_key")
            .collect()
        )
    else:
        raise ValueError("File type is not valid.")

    for x in pk_lst:
        if x.primary_key.lower() == "true":
            pk_dict[x.column_name.upper()] = x.data_attribute_id
    return pk_dict


def output_dqsm(
    df_hits: DataFrame,
    pk_dict: dict,
    check_ids_for_hits: list,
    data_attribute_mapping: DataFrame,
) -> Tuple[DataFrame, DataFrame]:
    """
    Transforms output into format of dq signalers.

    Args:
        df_hits: Dataframe to transform.
        pk_dict: Dataframe containing the primary key columns and their attribute alias.
        check_ids_for_hits: Check ids used to filter the detailed output Dataframe.
        data_attribute_mapping: Metadata for the `df_hits`. It contains a map of `data_attribute_uuid` and `data_attribute_id`. Since the identifier used by
          the rule engine is `_data_attribute_uuid` but the signalers require `_data_attribute_id`, we use this metadata to map these values
          and output `_data_attribute_id`.

    Returns:
        Tuple of a dataframe with a summary and the dataframe with details.

    Raises:
        None
    """
    data_attribute_mapping_renamed = data_attribute_mapping.withColumnRenamed(
        "data_attribute_uuid", "map_data_attribute_uuid"
    ).withColumnRenamed("data_attribute_id", "map_data_attribute_id")

    # Add and additional column `_data_attribute_id` to the given `df_hits` based on the given `metadata`.
    df_hits = df_hits.join(
        data_attribute_mapping_renamed,
        on=df_hits._data_attribute_uuid
        == data_attribute_mapping_renamed.map_data_attribute_uuid,
        how="left",
    ).withColumnRenamed("map_data_attribute_id", "_data_attribute_id")

    # create summary df
    columns_to_select = [
        "_check_id_dq",
        "_data_attribute_id",
        "_dq_check_scope_number_of_records",
        "_dq_check_hit_number_of_records",
        "_snapshotdate",
        "_dq_execution_date",
        "_generated_date",
        "_generated_by",
        "_check_version",
    ]
    df_chk_summary_out = (
        df_hits.select(*columns_to_select)
        .groupBy(*columns_to_select)
        .agg(*[F.col(col) for col in columns_to_select])
        .select(*columns_to_select)
    )
    # If there's a primary key, prepare and create hits df
    if pk_dict:
        # lets build a stament to put every thing in one column
        expr_technical_key = ""

        for column_name, column_alias in {
            k: v for k, v in sorted(pk_dict.items(), key=lambda item: item[1])
        }.items():
            # make sure the column exist in the dataframe
            if column_name in df_hits.columns:
                expr_technical_key += (
                    "("
                    + str(column_alias)
                    + " as pk_attr_id, "
                    + column_name
                    + " as pk_attr_value),"
                )
        if expr_technical_key != "":
            expr_technical_key = "array(struct" + expr_technical_key[:-1] + ")"
        else:
            expr_technical_key = "array()"
        expr_check_attributes = "array(struct(_data_attribute_id as dq_check_attr_id, _dq_check_attr_value as dq_check_attr_value , 1     as dq_check_attr_seq))"
        expr_outcome_details = "array(struct('NA' as outcome_attr_id, 'NA' as outcome_attr_value , 1 as outcome_attr_seq))"
        expr_business_key = "array(struct('NA' as identifying_data_element_id, 'NA' as identifying_data_element_value))"
        df_chk_details_out = df_hits.select(
            "_check_id_dq",
            "_data_attribute_id",
            "_dq_execution_date",
            "_generated_by",
            "_generated_date",
            "_snapshotdate",
            F.expr(expr_technical_key).alias("primary_key"),
            F.expr(expr_business_key).alias("business_key"),
            F.expr(expr_check_attributes).alias("dq_check_attributes"),
            F.expr(expr_outcome_details).alias("outcome_details"),
        ).filter(df_hits["_dq_check_hit_number_of_records"] > 0)
    # if no pkey, return empty df
    else:
        spark = SparkSession.builder.appName("output_generation").getOrCreate()
        emptyrdd = spark.sparkContext.emptyRDD()
        schema = StructType(
            [
                StructField("_check_id_dq", StringType(), True),
                StructField("_data_attribute_id", StringType(), True),
                StructField("_dq_execution_date", StringType(), True),
                StructField("_generated_by", StringType(), True),
                StructField("_generated_date", StringType(), True),
                StructField("_snapshotdate", StringType(), True),
                StructField("primary_key", StringType(), True),
                StructField("business_key", StringType(), True),
                StructField("dq_check_attributes", StringType(), True),
                StructField("outcome_details", StringType(), True),
            ]
        )
        df_chk_details_out = spark.createDataFrame(emptyrdd, schema)

    df_chk_details_out = (
        df_chk_details_out.withColumnRenamed("_check_id_dq", "dq_check_id")
        .withColumnRenamed("_rule_technical_name", "rule_technical_name")
        .withColumnRenamed(
            "_dq_check_scope_number_of_records", "dq_check_scope_number_of_records"
        )
        .withColumnRenamed(
            "_dq_check_hit_number_of_records", "dq_check_hit_number_of_records"
        )
        .withColumnRenamed("_snapshotdate", "snapshotdate")
        .withColumnRenamed("_dq_execution_date", "dq_execution_date")
        .withColumnRenamed("_generated_date", "generated_date")
        .withColumnRenamed("_generated_by", "generated_by")
        .withColumnRenamed("_rule_output_cd", "rule_output_cd")
        .withColumnRenamed("_data_attribute_id", "data_attribute_id")
        .withColumnRenamed("_dq_check_attr_value", "dq_check_attr_value")
    )

    df_chk_summary_out = (
        df_chk_summary_out.withColumnRenamed("_check_id_dq", "dq_check_id")
        .withColumnRenamed("_rule_technical_name", "rule_technical_name")
        .withColumnRenamed(
            "_dq_check_scope_number_of_records", "dq_check_scope_number_of_records"
        )
        .withColumnRenamed(
            "_dq_check_hit_number_of_records", "dq_check_hit_number_of_records"
        )
        .withColumnRenamed("_snapshotdate", "snapshotdate")
        .withColumnRenamed("_dq_execution_date", "dq_execution_date")
        .withColumnRenamed("_generated_date", "generated_date")
        .withColumnRenamed("_generated_by", "generated_by")
        .withColumnRenamed("_rule_output_cd", "rule_output_cd")
        .withColumnRenamed("_data_attribute_id", "data_attribute_id")
        .withColumnRenamed("_dq_check_attr_value", "dq_check_attr_value")
        .withColumnRenamed("_check_version", "check_version")
    )
    df_chk_details_out = df_chk_details_out.filter(
        df_chk_details_out["dq_check_id"].isin(check_ids_for_hits)
    )
    return df_chk_summary_out, df_chk_details_out


def write_uat_files(
    spark,
    dbutils,
    df: DataFrame,
    hits: DataFrame,
    passing_recs: DataFrame,
    filtered_df: DataFrame,
    out_of_scope_df: DataFrame,
    rule_json: dict,
    sample_count: int = 1000,
    pk_dict: Optional[dict] = None,
):
    """
    Prepares and writes uat data into excel file and stores it in azure storage account.
    The uat data consist of 3 elements, each of them in a different sheet of
    the same excel file:
      - counts: count of total records, hits, passing, out of scope and snapshot date.
      - pk_scope: PKs and corresponding "DQ_SCOPE".
      - records: Sample records and corresponding "DQ_SCOPE" limited by `sample_count`.

    """
    if not pk_dict:
        pk_dict = {}
    out_of_scope_records = out_of_scope_df
    dqe_obj = DQEData(spark=spark, dbutils=dbutils)
    dial_obj = DialRds(spark=spark, dbutils=dbutils)
    file_handler_obj = AzureFileHandler(
        spn_app_id=dqe_obj.spn_appid,
        spn_password=dqe_obj.app_psswd,
        tenant_id=dqe_obj.tenant_id,
        account_url=dqe_obj.dqe_account_url,
    )

    golden_data_element_df = DialMetadataHandler(
        spark=spark, dbutils_obj=dbutils, dial_path=dial_obj.end_point()
    ).get_golden_element_df(metadata_source="dsapp")

    data_element_row = golden_data_element_df.filter(
        golden_data_element_df["data_element_id"] == rule_json["golden_data_element_id"]
    )
    data_element_rec = data_element_row.select("data_element_name").collect()
    if not data_element_rec:
        print("Error in UAT generation, data element name not found for check")
        return
    data_element_name = data_element_rec[0]["data_element_name"]
    logs_id = (data_element_row.select("logs_id").collect())[0]["logs_id"]
    date_created = datetime.today().strftime("%d-%m-%Y")
    sample_dir = (
        f"uat_data/{rule_json['id']}_{logs_id}_{data_element_name}_{date_created}"
    )

    snapshot_date = rule_json["rule"]["parameters"]["snapshot_date"].strftime(
        "%d-%m-%Y"
    )

    total_records_count = df.count()

    counts_df = _prepare_counts_df(
        spark=spark,
        total_count=total_records_count,
        filtered_df=filtered_df,
        out_of_scope_df=out_of_scope_records,
        passing_df=passing_recs,
        hits_df=hits,
        snapshot_date=snapshot_date,
    )
    pk_scope_df = _prepare_pk_scope_df(
        spark=spark,
        total_records_count=total_records_count,
        pk_dict=pk_dict,
        hits_df=hits,
        passing_df=passing_recs,
        out_of_scope_df=out_of_scope_records,
    )
    records_sample_df = _prepare_records_sample_df(
        sample_count=sample_count,
        hits_df=hits,
        passing_df=passing_recs,
        out_of_scope_records=out_of_scope_records,
    )

    excel_buffer = BytesIO()  # To keep the excel file in memory.
    with pd.ExcelWriter(excel_buffer) as writer:
        counts_df.toPandas().to_excel(writer, sheet_name="counts", index=False)
        pk_scope_df.toPandas().to_excel(writer, sheet_name="pk_scope", index=False)
        records_sample_df.toPandas().to_excel(writer, sheet_name="records", index=False)

    # Reset the buffer position to the beginning
    excel_buffer.seek(0)

    file_handler_obj.write_file_to_azure(
        container=dqe_obj.default_container_name,
        data=excel_buffer,
        filename=f"{sample_dir}.xlsx",
    )


def _prepare_counts_df(
    spark: SparkSession,
    total_count: int,
    filtered_df: DataFrame,
    out_of_scope_df: DataFrame,
    passing_df: DataFrame,
    hits_df: DataFrame,
    snapshot_date: str,
) -> DataFrame:
    counts_data = [
        ("Total records", total_count),
        ("Scope records", filtered_df.count()),
        ("Out-of-scope Records", out_of_scope_df.count()),
        ("No-hits", passing_df.count()),
        ("Hits", hits_df.count()),
        ("Snapshot Date", snapshot_date),
    ]

    counts_df = spark.createDataFrame(counts_data, schema=["METRIC", "COUNT"])

    return counts_df


def _prepare_pk_scope_df(
    spark: SparkSession,
    total_records_count: int,
    pk_dict: dict,
    hits_df: DataFrame,
    passing_df: DataFrame,
    out_of_scope_df: DataFrame,
) -> DataFrame:
    if pk_dict:
        if total_records_count < 1000000:
            pk_columns = sorted(list(pk_dict.keys()))
            pk_scope_output = get_pk_scope_data(
                hits_df=hits_df,
                passing_df=passing_df,
                out_of_scope_df=out_of_scope_df,
                primary_key_cols=pk_columns,
            )

        else:
            pk_scope_output = "PK Scope data can't be generated because it contains more than 1M records."
    else:
        pk_scope_output = "No Primary keys"

    if isinstance(pk_scope_output, str):
        pk_scope_output = spark.createDataFrame([("data", pk_scope_output)])

    return pk_scope_output


def _prepare_records_sample_df(
    sample_count: int,
    hits_df: DataFrame,
    passing_df: DataFrame,
    out_of_scope_records: DataFrame,
) -> DataFrame:
    out_of_scope_records = out_of_scope_records.withColumn(
        "DQ_SCOPE", F.lit("out of scope")
    )
    passing_df = passing_df.withColumn("DQ_SCOPE", F.lit("passing"))
    hits_df = hits_df.withColumn("DQ_SCOPE", F.lit("hit"))
    columns_to_select = passing_df.columns
    result_df = (
        out_of_scope_records.limit(sample_count)
        .unionByName(passing_df.limit(sample_count), allowMissingColumns=True)
        .unionByName(hits_df.limit(sample_count), allowMissingColumns=True)
        .select(*columns_to_select)
    )

    # Escape control characters by replacing them with their Unicode escape sequence,
    # because control characters cannot be written into the excel file.
    control_chars_regex = r"[\x00-\x1F\x7F-\x9F]"
    for column_name, column_type in result_df.dtypes:
        if column_type == "string":
            # Replace control characters with their escaped Unicode representation
            result_df = result_df.withColumn(
                column_name,
                F.regexp_replace(F.col(column_name), control_chars_regex, ""),
            )

    # Cast all columns to strings to avoid issues in representation.
    result_df = result_df.select([F.col(c).cast("string") for c in result_df.columns])

    return result_df


def get_pk_scope_data(
    hits_df, passing_df, out_of_scope_df, primary_key_cols
) -> DataFrame:
    not_found_pk_columns = list(
        set(primary_key_cols) - set(hits_df.schema.fieldNames())
    )
    if len(not_found_pk_columns) > 0:
        raise PrimaryKeyColumnNotFoundException(not_found_pk_columns, hits_df.columns)

    hits_recs = hits_df.select(*primary_key_cols).withColumn("DQ_SCOPE", F.lit("hit"))
    passing_recs = passing_df.select(*primary_key_cols).withColumn(
        "DQ_SCOPE", F.lit("passing")
    )
    out_of_scope_recs = out_of_scope_df.select(*primary_key_cols).withColumn(
        "DQ_SCOPE", F.lit("out of scope")
    )

    all_data = hits_recs.union(passing_recs).union(out_of_scope_recs)

    return all_data
