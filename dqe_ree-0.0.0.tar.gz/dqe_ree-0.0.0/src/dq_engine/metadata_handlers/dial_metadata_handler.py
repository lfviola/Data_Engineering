"""Class to interact with dial metadata."""

from pyspark.sql import DataFrame
from typing import Optional

from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StringType, IntegerType, StructField

from dq_engine.utils.helpers import DatabricksHelperFunctions

from typing import Literal


class DialMetadataHandler(DatabricksHelperFunctions):
    """
    Functionality to read, process and retrieves metadata from different
    dial sources such as DSApp and DCApp.
    This class also groups some other methods to interact with this metadata.

    Extending from DatabricksHelperFunctions to have the ability to read files from DIAL.

    """

    METADATA_SCHEMA = StructType(
        [
            StructField("flat_file_uuid", StringType(), True),
            StructField("file_name", StringType(), True),
            StructField("data_attribute_uuid", StringType(), True),
            StructField("column_name", StringType(), True),
            StructField("column_sequence_number", StringType(), True),
            StructField("primary_key", StringType(), True),
            StructField("data_attribute_id", IntegerType(), True),
            StructField("flat_file_id", IntegerType(), True),
        ]
    )

    GOLDEN_ELEMENT_SCHEMA = StructType(
        [
            StructField("data_element_id", StringType(), True),
            StructField("data_element_name", StringType(), True),
        ]
    )

    def get_metadata(
        self, metadata_source: Optional[Literal["dsapp", "dcapp"]] = None
    ) -> DataFrame:
        """Main method to retrieve data attribute and filename metadata"""
        retrieval_methods = {
            "dsapp": self._get_dsapp_metadata,
            "dcapp": self._get_dcapp_metadata,
        }

        if metadata_source is not None:
            if metadata_source in retrieval_methods.keys():
                metadata_df = retrieval_methods[metadata_source]()
                return metadata_df
            else:
                raise ValueError(f"Metadata source '{metadata_source}' not supported.")

        else:
            # Initialize an empty DataFrame
            combined_metadata = self.spark.createDataFrame([], self.METADATA_SCHEMA)

            # Iterate over each retrieval method and combine the results
            for method in retrieval_methods.values():
                result = method()
                combined_metadata = combined_metadata.union(result)

            return combined_metadata

    def get_golden_element_df(
        self, metadata_source: Optional[Literal["dsapp", "dcapp"]] = None
    ) -> DataFrame:
        """Returns the golden element metadata dataframe."""
        retrieval_methods = {
            "dsapp": self._get_dsapp_golden_element_df,
            "dcapp": self._get_dcapp_golden_element_df,
        }

        if metadata_source is not None:
            if metadata_source in retrieval_methods.keys():
                golden_element_df = retrieval_methods[metadata_source]()
            else:
                raise ValueError(f"Metadata source '{metadata_source}' not supported.")

        else:
            # Iterate over each retrieval method and combine the results
            golden_element_df = self.spark.createDataFrame(
                [], self.GOLDEN_ELEMENT_SCHEMA
            )
            for method in retrieval_methods.values():
                result = method()
                golden_element_df = golden_element_df.union(result)

        return golden_element_df

    def _get_dsapp_golden_element_df(self) -> DataFrame:
        return self.read_latest_snapshot_file_to_dataframe(
            "dsapp_goldendataelement", "dial"
        )

    def _get_dcapp_golden_element_df(self) -> DataFrame:
        return self.read_latest_snapshot_file_to_dataframe(
            "dcapp_goldendataelement",
            "dial",  # ToDo: fix file name.
        )

    @staticmethod
    def get_att_id_att_uuid_file_id_map(metadata: DataFrame) -> dict:
        """
        From the given `metadata` retrieves a dictionary mapping
        the data attribute id and, data attribute uuid and flat file id.

        Args:
            metadata: Data attribute metadata dataframe with `data_attribute_id` and `data_attribute_uuid` columns.

        Returns:
            Dictionary in the form {"data_attribute_id":  ("data_attribute_uuid", "flat_file_id"), ...}

        """
        filtered_metadata = metadata.select(
            ["data_attribute_id", "data_attribute_uuid", "flat_file_id"]
        ).filter(metadata["data_attribute_id"].isNotNull())
        att_id_att_uuid_file_id_map = dict(
            filtered_metadata.rdd.map(
                lambda rec: (
                    rec["data_attribute_id"],
                    (rec["data_attribute_uuid"], rec["flat_file_id"]),
                )
            ).collect()
        )
        return att_id_att_uuid_file_id_map

    @staticmethod
    def get_att_uuid_col_name_map(
        metadata: DataFrame, file_name: str = None, reference_att_uuids: list = None
    ) -> dict:
        """
        From the given `metadata` retrieves a dictionary mapping
        the data attribute uuid and column name.

        Args:
            metadata: Data attribute metadata dataframe with `data_attribute_uuid`, `column_name` and `file_name` columns.
            file_name: If provided, it would filter the output for the attributes in the given `file_name`.
            reference_att_uuids: If provided, they will be retrieved as part of the output together with the other uuids.
                It only applies when `file_name` is provided, otherwise all `uuids` are retrieved.
                The reference attributes are specific parameters for reference rules, they are needed when
                the data attribute is present in a separate (reference) table, that we need to use to perform the rule logic.

        Returns:
            Dictionary in the form {"data_attribute_uuid":  "column_name", ...}

        """
        filtered_metadata = (
            metadata.select(["column_name", "data_attribute_uuid", "file_name"])
            .filter(metadata["data_attribute_uuid"].isNotNull())
            .withColumn("column_name", F.upper(metadata["column_name"]))
        )

        if file_name:
            filtered_by_filename = filtered_metadata.filter(
                F.upper(filtered_metadata["file_name"]) == file_name.upper()
            )

            if reference_att_uuids:
                filtered_metadata = filtered_by_filename.union(
                    filtered_metadata.filter(
                        filtered_metadata["data_attribute_uuid"].isin(
                            reference_att_uuids
                        )
                    )
                ).distinct()
            else:
                filtered_metadata = filtered_by_filename

        att_uuid_col_name_map = dict(
            filtered_metadata.rdd.map(
                lambda rec: (rec["data_attribute_uuid"], rec["column_name"])
            ).collect()
        )

        return att_uuid_col_name_map

    def _get_dsapp_metadata(self) -> DataFrame:
        """Reads DSApp metadata and returns a dataframe."""
        dsapp_metadata = self._read_metadata(
            physical_dataset_revision_attribute_file="dsapp_physicaldatasetrevisionattribute",
            physical_dataset_revision_file="dsapp_physicaldatasetrevision",
            data_delivery_revision_file="dsapp_datadeliveryrevision",
            physical_dataset_revision_attribute_legacy_data_attr_file="dsapp_PhysicalDatasetRevisionAttributeLegacyDataAttr",
            data_delivery_legacy_flat_file="dsapp_DataDeliveryLegacyFlatFile",
        )

        return dsapp_metadata

    def _get_dcapp_metadata(self) -> DataFrame:
        """Reads DCApp metadata and returns a dataframe."""
        dcapp_metadata = self._read_metadata(
            physical_dataset_revision_attribute_file="dcapp_PhysicalDatasetRevisionAttribute",
            physical_dataset_revision_file="dcapp_PhysicalDatasetRevision",
            data_delivery_revision_file="dcapp_DataDeliveryRevision",
            physical_dataset_revision_attribute_legacy_data_attr_file="dcapp_PhysicalDatasetRevisionAttributeLegacyDataAttr",
            data_delivery_legacy_flat_file="dcapp_DataDeliveryLegacyFlatFile",
        )

        return dcapp_metadata

    def _read_metadata(
        self,
        physical_dataset_revision_attribute_file: str,
        physical_dataset_revision_file: str,
        data_delivery_revision_file: str,
        physical_dataset_revision_attribute_legacy_data_attr_file: str,
        data_delivery_legacy_flat_file: str,
    ) -> DataFrame:
        """
        Reads the given metadata file names from DIAL and joins its multiple tables to return
        a dataframe with all the required metadata ("flat_file_uuid", "file_name", "data_attribute_uuid",
        "column_name", "column_sequence_number", "primary_key", "data_attribute_id" and "flat_file_id")

        This function runs the following query:
        select
        e.data_delivery_id, -- formerly know as flat file id
        e.file_name,
        attr.physical_attribute_id, -- formerly know as attribute_id
        attr.column_name,
        attr.column_sequence_number,
        attr.is_primary_key
        from
        default.physicaldatasetrevisionattribute_parquet as attr
        inner join default.physicaldatasetrevision_parquet as d on d.stage = 'consumable' and now() between d.effective_from and  d.effective_until and d.physical_dataset_revision_id =  attr.physical_dataset_revision_id
        inner join default.datadeliveryrevision_parquet as e on e.stage = 'consumable' and now() between e.effective_from and  e.effective_until and d.physical_dataset_id = e.physical_dataset_id
        order by e.file_name, attr.column_sequence_number

        """

        physical_attribute_revision_df = self.read_latest_snapshot_file_to_dataframe(
            physical_dataset_revision_attribute_file
        )
        physical_data_revision_df = self.read_latest_snapshot_file_to_dataframe(
            physical_dataset_revision_file
        )
        data_delivery_revision_df = self.read_latest_snapshot_file_to_dataframe(
            data_delivery_revision_file
        )
        physical_dataset_rev_att_leg_attr_df = (
            self.read_latest_snapshot_file_to_dataframe(
                physical_dataset_revision_attribute_legacy_data_attr_file
            )
        )
        data_delivery_leg_flat_file_df = self.read_latest_snapshot_file_to_dataframe(
            data_delivery_legacy_flat_file
        )

        current_timestamp = F.current_timestamp()
        stage_value = "consumable"

        filtered_physical_data_revision_df = physical_data_revision_df.filter(
            (physical_data_revision_df.stage == stage_value)
            & (
                current_timestamp.between(
                    physical_data_revision_df.effective_from,
                    physical_data_revision_df.effective_until,
                )
            )
        )
        filtered_data_delivery_revision_df = data_delivery_revision_df.filter(
            (data_delivery_revision_df.stage == stage_value)
            & (
                current_timestamp.between(
                    data_delivery_revision_df.effective_from,
                    data_delivery_revision_df.effective_until,
                )
            )
        )
        result_df = (
            physical_attribute_revision_df.join(
                filtered_physical_data_revision_df,
                physical_attribute_revision_df.physical_dataset_revision_id
                == filtered_physical_data_revision_df.physical_dataset_revision_id,
                how="inner",
            )
            .join(
                filtered_data_delivery_revision_df,
                filtered_data_delivery_revision_df.physical_dataset_id
                == filtered_physical_data_revision_df.physical_dataset_id,
            )
            .join(
                physical_dataset_rev_att_leg_attr_df,
                physical_dataset_rev_att_leg_attr_df.physical_attribute_id
                == physical_attribute_revision_df.physical_attribute_id,
            )
            .join(
                data_delivery_leg_flat_file_df,
                data_delivery_leg_flat_file_df.data_delivery_id
                == filtered_data_delivery_revision_df.data_delivery_id,
            )
            .select(
                filtered_data_delivery_revision_df.data_delivery_id.alias(
                    "flat_file_uuid"
                ),
                filtered_data_delivery_revision_df.file_name.alias("file_name"),
                physical_attribute_revision_df.physical_attribute_id.alias(
                    "data_attribute_uuid"
                ),
                physical_attribute_revision_df.column_name.alias("column_name"),
                physical_attribute_revision_df.column_sequence_number.alias(
                    "column_sequence_number"
                ),
                F.when(physical_attribute_revision_df.is_primary_key == True, "true")  # noqa: E712
                .otherwise("false")
                .alias("primary_key"),
                physical_dataset_rev_att_leg_attr_df.data_attribute_id.alias(
                    "data_attribute_id"
                ),
                data_delivery_leg_flat_file_df.flat_file_id.alias("flat_file_id"),
            )
        ).orderBy(
            filtered_data_delivery_revision_df.file_name.asc(),
            physical_attribute_revision_df.column_sequence_number.asc(),
        )

        return result_df
