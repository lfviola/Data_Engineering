"""Class to interact with dq dataset metadata."""

from pyspark.sql import DataFrame
from typing import Optional

from pyspark.sql import functions as F
from pyspark.sql.types import StringType

from pyspark.sql import SparkSession
from dq_engine.utils.helpers import AzureFileHandler


class DQDatasetMetadataHandler:
    """
    Functionality to (for now only) retrieve dq dataset metadata.
    """

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def get_metadata(
        self,
        file_handler: AzureFileHandler,
        filename: Optional[str] = None,
        file_path: Optional[str] = "dq_dataset_meta_data/dq_datasets_v1.json",
    ) -> DataFrame:
        """Loads metadata export for DQ Library in dataframe format and, if specified, reads the metadata for only a specified dq dataset."""
        json_data = file_handler.read_file_from_container_azure(  # noqa
            container="dqe-data", file_path=file_path
        )
        # Decode the bytes to a UTF-8 string
        json_data = json_data.decode("utf-8")

        # Parse the JSON string into a DataFrame
        dq_dataset_metadata_df = self.spark.read.json(
            self.spark.sparkContext.parallelize([json_data])
        )

        # Explode the dq_datasets array to access individual datasets
        dq_dataset_metadata_df = dq_dataset_metadata_df.select(
            F.explode(F.col("dq_datasets")).alias("dq_dataset")
        )

        # Filter for the specific dataset by name, if provided
        if filename:
            filtered_dq_dataset_metadata_df = dq_dataset_metadata_df.filter(
                F.lower(F.col("dq_dataset.name")) == filename.lower()
            )
        else:
            filtered_dq_dataset_metadata_df = dq_dataset_metadata_df

        filtered_dq_dataset_metadata_df = filtered_dq_dataset_metadata_df.select(
            F.lower(F.col("dq_dataset.name")).alias("dq_dataset_name"),
            F.col("dq_dataset.columns"),
        )

        # Explode the columns array to create a row per column dictionary
        columns_metadata_df = filtered_dq_dataset_metadata_df.select(
            F.col("dq_dataset_name"), F.explode(F.col("columns")).alias("column")
        )

        # Flatten the column dictionaries into separate columns
        flattened_metadata_df = columns_metadata_df.select(
            F.col("dq_dataset_name"),
            F.col("column.column_name").alias("column_name"),
            F.col("column.uuid").alias("uuid"),
            F.col("column.data_attribute_id").alias("data_attribute_id"),
            F.col("column.data_attribute_uuid").alias("data_attribute_uuid"),
            F.col("column.flat_file_id").alias("flat_file_id"),
            F.col("column.primary_key").cast(StringType()).alias("primary_key"),
        )
        return flattened_metadata_df
