"""Helpers to interact with metadata."""

from pyspark.sql import DataFrame
from typing import Optional

from pyspark.sql import functions as F
from pyspark.sql.types import Dict


def retrieve_run_metadata(
    dial_metadata: DataFrame,
    file_name: str,
    dq_dataset_metadata: Optional[DataFrame] = None,
    reference_att_uuids: list = [],
) -> DataFrame:
    """
    Retrieves metadata needed at the time of running a DQ check.
    This can either be dial metadata, or a union of dial metadata and dq dataset metadata.

    Raises a ValueError in the odd case that custom created dq dataset uuid's overlap with dial generated uuid's.
    """
    dial_file_metadata = dial_metadata.filter(
        F.lower(dial_metadata["file_name"]) == file_name.lower()
    )
    run_metadata = dial_file_metadata.select(
        "data_attribute_uuid", "column_name", "file_name", "data_attribute_id"
    )

    if reference_att_uuids:
        run_metadata = (
            dial_metadata.filter(
                dial_metadata["data_attribute_uuid"].isin(reference_att_uuids)
            )
            .select(
                "data_attribute_uuid", "column_name", "file_name", "data_attribute_id"
            )
            .union(run_metadata)
        )
    if dq_dataset_metadata:
        dq_selected = dq_dataset_metadata.select(
            dq_dataset_metadata["uuid"].alias("data_attribute_uuid"),
            "column_name",
            dq_dataset_metadata["dq_dataset_name"].alias("file_name"),
            "data_attribute_id",
        )
        dq_ids = dq_selected.select("data_attribute_uuid").distinct()
        dial_ids = run_metadata.select("data_attribute_uuid").distinct()

        overlapping_ids = dq_ids.intersect(dial_ids)

        if overlapping_ids.count() > 0:
            raise ValueError(
                "Overlapping UUIDs found between dq dataset metadata and dial metadata."
            )

        run_metadata = run_metadata.union(dq_selected)

    return run_metadata


def fetch_flat_file_id(
    metadata_df: DataFrame, condition_column, condition_value
) -> str:
    """Helper function to fetch a flat file ID based on a condition."""
    flat_file_id_row = (
        metadata_df.filter(condition_column == condition_value)
        .select(metadata_df.flat_file_id)
        .distinct()
        .collect()
    )
    try:
        flat_file_id_value = flat_file_id_row[0]["flat_file_id"]
    except Exception as e:
        raise ValueError(
            "Flat file id could not be extracted. Please check metadata and/or filename"
        ) from e

    return str(flat_file_id_value)


def get_flat_file_id(
    metadata_df: DataFrame, file_name: str, file_type: str, pk_struct: Dict
) -> str:
    """
    Retrieve the flat file ID based on the file type and other parameters.
    """
    if file_type != "dq_dataset":
        return fetch_flat_file_id(
            metadata_df, F.lower(metadata_df.file_name), file_name.lower()
        )
    else:
        first_key = next(iter(pk_struct))
        data_attribute_id = pk_struct[first_key]
        return fetch_flat_file_id(
            metadata_df, metadata_df.data_attribute_id, data_attribute_id
        )
