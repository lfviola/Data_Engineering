import ast
import datetime
import json
import logging
import os
from collections import defaultdict

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    ArrayType,
    IntegerType,
    MapType,
    StringType,
    StructField,
    StructType,
)

from dq_engine.lib import (
    get_data_attribute_parameter_dict,
    get_reference_data_attribute_parameter_dict,
    rule_json_export,
)
from dq_engine.rules.custom_exceptions import (
    DataAttributeNotFoundValidationException,
    FileNameNotFoundException,
    FileNotFoundException,
    FileReadException,
)
from dq_engine.utils.check_output import log_check_output
from dq_engine.utils.helpers import DatabricksHelperFunctions

logger = logging.getLogger(__name__)

REFERENCE_DATA_ATTRIBUTE_PARAMETER_DICT = get_reference_data_attribute_parameter_dict()
DATA_ATTRIBUTE_PARAMETER_DICT = get_data_attribute_parameter_dict()
REFERENCE_RULES = list(REFERENCE_DATA_ATTRIBUTE_PARAMETER_DICT.keys())

# Define the schema for the JSON data
JSON_SCHEMA = StructType(
    [
        StructField("golden_data_element_id", IntegerType(), nullable=True),
        StructField("id", StringType(), nullable=True),
        StructField("description", StringType(), nullable=True),
        StructField("status_id", StringType(), nullable=True),
        StructField("source_id", StringType(), nullable=True),
        StructField(
            "rule",
            StructType(
                [
                    StructField("technical_name", StringType(), nullable=True),
                    StructField("functional_name", StringType(), nullable=True),
                    StructField(
                        "parameters", MapType(StringType(), StringType()), nullable=True
                    ),
                    StructField(
                        "data_attribute",
                        StructType(
                            [
                                StructField(
                                    "data_attribute_uuid", StringType(), nullable=True
                                ),
                                StructField(
                                    "data_attribute_source", StringType(), nullable=True
                                ),
                            ]
                        ),
                        nullable=True,
                    ),
                    StructField(
                        "dq_dataset_data_attribute",
                        StructType(
                            [
                                StructField(
                                    "data_attribute_uuid", StringType(), nullable=True
                                )
                            ]
                        ),
                        nullable=True,
                    ),
                ]
            ),
            nullable=True,
        ),
        StructField(
            "filters",
            ArrayType(
                StructType(
                    [
                        StructField(
                            "parameters",
                            MapType(StringType(), StringType()),
                            nullable=True,
                        ),
                        StructField("description", StringType(), nullable=True),
                        StructField(
                            "data_attribute",
                            StructType(
                                [
                                    StructField(
                                        "data_attribute_uuid",
                                        StringType(),
                                        nullable=True,
                                    ),
                                    StructField(
                                        "data_attribute_source",
                                        StringType(),
                                        nullable=True,
                                    ),
                                ]
                            ),
                            nullable=True,
                        ),
                        StructField("technical_name", StringType(), nullable=True),
                    ]
                )
            ),
            nullable=True,
        ),
    ]
)


class ChecksParser:
    def __init__(
        self,
        spark,
        dqrem_path,
        invalid_checks_folder,
        checks_dir,
        new_checks_dir,
        databricks_helpers: DatabricksHelperFunctions,
        dial_metadata: DataFrame,
        dq_dataset_metadata: DataFrame,
        logs_directory: str = "check_outputs",
        dq_lib_logs_directory: str = "check_outputs",
    ) -> None:
        self.spark = spark
        self.dqrem_path: str = dqrem_path
        self.checks_dir = os.path.join(self.dqrem_path, checks_dir)
        self.new_checks_dir = os.path.join(self.dqrem_path, new_checks_dir)
        self.databricks_helpers: DatabricksHelperFunctions = databricks_helpers
        self.invalid_checks_folder = invalid_checks_folder
        self.dial_metadata = dial_metadata
        self.dq_dataset_metadata = dq_dataset_metadata
        self.cache_outputs: dict = {}
        self.logs_directory = logs_directory
        self.dq_lib_logs_directory = dq_lib_logs_directory
        self.logger = logger

    def add_filename_to_checks_df(
        self, checks_dataframe: DataFrame, filters_dataframe: DataFrame
    ) -> tuple[DataFrame, DataFrame, DataFrame]:
        """
        Method to find files needed to execute DQ checks.
        Adds 2 columns to check dataframe:
        - file_name: Name of flat file linked to data attribute uuid.
        - file_type: Either 'dsapp' or 'dq_dataset'.
        """
        df = self.parse_dq_dataset_data(checks_dataframe)
        # Filter records where dq_dataset.data_attribute_uuid is null for the first join
        dial_checks_df = df.filter(df["dq_dataset"]["data_attribute_uuid"].isNull())
        # Add filename to the dataframe
        dial_checks_with_filename_added = dial_checks_df.join(
            self.dial_metadata.withColumnRenamed("file_name", "dial_file_name"),
            "data_attribute_uuid",
            how="left",
        ).select(
            dial_checks_df["*"],
            F.lower("dial_file_name").alias("file_name"),
            F.lower(df["data_attribute_source"]).alias("file_type"),
        )

        # Separate unmatched rows where file_name is Null
        dq_dataset_checks_df = df.filter(
            df["dq_dataset"]["data_attribute_uuid"].isNotNull()
        )

        # Join unmatched rows with dq_dataset_metadata
        dq_dataset_checks_with_filename_added = dq_dataset_checks_df.join(
            self.dq_dataset_metadata,
            dq_dataset_checks_df["dq_dataset"]["data_attribute_uuid"]
            == self.dq_dataset_metadata["uuid"],
            how="left",
        ).select(
            dq_dataset_checks_df["*"],
            F.lower(self.dq_dataset_metadata["dq_dataset_name"]).alias("file_name"),
            F.lit("dq_dataset").alias("file_type"),
        )

        # Combine matched and processed unmatched DataFrames
        dqrem_checks_with_filename_added = dial_checks_with_filename_added.union(
            dq_dataset_checks_with_filename_added
        )

        checks_without_filename = dqrem_checks_with_filename_added.filter(
            dqrem_checks_with_filename_added["file_name"].isNull()
        )
        checks_with_filename = dqrem_checks_with_filename_added.filter(
            dqrem_checks_with_filename_added["file_name"].isNotNull()
        )
        check_ids = [check["id"] for check in checks_with_filename.collect()]
        filename_checks_filters_dataframe = filters_dataframe.filter(
            filters_dataframe["dq_check_id"].isin(check_ids)
        )

        return (
            checks_with_filename,
            filename_checks_filters_dataframe,
            checks_without_filename,
        )

    @staticmethod
    def parse_dq_dataset_data(checks_dataframe) -> DataFrame:
        """Extract DQ dataset parameters"""
        # Define schema for the JSON content
        schema = StructType(
            [
                StructField("data_attribute_uuid", StringType(), True),
                StructField("data_attribute_source", StringType(), True),
            ]
        )
        # Extract JSON substring and cast to a new column
        unpacked_checks_dataframe = checks_dataframe.withColumn(
            "dq_dataset",
            F.from_json(
                F.regexp_replace(F.col("dq_dataset"), r"dq_dataset: ", ""), schema
            ),
        )
        return unpacked_checks_dataframe

    def get_filename_snapshot_date_dataframe(
        self, filenames: list[str], file_type: str
    ) -> tuple[list, list]:
        """Method to get snapshot paths of a list of filenames.

        Currently only supports 'dsapp', 'dcapp' and 'dq_dataset' files.
        """
        file_type_location_mapping = {
            "dsapp": "dial",
            "dcapp": "dial",
            "dq_dataset": "dqrem",
        }
        supported_file_types = file_type_location_mapping.keys()

        if file_type not in supported_file_types:
            raise ValueError(
                f"Data attribute source not supported. Currently only files from the following sources are supported: {supported_file_types}"
            )

        location_data: list[dict] = []
        not_found_files: list = []
        for name in filenames:
            try:
                snapshot_path = self.databricks_helpers.get_latest_snapshot_file_path(
                    file_name=name, location=file_type_location_mapping[file_type]
                )
                location_data.append(
                    {
                        "name": name,
                        "snapshot_path": snapshot_path,
                        "file_type": file_type,
                    }
                )
            except (FileNotFoundException, FileReadException, IndexError) as e:
                if isinstance(
                    e, IndexError
                ):  # IndexError due to no snapshots being present
                    logger.error(
                        f"Dataset {name} of type {file_type} does not contain any snapshot dates"
                    )
                not_found_files.append([name, file_type_location_mapping[file_type]])

        return location_data, not_found_files

    def add_extra_columns(
        self, data_frame: DataFrame
    ) -> tuple[DataFrame, list, DataFrame]:
        """Adds 'snapshot_path' and 'md5_hash' columns to check dataframe.

        Returns:
        - Checks dataframe with added columns
        - List of filenames that could not be found
        - Dataframe of checks without snapshot
        """
        latest_snapshots_data: list[dict] = []
        all_not_found_files: list[list] = []
        # Retrieve distinct file types from the DataFrame
        unique_file_types = [
            row["file_type"]
            for row in data_frame.select("file_type").distinct().collect()
        ]

        # Iterate over each file type
        for file_type in unique_file_types:
            # Collect distinct file names for the current file type
            file_names = [
                row["file_name"]
                for row in data_frame.select("file_name")
                .filter(data_frame["file_type"] == file_type)
                .distinct()
                .collect()
            ]

            # Retrieve snapshot dates for the current file type
            snapshot_data, not_found_files = self.get_filename_snapshot_date_dataframe(
                file_names, file_type
            )

            # Add the snapshot data to the list
            latest_snapshots_data.extend(snapshot_data)
            all_not_found_files.extend(not_found_files)

        latest_filename_snapshot_dataframe: DataFrame = self.spark.createDataFrame(
            latest_snapshots_data
        )
        data_with_snapshot_date: DataFrame = data_frame.join(
            latest_filename_snapshot_dataframe,
            (data_frame.file_name == latest_filename_snapshot_dataframe.name)
            & (data_frame.file_type == latest_filename_snapshot_dataframe.file_type),
            how="left",
        ).select(data_frame["*"], latest_filename_snapshot_dataframe["snapshot_path"])

        checks_with_snapshot = data_with_snapshot_date.filter(
            data_with_snapshot_date["snapshot_path"].isNotNull()
        )
        checks_without_snapshot = data_with_snapshot_date.filter(
            data_with_snapshot_date["snapshot_path"].isNull()
        )

        data_frame_with_md5 = checks_with_snapshot.withColumn(
            "str_json", data_frame["check_json"].cast("string")
        ).withColumn(
            "md5_hash",
            F.md5(F.concat_ws(" ", *["str_json", "file_name", "snapshot_path"])),
        )

        return (
            data_frame_with_md5.drop("str_json"),
            all_not_found_files,
            checks_without_snapshot,
        )

    def return_check_json(
        self, rule_data, filter_data, functional_name_technical_name_map
    ) -> dict:
        """Returns a JSON representation of a check."""
        rule_dict = {
            "technical_name": functional_name_technical_name_map.get(
                rule_data.dq_rule, rule_data.dq_rule
            ),
            "functional_name": rule_data.dq_rule,
            "parameters": ast.literal_eval(rule_data["rule_parameters"]),
            "data_attribute": {
                "data_attribute_uuid": rule_data["data_attribute_uuid"],
                "data_attribute_source": rule_data["data_attribute_source"],
            },
            "dq_dataset_data_attribute": {
                "data_attribute_uuid": rule_data["dq_dataset"]["data_attribute_uuid"]
            },
        }
        filter_dict = [
            {
                "parameters": ast.literal_eval(_filter["parameters"]),
                "description": _filter["description"],
                "data_attribute": {
                    "data_attribute_uuid": _filter["data_attribute_uuid"],
                    "data_attribute_source": rule_data["data_attribute_source"],
                },
                "technical_name": functional_name_technical_name_map.get(
                    _filter["dq_rule"], _filter["dq_rule"]
                ),
            }
            for _filter in filter_data
        ]
        rule_json = {
            "golden_data_element_id": rule_data["golden_data_element_id"],
            "id": rule_data["id"],
            "check_version": rule_data["check_version"],
            "description": rule_data["functional_description"],
            "status_id": rule_data["business_status"],
            "source_id": rule_data["dq_rule_source"],
            "rule": rule_dict,
            "filters": filter_dict,
            "file_name": rule_data["file_name"],
        }

        return rule_json

    def convert_checks_dataframes_to_json(
        self,
        checks_df: DataFrame,
        filters_df: DataFrame,
        functional_name_technical_name_map: dict,
    ) -> list:
        """return checks dictionary from checks dataframe"""
        checks_list = []
        all_checks = checks_df.collect()
        all_filters = filters_df.collect()
        filters_dict = defaultdict(list)
        for _filter in all_filters:
            filters_dict[_filter["dq_check_id"]].append(_filter)
        for check in all_checks:
            filter_data = filters_dict[check["id"]]
            check_json = self.return_check_json(
                check,
                filter_data=filter_data,
                functional_name_technical_name_map=functional_name_technical_name_map,
            )
            checks_list.append(check_json)
        return checks_list

    def log_invalid_checks(self, invalid_checks_df: DataFrame, path: str) -> None:
        """Logs invalid checks to storage account."""
        invalid_checks_df.write.format("parquet").mode("overwrite").save(path=path)

    def not_found_files_errors(self, files_list):
        """Logs filenames of files not found on DIAL."""
        out_folder = os.path.join(self.dqrem_path, self.invalid_checks_folder)
        out_data = "\n".join(
            ["filename,location"] + [",".join(rec) for rec in files_list]
        )
        self.databricks_helpers.write_text_files(
            path=os.path.join(
                out_folder,
                f"not_found_files_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.csv",
            ),
            contents=out_data,
            overwrite=True,
        )

    def compare_checks_and_return_new_checks(
        self, all_checks_df: DataFrame, old_checks_df: DataFrame
    ) -> DataFrame:
        """Compares an old and a new checks dataframe and returns new/updated checks."""
        old_checks = old_checks_df
        new_checks = all_checks_df.join(
            old_checks,
            (all_checks_df["id"] == old_checks["id"])
            & (all_checks_df["md5_hash"] == old_checks["md5_hash"]),
            how="left_anti",
        ).select(all_checks_df["*"])
        return new_checks

    def save_parquet(self, data_frame: DataFrame, mode: str, path: str) -> None:
        """Saves a dataframe to the storage account."""
        data_frame.write.format("parquet").mode(mode).save(path)

    def merge_checks_and_filters_dataframes(self, checks_df, filters_df):
        """Merges the dataframes for checks and filters on the 'check_id'."""
        functional_name_technical_name_map = {
            rule["name"]: rule["technical_name"] for rule in rule_json_export()
        }
        checks_json_data = [
            (check["id"], str(check))
            for check in self.convert_checks_dataframes_to_json(
                checks_df, filters_df, functional_name_technical_name_map
            )
        ]
        df = self.spark.createDataFrame(
            data=checks_json_data, schema=["check_id", "check_json"]
        )
        return checks_df.join(df, checks_df["id"] == df["check_id"]).select(
            checks_df["*"], df["check_json"]
        )

    def refresh_checks_and_return_new_checks_from_dataframe(
        self,
        checks_dataframe: DataFrame,
        filters_dataframe: DataFrame,
        old_checks_df: DataFrame | None = None,
    ) -> tuple[list, DataFrame, DataFrame, DataFrame, DataFrame, DataFrame]:
        """refresh dq checks parquet with latest checks and return new/updated checks since the last run

        Args:
            file_path (str): dq checks json file path.
            write_outputs (bool, optional): option to write the output errors and dataframes. Defaults to True.

        Returns:
            DataFrame: new checks which have been added/updated since the last run.
        """
        # add filename to checks df
        (
            checks_df,
            filter_df,
            checks_without_filename,
        ) = self.add_filename_to_checks_df(checks_dataframe, filters_dataframe)
        full_checks_df = self.merge_checks_and_filters_dataframes(checks_df, filter_df)
        (
            all_checks,
            not_found_files,
            checks_without_snapshot,
        ) = self.add_extra_columns(full_checks_df)

        all_checks, checks_with_attribute_errors = self.validate_attributes_in_rule(
            all_checks
        )

        if old_checks_df:
            new_checks = self.compare_checks_and_return_new_checks(
                all_checks, old_checks_df
            )
        else:
            new_checks = all_checks

        return (
            not_found_files,
            new_checks,
            all_checks,
            checks_without_filename,
            checks_without_snapshot,
            checks_with_attribute_errors,
        )

    def compare_attributes_with_metadata(
        self,
        all_attributes_dial_regular,
        all_attributes_dq_dataset_regular,
        all_attributes_reference,
    ) -> tuple[list, DataFrame]:
        """
        Compares data attributes extracted from rules and filters against main or main reference attribute. File names in metadata should align.

        :param all_attributes_dial_regular: DataFrame containing regular data attributes extracted from checks defined on dial files.
        :param all_attributes_dq_dataset_regular: DataFrame containing regular data attributes extracted from checks defined on dq datasets.
        :param all_attributes_reference: DataFrame containing all extracted reference data attributes.
        :return missing_ids: list containing check ids or checks containing incorrect data attributes.
        :return missing_attributes_df: DataFrame with errors for data attributes not belonging to the specified file.
        """
        # Perform a left anti join to find attributes not belonging to the specified file
        missing_attributes_dial = all_attributes_dial_regular.join(
            self.dial_metadata,
            (
                all_attributes_dial_regular["attribute"]
                == self.dial_metadata["data_attribute_uuid"]
            )
            & (
                F.lower(all_attributes_dial_regular["original_file_name"])
                == F.lower(self.dial_metadata["file_name"])
            ),
            "left_anti",
        ).select(
            F.col("id"),
            F.col("attribute"),
            F.col("original_file_name"),
            F.col("rule_type"),
            F.col("attribute_type"),
            F.col("check_json"),
        )

        # Perform the self-join to get and compare the filenames in a single operation
        missing_attributes_reference = (
            all_attributes_reference.alias("exp")
            .join(
                self.dial_metadata.alias("meta_ref"),
                F.col("exp.reference_data_attribute_uuid")
                == F.col("meta_ref.data_attribute_uuid"),
                "inner",
            )
            .join(
                self.dial_metadata.alias("meta_attr"),
                F.col("exp.attribute") == F.col("meta_attr.data_attribute_uuid"),
                "left",
            )
            .select(
                F.col("exp.id"),
                F.col("exp.attribute"),
                F.col("meta_ref.file_name").alias("reference_file_name"),
                F.col("meta_attr.file_name").alias("attribute_file_name"),
                F.col("exp.rule_type"),
                F.col("exp.attribute_type"),
                F.col("exp.check_json"),
            )
            .filter(
                (
                    F.lower(F.col("reference_file_name"))
                    != F.lower(F.col("attribute_file_name"))
                )
                | (F.col("reference_file_name").isNull())
                | (F.col("attribute_file_name").isNull())
            )
            .select(
                F.col("id"),
                F.col("attribute"),
                F.col("reference_file_name").alias("original_file_name"),
                F.col("rule_type"),
                F.col("attribute_type"),
                F.col("check_json"),
            )
        )

        missing_attributes_dq_dataset = all_attributes_dq_dataset_regular.join(
            self.dq_dataset_metadata,
            (
                all_attributes_dq_dataset_regular["attribute"]
                == self.dq_dataset_metadata["uuid"]
            )
            & (
                all_attributes_dq_dataset_regular["original_file_name"]
                == self.dq_dataset_metadata["dq_dataset_name"]
            ),
            "left_anti",
        ).select(
            F.col("id"),
            F.col("attribute"),
            F.col("original_file_name"),
            F.col("rule_type"),
            F.col("attribute_type"),
            F.col("check_json"),
        )

        missing_attributes_df = missing_attributes_dial.union(
            missing_attributes_dq_dataset
        ).union(missing_attributes_reference)
        # Filter for edge cases where an empty array of data attributes is present
        missing_attributes_df = missing_attributes_df.filter(
            (F.col("attribute") != "[]")
        )
        missing_ids = (
            missing_attributes_df.select("id")
            .distinct()
            .rdd.flatMap(lambda x: x)
            .collect()
        )

        return missing_ids, missing_attributes_df

    def validate_attributes_in_rule(
        self, checks_df: DataFrame
    ) -> tuple[DataFrame, DataFrame]:
        """
        Validates whether data attributes in the checks DataFrame belong to the same file and exist in the metadata DataFrame.

        :param checks_df: DataFrame containing parsed DQ checks.
        :return filtered_checks_df: DataFrame containing error free parsed DQ checks.
        :return missing_attributes_df: DataFrame with errors for data attributes not belonging to the specified file.
        """

        # Register UDF
        parse_and_flatten_udf = F.udf(parse_and_flatten, ArrayType(StringType()))
        get_parameters_combined_udf = F.udf(
            get_parameters_combined, ArrayType(StringType())
        )

        # Parse the JSON string column into a structured format
        copy_checks_df = checks_df.withColumn(
            "check_json", F.regexp_replace("check_json", "None", "null")
        )
        copy_checks_df = copy_checks_df.withColumn(
            "parsed_json", F.from_json(F.col("check_json"), JSON_SCHEMA)
        )
        copy_checks_df = copy_checks_df.withColumn(
            "check_json", F.regexp_replace("check_json", "null", "None")
        )

        # Extract rule attributes
        rule_attributes = copy_checks_df.select(
            F.col("parsed_json.id").alias("id"),
            F.when(
                F.col("parsed_json.rule.dq_dataset_data_attribute.data_attribute_uuid")
                != "null",
                F.col("parsed_json.rule.dq_dataset_data_attribute.data_attribute_uuid"),
            )
            .otherwise(F.col("parsed_json.rule.data_attribute.data_attribute_uuid"))
            .alias("main_attribute"),
            F.transform(
                get_parameters_combined_udf(
                    F.col("parsed_json.rule.technical_name"), F.lit(False)
                ),
                lambda param: F.col("parsed_json.rule.parameters")[param],
            ).alias("regular_attributes"),
            F.when(
                F.col("parsed_json.rule.technical_name").isin(REFERENCE_RULES),
                F.transform(
                    get_parameters_combined_udf(
                        F.col("parsed_json.rule.technical_name"), F.lit(True)
                    ),
                    lambda param: F.col("parsed_json.rule.parameters")[param],
                ),
            )
            .otherwise(F.array())
            .alias("reference_attributes"),
            F.when(
                F.col("parsed_json.rule.technical_name").isin(REFERENCE_RULES),
                F.col("parsed_json.rule.parameters.reference_data_attribute_id"),
            ).alias("reference_data_attribute_uuid"),
            F.col("file_name").alias("original_file_name"),
            F.col("file_type"),
            F.lit("rule").alias("rule_type"),
            F.col("check_json"),
        ).filter(F.col("main_attribute").isNotNull())

        # Extract filter attributes
        filter_attributes = copy_checks_df.select(
            F.col("parsed_json.id").alias("id"),
            F.col("parsed_json.rule.data_attribute.data_attribute_uuid").alias(
                "main_attribute"
            ),
            F.explode("parsed_json.filters").alias("filter"),
            F.col("file_name"),
            F.col("file_type"),
            F.col("check_json"),
        ).select(
            F.col("id"),
            F.col("main_attribute"),
            F.array_union(
                F.array(F.col("filter.data_attribute.data_attribute_uuid")),
                F.transform(
                    get_parameters_combined_udf(F.col("filter.technical_name")),
                    lambda param: F.col("filter.parameters")[param],
                ),
            ).alias("regular_attributes"),
            F.when(
                F.col("filter.technical_name").isin(REFERENCE_RULES),
                F.transform(
                    get_parameters_combined_udf(
                        F.col("filter.technical_name"), F.lit(True)
                    ),
                    lambda param: F.col("filter.parameters")[param],
                ),
            )
            .otherwise(F.array())
            .alias("reference_attributes"),
            F.when(
                F.col("filter.technical_name").isin(REFERENCE_RULES),
                F.col("filter.parameters.reference_data_attribute_id"),
            ).alias("reference_data_attribute_uuid"),
            F.col("file_name").alias("original_file_name"),
            F.col("file_type"),
            F.lit("filter").alias("rule_type"),
            F.col("check_json"),
        )
        # Combine all attributes
        all_attributes = rule_attributes.union(filter_attributes)

        # Parse and flatten attributes
        all_attributes = all_attributes.withColumn(
            "regular_attributes", parse_and_flatten_udf(F.col("regular_attributes"))
        ).withColumn(
            "reference_attributes", parse_and_flatten_udf(F.col("reference_attributes"))
        )

        exploded_regular_attributes = all_attributes.select(
            F.col("id"),
            F.explode(F.col("regular_attributes")).alias("attribute"),
            F.col("original_file_name"),
            F.col("file_type"),
            F.col("rule_type"),
            F.lit("regular").alias("attribute_type"),
            F.col("check_json"),
        ).filter(F.col("attribute").isNotNull())

        exploded_reference_attributes = all_attributes.select(
            F.col("id"),
            F.explode(F.col("reference_attributes")).alias("attribute"),
            F.col("reference_data_attribute_uuid"),
            F.col("file_type"),
            F.col("rule_type"),
            F.lit("reference").alias("attribute_type"),
            F.col("check_json"),
        ).filter(F.col("attribute").isNotNull())

        all_attributes_dial_regular = exploded_regular_attributes.filter(
            exploded_regular_attributes["file_type"] != "dq_dataset"
        )

        all_attributes_dial_reference = exploded_reference_attributes.filter(
            exploded_reference_attributes["file_type"] != "dq_dataset"
        )
        all_attributes_dq_dataset_reference = exploded_reference_attributes.filter(
            exploded_reference_attributes["file_type"] == "dq_dataset"
        )
        all_attributes_reference = all_attributes_dial_reference.union(
            all_attributes_dq_dataset_reference
        )

        all_attributes_dq_dataset_regular = exploded_regular_attributes.filter(
            exploded_regular_attributes["file_type"] == "dq_dataset"
        )

        missing_ids, missing_attributes_df = self.compare_attributes_with_metadata(
            all_attributes_dial_regular,
            all_attributes_dq_dataset_regular,
            all_attributes_reference,
        )

        filtered_checks_df = checks_df.filter(~checks_df["id"].isin(missing_ids))

        return filtered_checks_df, missing_attributes_df

    def get_new_checks(
        self, checks_parquet_path: str, filters_parquet_path: str
    ) -> DataFrame:
        """Get new checks, save parquets and return new checks dataframe.

        To get the new checks, it loads current checks and checks from the previous run and compares them to get the new and updated checks.
        This is an optimization to avoid running same checks that where executed in a previous run since the result would be the same.

        Args:
            checks_parquet_path: Full path of parquet file containing the checks.
            filters_parquet_path: Full path of parquet file containing the filters.

        Returns:
            Dataframe of the new checks.

        Side Effects:
            This method writes outputs to external location.
            Parquet files for all checks and new checks are written into storage account.
            For checks without filename and checks without snapshot, a json file with error details
            is stored in storage account directory "check_outputs".

        """
        if not self.databricks_helpers.check_file_exists(self.checks_dir):
            old_checks_df = None
        else:
            old_checks_df = self.spark.read.parquet(self.checks_dir)
        checks_dataframe = self.spark.read.parquet(checks_parquet_path)
        filters_dataframe = self.spark.read.parquet(filters_parquet_path)
        (
            not_found_files,
            new_checks_df,
            all_checks_df,
            checks_without_filename_df,
            checks_without_snapshot,
            checks_with_attribute_errors,
        ) = self.refresh_checks_and_return_new_checks_from_dataframe(
            checks_dataframe, filters_dataframe, old_checks_df
        )

        self.cache_outputs = {
            "not_found_files": not_found_files,
            "new_checks_df": new_checks_df,
            "all_checks_df": all_checks_df,
            "checks_without_filename_df": checks_without_filename_df,
            "filters_dataframe": filters_dataframe,
            "checks_without_snapshot": checks_without_snapshot,
            "checks_with_attribute_errors": checks_with_attribute_errors,
        }
        self.write_outputs()
        return self.spark.read.parquet(self.new_checks_dir)

    def write_outputs(self):
        """Writes error logs and check dataframes to storage account."""
        datetime_str = datetime.datetime.now().strftime("%Y%m%d_%H%M")
        functional_name_technical_name_map = {
            rule["name"]: rule["technical_name"] for rule in rule_json_export()
        }
        checks_with_attribute_errors = self.cache_outputs[
            "checks_with_attribute_errors"
        ]
        errors_grouped = checks_with_attribute_errors.groupBy("id").agg(
            F.collect_list("attribute").alias("attributes"),
            F.collect_list("original_file_name").alias("file_names"),
            F.collect_list("rule_type").alias("rule_types"),
            F.collect_list("attribute_type").alias("attribute_types"),
            F.first("check_json").alias("check_json"),
        )
        for row in errors_grouped.collect():
            error_messages = [
                DataAttributeNotFoundValidationException(attr, file, rule, attr_type)
                for attr, file, rule, attr_type in zip(
                    row["attributes"],
                    row["file_names"],
                    row["rule_types"],
                    row["attribute_types"],
                )
            ]
            log_check_output(
                spark=self.databricks_helpers.spark,
                dbutils=self.databricks_helpers.dbutils_obj,
                rule_id=row["id"],
                rule_json_dict=ast.literal_eval(row["check_json"]),
                error=error_messages,
                logs_directory=self.logs_directory,
                dq_lib_logs_directory=self.dq_lib_logs_directory,
            )

        checks_without_filename_df = self.cache_outputs["checks_without_filename_df"]
        filters_dataframe = self.cache_outputs["filters_dataframe"]
        for row in checks_without_filename_df.collect():
            filter_row = filters_dataframe.filter(
                filters_dataframe["dq_check_id"] == row.id
            ).collect()
            rule_json = self.return_check_json(
                row, filter_row, functional_name_technical_name_map
            )
            log_check_output(
                spark=self.databricks_helpers.spark,
                dbutils=self.databricks_helpers.dbutils_obj,
                rule_id=row.id,
                rule_json_dict=rule_json,
                error=FileNameNotFoundException(),
                logs_directory=self.logs_directory,
                dq_lib_logs_directory=self.dq_lib_logs_directory,
            )
        checks_without_snapshot = self.cache_outputs["checks_without_snapshot"]
        for check in checks_without_snapshot.collect():
            log_check_output(
                spark=self.databricks_helpers.spark,
                dbutils=self.databricks_helpers.dbutils_obj,
                rule_id=check["id"],
                rule_json_dict=ast.literal_eval(check["check_json"]),
                error=FileNotFoundException(check["file_name"], check["file_type"]),
                logs_directory=self.logs_directory,
                dq_lib_logs_directory=self.dq_lib_logs_directory,
            )
        checks_with_no_filenames_dir = os.path.join(
            self.dqrem_path,
            self.invalid_checks_folder
            + f"/invalid_checks_with_no_filename_{datetime_str}",
        )
        if self.cache_outputs["checks_without_filename_df"].count() != 0:
            self.log_invalid_checks(
                self.cache_outputs["checks_without_filename_df"],
                path=checks_with_no_filenames_dir,
            )
        if len(self.cache_outputs["not_found_files"]) != 0:
            self.not_found_files_errors(self.cache_outputs["not_found_files"])

        self.save_parquet(
            self.cache_outputs["new_checks_df"], "overwrite", self.new_checks_dir
        )

        self.save_parquet(
            self.cache_outputs["all_checks_df"], "overwrite", self.checks_dir
        )


def get_parameters_combined(technical_name, reference=False):
    if reference:
        parameters = REFERENCE_DATA_ATTRIBUTE_PARAMETER_DICT.get(technical_name, [])
    else:
        parameters = DATA_ATTRIBUTE_PARAMETER_DICT.get(technical_name, [])
    return parameters


def parse_and_flatten(value):
    """Parse and flatten lists of data attributes."""
    if (
        len(value) > 0 and value[0] is not None
    ):  # Filter out empty lists and lists with none value
        try:  # Parse lists saved as string
            parsed_list = json.loads(value[0])
            return parsed_list
        except json.JSONDecodeError:  # Ignore correctly parsed values
            return value
    return value
