from .rule import Rule


class expect_column_values_to_be_a_hit(Rule):
    @classmethod
    def uuid(cls):
        return "612e1fa5-408d-4c70-a1b7-0fb349636227"

    @classmethod
    def functional_name(cls):
        return "must not pass given filter(s) (automatable)"

    @classmethod
    def technical_name(cls):
        return "expect_column_values_to_be_a_hit"

    @classmethod
    def description(cls):
        return "All data attributes will result in a hit (automatable)"

    @classmethod
    def subdimension(cls):
        return "Values Acceptance"

    @classmethod
    def aliases(cls):
        return super().aliases()

    @classmethod
    def scope(cls):
        return "both"

    @classmethod
    def parameter_definitions(cls):
        return []

    def parse_parameters(self, parameters):
        return super().parse_parameters(parameters)

    def passing(self, data_frame):
        return data_frame.limit(0)

    def failing(self, data_frame):
        return data_frame
