"""
This module contains all the rules that compare a date column with
a particular value, such as another date or a time difference with another date.
"""

from typing import List, Callable, Literal
from abc import ABC
from datetime import datetime, date

from pyspark.sql import DataFrame
import pyspark.sql.functions as F


from dq_engine.rules.rule import ParameterDefinition, Rule
from dq_engine.rules.helpers import (
    Operator,
    get_datatype_from_colname,
    generate_constraint_column_name,
)
from dq_engine.rules.custom_exceptions import ParameterNotFoundException

DATE_TYPES = ["date", "timestamp"]
NUMERICAL_TYPES = ["int", "bigint", "double", "float"]
STR_TYPES = ["string"]
VALID_TYPES = DATE_TYPES + NUMERICAL_TYPES + STR_TYPES


class DateColumnComparedToValue(Rule, ABC):
    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="date_format",
                functional_name="Date format for main attribute",
                description=(
                    "The date format of the attribute this check is defined on as defined by "
                    "Spark. See https://spark.apache.org/docs/latest/sql-ref-datetime-pattern.html. "
                    "Required when the column is not a date or timestamp type. "
                    "When the column is a numerical type (integer, float, decimal etc.), only date formats 'ddMMyyyy' and 'yyyyMMdd' are supported."
                    "Note that 'MM' stands for month and 'mm' stands for minutes."
                ),
                value_type="string",
                logical_type="value",
                required=False,
            ),
        ]

    def parse_parameters(self, parameters) -> None:
        super().parse_parameters(parameters)
        self.date_format = parameters.get("date_format")

    def validate_parameters(self, data_frame: DataFrame) -> None:
        col_type = get_datatype_from_colname(data_frame, self.column_name)
        if col_type not in VALID_TYPES and "decimal" not in col_type:
            raise ValueError(
                f"Column '{self.column_name}' of type '{col_type}' is not a date."
            )
        elif col_type not in DATE_TYPES and not self.date_format:
            raise ParameterNotFoundException(
                "Required parameter 'date_format' not found. This parameter is required when the date is not a date value."
            )

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        # Parse str, integer, long, decimal, double and timestamp columns to date.
        col_type = get_datatype_from_colname(data_frame, self.column_name)
        if col_type in ["string", "timestamp"]:
            data_frame = data_frame.withColumn(
                "parsed_date", F.to_date(data_frame[self.column_name], self.date_format)
            )
            self.column_name = "parsed_date"
        elif col_type in NUMERICAL_TYPES or "decimal" in col_type:
            data_frame = data_frame.withColumn(
                "parsed_date",
                F.to_date(
                    F.lpad(
                        data_frame[self.column_name].cast("int").cast("string"), 8, "0"
                    ),
                    self.date_format,
                ),
            )
            self.column_name = "parsed_date"
        return data_frame


class DateColumnComparedToDateRule(DateColumnComparedToValue):
    """
    Compares a date column against a given date.
    Supports different comparison types, such as: equal, distinct, equal or less,
    less, equal or greater and greater.
    """

    operator: Callable
    comparison_date: date
    date_format: str
    column_name: str

    @classmethod
    def uuid(cls) -> str:
        return "31b90fb8-7f93-47e0-bac0-c12273d2aad5"

    @classmethod
    def functional_name(cls) -> str:
        return "Data attribute must be compared to given date (automatable)"

    @classmethod
    def aliases(cls):
        """possible aliases in case of changing name for renaming"""
        return []

    @classmethod
    def description(cls) -> str:
        return """
            Compares a date column against a given date.
            \n\n The data attribute must contain a date and that date will be
            compared against the given date in the 'Comparison date' parameter.
            \n The comparison type must be provided in the 'Comparison type' parameter.
            \n\n The rule fails if:
            \n - The attribute does not adhere to the rule.
            \n - The attribute is not filled.
            \n - The attribute contains a value not according to defined 'Date format' parameter.
        """

    @classmethod
    def subdimension(cls):
        return "Logic Consistency"

    @classmethod
    def parameter_definitions(cls) -> List[ParameterDefinition]:
        return super().parameter_definitions() + [
            ParameterDefinition(
                technical_name="comparison_type",
                functional_name="Comparison",
                description="The type of comparison.",
                value_type="string",
                logical_type="value",
                required=True,
                enum_values=Operator.as_list(),
            ),
            ParameterDefinition(
                technical_name="comparison_date",
                functional_name="Comparison date",
                description="The given date to compare against. Must be in format 'dd-MM-yyyy'.",
                value_type="string",
                logical_type="value",
                required=True,
            ),
        ]

    def parse_parameters(self, parameters) -> None:
        super().parse_parameters(parameters)
        self.operator = Operator.get_operator_from_str(parameters["comparison_type"])
        # Parse string date in format "dd-MM-yyyy" to date object.
        self.comparison_date = datetime.strptime(
            parameters["comparison_date"], "%d-%m-%Y"
        ).date()

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop("parsed_date")

    def passing(self, data_frame: DataFrame) -> DataFrame:
        """
        Execute the check and return a dataframe which contains
        only passing records (records that adhere to the rule)
        """
        return data_frame.filter(
            self.operator(data_frame[self.column_name], self.comparison_date)
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        """
        Execute the check and return a dataframe which contains only
        failing records (records that do not adhere to the rule)
        """
        return data_frame.filter(
            (~self.operator(data_frame[self.column_name], self.comparison_date))
            | data_frame[self.column_name].isNull()
        )

    @classmethod
    def usage_examples(cls) -> str:
        return """
This rule compares the selected data attribute against a user defined date.

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Start Date', 'End Date' and 'Reopening Date'.
- 'ID' and 'Start Date' are of type `string`, End Date is of type `date` and 'Reopening Date' is of type `integer`.

The dataset looks like this:
| ID          | Start Date  | End Date   | Reopening Date |
| ----------- | ----------- | ---------- | -------------- |
| 1           | 12-10-2012  | 12-10-2012 | 20131012       |
| 2           | 01-01-2025  | 01-01-2025 | 20260101       |
| 3           | 01-01-2026  | 01-01-2026 | 20270101       |
| 4           | 20-02-2025  | 20-02-2099 | 20250320       |

Examples:

1. If I would want to ensure that all dates in the data element 'Start Date' are later than the 1st of January 2000 (to spot wrongly filled dates for example), the following parameter definition is needed:

    ```
    Date format: "dd-MM-yyyy"
    Comparison Type: "greater than or equal"
    Comparison date: "01-01-2000"
    ```

    The date format is needed as the data element is of type `string`. Note the capital MM for months.
    The comparison type needs to be greater than or equal. The snapshot date should be later than the given date.
    The comparison date needs to be set to 01-01-2000, as this the chosen date in a `dd-MM-yyyy` format.

    Given the dataset above, all rows would be valid.

2. If I would want to ensure that all dates in the data element 'End Date' are before or on the 31st of December 2030, the following parameter definition is needed:

    ```
    Comparison Type: "less than or equal"
    Comparison date: "12-12-2030"
    ```

    The date format is not needed as the data element is of type `date`.
    The comparison type needs to be less than or equal.
    The comparison date needs to be set to 12-12-2030, as this the chosen date in a `dd-MM-yyyy` format.

    Given the dataset above, rows 1, 2 and 3 would be valid, but row 4 would result in a hit.

3. If I would want to ensure that all dates in the data element 'Reopening Date' are later than the 1st of January 2000 (to spot wrongly filled dates for example), the following parameter definition is needed:

    ```
    Date format: "yyyyMMdd"
    Comparison Type: "greater than or equal"
    Comparison date: "01-01-2000"
    ```

    The date format is needed as the data element is of type `integer`. Note the capital MM for months and the fact that integer dates cannot contain dashes.
    The comparison type needs to be greater than or equal. The snapshot date should be later than the given date.
    The comparison date needs to be set to 01-01-2000, as this the chosen date in a `dd-MM-yyyy` format.

    Given the dataset above, all rows would be valid.
"""


class must_be_compared_against_days_difference_from_snapshot_date(
    DateColumnComparedToValue
):
    def __init__(self, **kwargs):
        self.snapshot_date = None
        self.number_of_days = None
        self.date_format = None
        self.operator = None
        super().__init__(**kwargs)
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )

    @classmethod
    def uuid(cls) -> str:
        return "cab23632-c284-4714-9255-e05fe2ddf3b3"

    @classmethod
    def functional_name(cls) -> str:
        return "Data attribute must be compared against days difference from snapshot date (automatable)"

    @classmethod
    def description(cls) -> str:
        return "Compares the days difference between the date attribute and the snapshot date value of the file. The days difference will be positive if the data element date is before the snapshot date. The days difference will be negative if the data element date is after the snapshot date. For documentation see: https://dev.azure.com/cbsp-abnamro/GRD0001077/_wiki/wikis/DQ%20Rule%20Engine%20Modernization/112852/Data-attribute-must-be-compared-against-days-difference-from-snapshot-date-(automatable)-documentation."

    @classmethod
    def aliases(cls) -> list:
        return []

    @classmethod
    def subdimension(cls) -> str:
        return "Logic Consistency"

    @classmethod
    def parameter_definitions(cls):
        return super().parameter_definitions() + [
            ParameterDefinition(
                technical_name="operator",
                functional_name="Comparison Type",
                description="Kind of operator between Number of Days parameter and the number of "
                "days difference between main date value and snapshot date.",
                value_type="string",
                logical_type="value",
                required=True,
                enum_values=Operator.as_list(),
            ),
            ParameterDefinition(
                technical_name="number_of_days",
                functional_name="Number of days value",
                description="The number of days value to be compared against the days difference "
                "value between main attribute and snapshot date.",
                value_type="number",
                logical_type="value",
                required=True,
            ),
        ]

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def parse_parameters(self, parameters):
        """Parse and validate parameters including number_of_days and snapshot_date."""
        super().parse_parameters(parameters)
        if "snapshot_date" not in parameters:
            raise ParameterNotFoundException("Parameter 'snapshot_date' not found.")

        # Process number_of_days
        number_of_days = parameters["number_of_days"]
        if isinstance(number_of_days, str):
            is_negative = number_of_days.startswith("-")
            stripped_number_of_days = (
                number_of_days[1:] if is_negative else number_of_days
            )

            if stripped_number_of_days.isnumeric():
                self.number_of_days = int(number_of_days)
            else:
                raise ValueError("Invalid value for parameter 'number_of_days'")
        elif isinstance(number_of_days, int):
            self.number_of_days = number_of_days
        else:
            raise ValueError("Invalid type for parameter 'number_of_days'")

        self.operator = Operator.get_operator_from_str(parameters["operator"])

        self.snapshot_date = parameters["snapshot_date"]

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        data_frame = super().pre_process(data_frame)

        data_frame = data_frame.withColumn("_snapshot_date", F.lit(self.snapshot_date))
        date_diff = F.datediff(
            data_frame["_snapshot_date"], data_frame[self.column_name]
        ).cast("int")
        data_frame = data_frame.withColumn(
            self.constraint_column_name, F.lit(date_diff)
        )
        return data_frame

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(
            self.constraint_column_name, "_snapshot_date", "parsed_date"
        )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            self.operator(data_frame[self.constraint_column_name], self.number_of_days)
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            (
                ~self.operator(
                    data_frame[self.constraint_column_name], self.number_of_days
                )
            )
            | data_frame[self.constraint_column_name].isNull()
        )

    @classmethod
    def usage_examples(cls) -> str:
        return """
This rule compares the days difference between the date attribute and the snapshot date value of the file.
The formula that is used for this comparison is:
    difference = snapshot date - data element date

Where:

- When the data element date is in the past -> The difference is a positive number as snapshot date is bigger than the element date.
- When the data element date is in the future -> The difference is a negative number as snapshot date is less than the element date.

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Start Date', 'End Date' and 'Reopening Date'.
- 'ID' and 'Start Date' are of type `string`, 'End Date' is of type `date` and 'Reopening Date' is of type `integer`.
- Today's date is 18-02-2025

The dataset looks like this:
| ID          | Start Date  | End Date   | Reopening Date |
| ----------- | ----------- | ---------- | -------------- |
| 1           | 12-10-2012  | 12-10-2012 | 20131012       |
| 2           | 01-01-2025  | 01-01-2025 | 20260101       |
| 3           | 01-01-2026  | 01-01-2026 | 20270101       |
| 4           | 20-02-2025  | 20-02-2025 | 20250320       |

Examples:

1. If I would want to ensure that all dates in the data element 'Start Date' can not be in the future (i.e. are smaller than or equal to the snapshot date) the following parameter definition is needed:

    ```
    Date format for main attribute: dd-MM-yyyy
    Comparison Type: greater than or equal
    Number of days value: 0
    ```

    The date format is needed as the data element is of type `string`. Note the capital MM for months.
    The comparison type needs to be greater than or equal. The snapshot date should be later than the data element date (thus a bigger value). When we subtract the two as mentioned above, we want the result to be positive.
    The number of days needs to be set to 0, as this is the limit of our acceptance criteria (if the difference is 0, the element date is equal to the snapshot date and valid. Any smaller differences (negative) are not valid, but bigger differences are).

    Given the dataset above, rows 1 and 2 would be valid, but row 3 and 4 would result in a hit.

2. If I would want to ensure that all dates in the data element 'End Date' can not be more than 2 weeks in the future, the following parameter definition is needed:

    ```
    Comparison Type: greater than or equal
    Number of days value: -14
    ```

    The date format is not needed as the data element is of type `date`. Note that also when the data element is of type `timestamp` the date format is not needed.
    The comparison type needs to be greater than or equal. Similar to the above example, the snapshot date should be later than the data element date (thus a bigger value), however there is an offset of 2 weeks (2 weeks into the future is okay). This offset shows itself in the next parameter.
    The number of days needs to be set to -14. We choose the number 14 as 2 weeks equals 14 days, and it is negative as we allow the data element date to be up to 14 days bigger than the snapshot date. If the difference is more than 14 days, the difference will become -15 and we will not treat this as a valid record.

    Given the dataset above, rows 1 and 2 **and 4** would be valid, but row 3 would result in a hit.

3. If I would want to ensure that all dates in the data element 'End Date' can not be more then 2 years in the past, the following parameter definition is needed:

    ```
    Comparison Type: less than
    Number of days value: 731
    ```

    The date format is not needed as the data element is of type `date`. Note that also when the data element is of type `timestamp` the date format is not needed.
    The comparison type needs to be less than. The snapshot date should be later than the data element date (thus a bigger value) and when there is 2 years difference that equates to 730 days (when taking 365 days a year). We want the difference to always be smaller, so we pick less than.
    The number of days needs to be set to 731. We choose the number 731 as it is one day more than 2 years (see above) and we have used the comparison type of `less than`. If the difference is equal to / more than 731 days, we will not treat this as a valid record.

    Note that parameter values `less than` and `731` functionally work the same as parameter values `less than or equal` and `730`.

    Given the dataset above, row 2, 3 and 4 would be valid, but row 1 would result in a hit.

4. If I would want to ensure that all dates in the data element 'Reopening Date' can not be in the future (i.e. are smaller than or equal to the snapshot date) the following parameter definition is needed:

    ```
    Date format for main attribute: yyyyMMdd
    Comparison Type: greater than or equal
    Number of days value: 0
    ```

    The date format is needed as the data element is of type `integer`. Note the capital MM for months and the fact that integer dates cannot contain dashes.
    The comparison type needs to be greater than or equal. The snapshot date should be later than the data element date (thus a bigger value). When we subtract the two as mentioned above, we want the result to be positive.
    The number of days needs to be set to 0, as this is the limit of our acceptance criteria (if the difference is 0, the element date is equal to the snapshot date and valid. Any smaller differences (negative) are not valid, but bigger differences are).

    Given the dataset above, only row 1 would be valid, and rows 2, 3 and 4 would result in a hit.
"""
