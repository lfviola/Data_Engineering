from typing import Literal

from pyspark.sql import DataFrame
from pyspark.sql.functions import expr

from dq_engine.rules.custom_exceptions import (
    InvalidColumnDatatypeException,
    ParameterNotFoundException,
)
from dq_engine.rules.helpers import (
    generate_constraint_column_name,
    get_datatype_from_colname,
)
from dq_engine.rules.rule import ParameterDefinition
from dq_engine.rules.rule_reference import ReferenceDataRule


class expect_column_values_to_match_referenced_regex(ReferenceDataRule):
    def __init__(self, **kwargs):
        self.reference_attribute_id = None
        self.reference_data_attribute = None
        self.reference_data_attribute_id = None
        self.lookup_attribute_id = None
        self.lookup_attribute = None
        self.reference_regex_attribute_id = None
        self.reference_regex_attribute = None
        self.constraint_column_name = None

        super().__init__(**kwargs)
        self.constraint_colname = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )

    @classmethod
    def uuid(cls):
        return "8E2D428E-27BD-47CF-9C91-3A60FFC21447"

    @classmethod
    def functional_name(cls):
        return "must be valid for regular expression in reference data (automatable)"

    @classmethod
    def description(cls):
        return (
            "Data attribute must contain a value that can be found in the reference data attribute with regex input. The reference "
            "data attribute  is expected to be in a different flat-file. This would usually concern reference "
            "data with regex input."
        )

    @classmethod
    def subdimension(cls):
        return "Logic Consistency"

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    def parameter_definitions(cls):
        # reference_data_attribute_id -> Join column in reference data
        # lookup_attribute_id -> Join colomn in flat file
        # reference_regex_attribute_id -> column name in reference data containing regex
        return [
            ParameterDefinition(
                technical_name="reference_data_attribute_id",
                functional_name="Referenced identifier attribute",
                description="The identifier attribute in the reference table with regular expressions.",
                value_type="data-attribute",
                logical_type="value",
                required=True,
                is_reference_data_attribute=True,
            ),
            ParameterDefinition(
                technical_name="lookup_attribute_id",
                functional_name="Lookup value attribute",
                description="Attribute containing the identifier value to look up in the reference table with regular expressions.",
                value_type="data-attribute",
                logical_type="value",
                required=True,
                is_reference_data_attribute=False,
            ),
            ParameterDefinition(
                technical_name="reference_regex_attribute_id",
                functional_name="Referenced regular expression attribute",
                description="The attribute in the reference table that contains the actual regular expression value itself.",
                value_type="data-attribute",
                logical_type="value",
                required=True,
                is_reference_data_attribute=True,
            ),
        ]

    @classmethod
    def aliases(cls):
        return super().aliases()

    def parse_parameters(self, parameters):
        super().parse_parameters(parameters)
        if "reference_data_attribute_id" not in parameters:
            raise ParameterNotFoundException(
                "Parameter 'reference_data_attribute_id' not found."
            )
        if "lookup_attribute_id" not in parameters:
            raise ParameterNotFoundException(
                "Parameter 'lookup_attribute_id' not found."
            )
        if "reference_regex_attribute_id" not in parameters:
            raise ParameterNotFoundException(
                "Parameter 'reference_regex_attribute_id' not found."
            )
        self.reference_data_attribute = parameters["reference_data_attribute_id"]
        self.reference_column_name = (
            self.reference_data_attribute.column_name + self.reference_suffix
        )
        self.reference_attribute_id = self.reference_data_attribute.data_attribute_uuid

        self.lookup_attribute = parameters["lookup_attribute_id"]
        self.lookup_attribute_id = self.lookup_attribute.data_attribute_uuid
        self.lookup_attribute_column_name = self.lookup_attribute.column_name

        self.reference_regex_attribute = parameters["reference_regex_attribute_id"]
        self.reference_regex_attribute_column_name = (
            self.reference_regex_attribute.column_name + self.reference_suffix
        )
        self.reference_regex_attribute_id = (
            self.reference_regex_attribute.data_attribute_uuid
        )

    def validate_parameters(self, data_frame: DataFrame) -> None:
        """
        Validations:
        1. if lookup attribute  datatype and reference column datatype are not same  raise error.
        2. if main data attribute datatype and reference regex attribute are not same raise error
        3. if all columns are of same type do nothing.
        """
        main_col_datatype = get_datatype_from_colname(data_frame, self.column_name)
        ref_col_datatype = get_datatype_from_colname(
            self.ref_df, self.reference_column_name
        )
        lookup_col_datatype = get_datatype_from_colname(
            data_frame, self.lookup_attribute_column_name
        )
        reference_regex_attribute_column_name_datatype = get_datatype_from_colname(
            self.ref_df, self.reference_regex_attribute_column_name
        )
        if lookup_col_datatype == ref_col_datatype:
            return
        if lookup_col_datatype != ref_col_datatype:
            raise InvalidColumnDatatypeException(
                f"lookup column datatype {lookup_col_datatype} and ref column datatype{ref_col_datatype} are not same so lookup is possible."
            )
        if main_col_datatype not in [
            "string",
            "char",
            "varchar",
        ]:
            raise InvalidColumnDatatypeException(
                f"Main Column datatype {main_col_datatype} not supported."
            )
        if reference_regex_attribute_column_name_datatype not in [
            "string",
            "char",
            "varchar",
        ]:
            raise InvalidColumnDatatypeException(
                f"Reference regex Column datatype {ref_col_datatype} not supported."
            )

    def pre_process(self, data_frame: DataFrame):
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )

        renamed_ref_df = self.ref_df.select(
            self.reference_column_name, self.reference_regex_attribute_column_name
        )
        data_frame = data_frame.join(
            renamed_ref_df,
            data_frame[self.lookup_attribute_column_name]
            == renamed_ref_df[self.reference_column_name],
            how="left",
        )
        data_frame = data_frame.withColumn(
            self.constraint_column_name,
            expr(
                f"{self.column_name} rlike {self.reference_regex_attribute_column_name}"
            ),
        )

        return data_frame

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == True)  # noqa: E712

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] != True)  # noqa: E712

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_column_name)
