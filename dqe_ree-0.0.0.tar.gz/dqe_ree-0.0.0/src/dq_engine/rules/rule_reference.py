from enum import Enum
from typing import Literal

import pyspark.sql.functions as F
from pyspark.sql import DataFrame, Window

from .custom_exceptions import (
    InvalidColumnDatatypeException,
    ParameterNotFoundException,
)
from .helpers import (
    Operator,
    generate_constraint_column_name,
    get_datatype_from_colname,
)
from .rule import ParameterDefinition, Rule
from .helpers import BooleanParameter
from dq_engine.rules.parameters import trim_whitespace


class ReferenceDataRule(Rule):
    """Base class for rules that require reference data.

    These rules require a supporting reference dataframe,
    used in calculations or comparisons with the main dataframe."""

    def __init__(self, **kwargs):
        self.reference_attribute_id = None
        self.reference_suffix = "_REFERENCE"

        super().__init__(**kwargs)

    def supporting_data(self):
        """Returns a dict with supporting date this rule needs."""
        return {"ref_df": self.reference_attribute_id}

    def set_supporting_data(self, supporting_data):
        """Sets supporting data for this rule.

        In addition, adds a suffix to all column names in order
        to distinguish them from main dataframe columns.
        """
        ref_df: DataFrame = supporting_data["ref_df"]

        # renaming columns to avoid conflicting names
        for col_name in ref_df.columns:
            ref_df = ref_df.withColumnRenamed(
                col_name, col_name + self.reference_suffix
            )

        self.ref_df: DataFrame = ref_df


class ComparisonType(Enum):
    STRING = "string"
    NUMERIC = "numeric"

    @classmethod
    def values_as_list(cls) -> list:
        return [member.value for member in cls]


class ReferenceRule(ReferenceDataRule):
    def __init__(self, **kwargs):
        self.reference_attribute_id = None
        self.reference_data_attribute = None
        self.comparison_type = None

        super().__init__(**kwargs)

        self.constraint_colname = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )

    @classmethod
    def child_parameter_definitions(cls):
        raise NotImplementedError

    @classmethod
    def subdimension(cls):
        return "Logic Consistency"

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def parse_child_parameters(self, parameters):
        raise NotImplementedError

    @classmethod
    def parameter_definitions(cls):
        shared_parameters = [
            ParameterDefinition(
                technical_name="reference_data_attribute_id",
                functional_name="Reference attribute id",
                description="The reference data attribute in which to look up the value.",
                value_type="data-attribute",
                logical_type="value",
                required=True,
                is_reference_data_attribute=True,
            ),
            ParameterDefinition(
                technical_name="comparison_type",
                functional_name="comparisonType",
                description="It is a optional field to provide value with 'string' and 'numeric' as the options.Both the comparision column will be converted to same data type according to input value",
                value_type="string",
                logical_type="value",
                required=False,
                enum_values=ComparisonType.values_as_list(),
            ),
            trim_whitespace,
        ]
        return shared_parameters + cls.child_parameter_definitions()

    @classmethod
    def aliases(cls):
        return super().aliases()

    def parse_parameters(self, parameters):
        super().parse_parameters(parameters)

        if "reference_data_attribute_id" not in parameters:
            raise ParameterNotFoundException(
                "Parameter 'reference_data_attribute_id' not found."
            )
        self.reference_data_attribute = parameters["reference_data_attribute_id"]
        self.reference_column_name = (
            self.reference_data_attribute.column_name + self.reference_suffix
        )
        self.reference_attribute_id = self.reference_data_attribute.data_attribute_uuid

        self.trim_whitespace = parameters.get("trim_whitespace", False)
        if self.trim_whitespace not in BooleanParameter.values_as_list():
            raise ValueError(
                "Invalid value for 'trim_whitespace' parameter. Only boolean values allowed."
            )

        self.comparison_type = None
        if "comparison_type" in parameters:
            self.comparison_type = parameters["comparison_type"].lower()

        self.parse_child_parameters(parameters)

    def validate_parameters(self, data_frame: DataFrame) -> None:
        """
        Validations:
        1. If comparison_type value is present then validate the given input. Only numeric and string value is allowed
        2. if main column datatype and reference column datatype are not in given types raise error.
        3. if both columns are of same type do nothing.
        """
        main_col_datatype = get_datatype_from_colname(data_frame, self.column_name)
        ref_col_datatype = get_datatype_from_colname(
            self.ref_df, self.reference_column_name
        )

        if main_col_datatype == ref_col_datatype:
            return

        if (
            self.comparison_type
            and self.comparison_type not in ComparisonType.values_as_list()
        ):
            raise InvalidColumnDatatypeException(
                f"comparison_type {self.comparison_type} is not supported. Allowed values: {ComparisonType.values_as_list()}"
            )

        if self.comparison_type:
            return

        allowed_types = [
            "int",
            "bigint",
            "tinyint",
            "smallint",
            "string",
            "char",
            "varchar",
        ]

        if (
            main_col_datatype not in allowed_types
            and "decimal" not in main_col_datatype
        ):
            raise InvalidColumnDatatypeException(
                f"Main Column datatype {main_col_datatype} not supported."
            )

        if ref_col_datatype not in allowed_types and "decimal" not in ref_col_datatype:
            raise InvalidColumnDatatypeException(
                f"Reference Column datatype {ref_col_datatype} not supported."
            )

    def pre_process(self, data_frame: DataFrame):
        """
        Conversions: main column -> reference column combinations
        If comparison_type is given the both the columns will be converted to as per given input.
        e.g : If comparison_type is numeric then both the columns will be converted to integer
              If comparison_type is string  then both the columns will be converted to string
        main col: tiny-/small-/big-/int:
            decimal: convert ref column to decimal.
            string/char/varchar: convert ref column to integer and compare
            tiny-/small-/big-/int: compare as usual
        main col: decimal
            decimal: compare as usual
            string/char/varchar: convert reference column to decimal
            tiny-/small-/big-/int: convert reference column to decimal and compare
        main col: string/char/varchar:
            decimal: convert ref column to decimal
            string/char/varchar: compare as usual
            tiny-/small-/big-/int: convert ref column to integer and compare

        join the reference df with duplicates removed to main df column.

        :param data_frame: main table dataframe
        :return data_frame: joined dataframe
        """
        main_col_datatype = get_datatype_from_colname(data_frame, self.column_name)

        ref_col_datatype = get_datatype_from_colname(
            self.ref_df, self.reference_column_name
        )

        if self.trim_whitespace:
            data_frame = data_frame.withColumn(
                self.column_name, F.trim(self.column_name)
            )
            self.ref_df = self.ref_df.withColumn(
                self.reference_column_name, F.trim(self.reference_column_name)
            )

        if self.comparison_type == "numeric":
            if (
                "decimal" in ref_col_datatype.lower()
                or "decimal" in main_col_datatype.lower()
            ):
                if "decimal" in main_col_datatype.lower():
                    if ref_col_datatype.lower() in ["string", "char", "varchar"]:
                        self.ref_df = self.ref_df.withColumn(
                            self.reference_column_name,
                            F.when(
                                self.ref_df[self.reference_column_name].rlike(
                                    "^[0-9]+$"
                                ),
                                self.ref_df[self.reference_column_name].cast(
                                    main_col_datatype
                                ),
                            ).otherwise(None),
                        )
                    else:
                        self.ref_df = self.ref_df.withColumn(
                            self.reference_column_name,
                            self.ref_df[self.reference_column_name].cast(
                                main_col_datatype
                            ),
                        )
                else:
                    if main_col_datatype.lower() in ["string", "char", "varchar"]:
                        data_frame = data_frame.withColumn(
                            self.column_name,
                            F.when(
                                data_frame[self.column_name].rlike("^[0-9]+$"),
                                data_frame[self.column_name].cast(ref_col_datatype),
                            ).otherwise(None),
                        )
                    else:
                        data_frame = data_frame.withColumn(
                            self.column_name,
                            data_frame[self.column_name].cast(ref_col_datatype),
                        )
            else:
                data_frame = data_frame.withColumn(
                    self.column_name, data_frame[self.column_name].cast("int")
                )
                self.ref_df = self.ref_df.withColumn(
                    self.reference_column_name,
                    self.ref_df[self.reference_column_name].cast("int"),
                )

        elif self.comparison_type == "string":
            data_frame = data_frame.withColumn(
                self.column_name, data_frame[self.column_name].cast("string")
            )
            self.ref_df = self.ref_df.withColumn(
                self.reference_column_name,
                self.ref_df[self.reference_column_name].cast("string"),
            )

        else:
            if main_col_datatype in ["int", "bigint", "tinyint", "smallint"]:
                if "decimal" in ref_col_datatype.lower():
                    data_frame = data_frame.withColumn(
                        self.column_name,
                        data_frame[self.column_name].cast(ref_col_datatype),
                    )
                if ref_col_datatype in ["string", "char", "varchar"]:
                    self.ref_df = self.ref_df.withColumn(
                        self.reference_column_name,
                        self.ref_df[self.reference_column_name].cast(main_col_datatype),
                    )
            elif main_col_datatype.lower() in [
                "string",
                "char",
                "varchar",
            ] or main_col_datatype.lower().startswith("decimal"):
                self.ref_df = self.ref_df.withColumn(
                    self.reference_column_name,
                    self.ref_df[self.reference_column_name].cast(main_col_datatype),
                )
            else:
                # do nothing
                pass

        renamed_ref_df = (
            self.ref_df.withColumn(
                self.constraint_colname, self.ref_df[self.reference_column_name]
            )
            .select(self.constraint_colname)
            .distinct()
        )
        data_frame = data_frame.join(
            renamed_ref_df,
            data_frame[self.column_name] == renamed_ref_df[self.constraint_colname],
            how="left",
        )

        return data_frame


class expect_column_value_to_exist_in_reference_column(ReferenceRule):
    @classmethod
    def uuid(cls):
        return "62e5e860-e189-48fc-aad1-a51ec5f7d6a3"

    @classmethod
    def functional_name(cls):
        return "must exist in reference attribute (automatable)"

    @classmethod
    def description(cls):
        return (
            "Data attribute must contain a value that exists in the reference data attribute. "
            "The reference data attribute is expected to be in a different flat-file. "
            "This would usually concern reference data."
        )

    @classmethod
    def child_parameter_definitions(cls):
        return []

    def parse_child_parameters(self, parameters):
        return None

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_colname].isNotNull())

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter((data_frame[self.constraint_colname].isNull()))

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_colname)


class expect_number_of_occurrences_in_reference_column(ReferenceRule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.count_col_name = f"{self.constraint_colname}_count"

    @classmethod
    def uuid(cls):
        return "11b7dd27-be88-439b-8344-3247de69df2f"

    @classmethod
    def functional_name(cls):
        return (
            "must be compared against occurrences in reference attribute (automatable)"
        )

    @classmethod
    def description(cls):
        return (
            "Data attribute must contain a value that can be observed a certain number of occurrences in the reference data attribute. "
            "The reference data attribute is expected to be in a different flat-file. "
            "This would usually concern reference data."
        )

    @classmethod
    def child_parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="operator",
                functional_name="Comparison Operator",
                description="Operator for asses number of occurrences observed in the Reference table",
                value_type="string",
                logical_type="value",
                required=True,
                enum_values=Operator.as_list(),
            ),
            ParameterDefinition(
                technical_name="occurrences",
                functional_name="occurrences",
                description="The number of expected occurrences in the Reference table",
                value_type="number",
                logical_type="value",
                required=True,
            ),
        ]

    def parse_child_parameters(self, parameters):
        if "operator" not in parameters:
            raise ParameterNotFoundException("Parameter 'operator' not found.")
        if "occurrences" not in parameters:
            raise ParameterNotFoundException("Parameter 'occurrences' not found.")

        if parameters["operator"] in Operator.as_list():
            self.operator = parameters["operator"].upper().replace(" ", "_")
        else:
            raise ValueError(
                f"Unknown operator type {parameters['operator']}, please select from {Operator.as_list()}"
            )

        self.occurrences = parameters.get("occurrences")
        if self.occurrences is not None:
            try:
                self.occurrences = int(self.occurrences)
            except ValueError:
                raise ValueError("Parameter occurrence is not an integer.")

    def count_occurrences(self, ref_df: DataFrame, data_frame: DataFrame) -> DataFrame:
        w = Window.partitionBy(self.constraint_colname)
        renamed_ref_df = (
            ref_df.withColumn(
                self.constraint_colname, ref_df[self.reference_column_name]
            )
            .select(
                self.constraint_colname,
                F.count(self.constraint_colname).over(w).alias(self.count_col_name),
            )
            .distinct()
        )

        data_frame = data_frame.join(
            renamed_ref_df,
            data_frame[self.column_name] == renamed_ref_df[self.constraint_colname],
            how="left",
        ).fillna({self.count_col_name: 0})

        return data_frame

    def passing(self, data_frame: DataFrame) -> DataFrame:
        df_with_occurrences = self.count_occurrences(self.ref_df, data_frame)
        return df_with_occurrences.filter(
            Operator[self.operator].value(F.col(self.count_col_name), self.occurrences)
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        df_with_occurrences = self.count_occurrences(self.ref_df, data_frame)
        return df_with_occurrences.filter(
            ~Operator[self.operator].value(F.col(self.count_col_name), self.occurrences)
        )

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_colname, self.count_col_name)
