from pyspark.sql import functions as F
from pyspark.sql import Column

from .custom_exceptions import ParameterNotFoundException
from .helpers import BooleanParameter
from .rule import DataFrame, ParameterDefinition, Rule
from dq_engine.rules.parameters import trim_whitespace, ignore_case


class ColumnEqualityRule(Rule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.accent_characters = "áãâàéêèíîìóöõôòúûùç"
        self.replacement_characters = "aaaaeeeiiiooooouuuc"

    @classmethod
    def subdimension(cls):
        return "Logic Consistency"

    @classmethod
    def parameter_definitions(cls):
        shared_parameters = [
            ParameterDefinition(
                technical_name="column_to_compare",
                functional_name="Column to compare",
                description="The column to check equality against.",
                value_type="data-attribute",
                logical_type="value",
                required=True,
                is_reference_data_attribute=False,
            ),
            ParameterDefinition(
                technical_name="ignore_accents",
                functional_name="Ignore Accents",
                description="Enable accent insensitive comparison between both provided columns.",
                value_type="boolean",
                logical_type="value",
                required=False,
                is_reference_data_attribute=False,
                enum_values=BooleanParameter.values_as_list(),
            ),
            trim_whitespace,
            ignore_case,
        ]

        return shared_parameters

    @classmethod
    def scope(cls):
        return "both"

    def parse_parameters(self, parameters):
        super().parse_parameters(parameters)
        if not parameters.get("column_to_compare"):
            raise ParameterNotFoundException(
                "comparison column not found in parameters"
            )
        self.column_to_compare = parameters["column_to_compare"].column_name
        self.ignore_case = parameters.get("ignore_case", False)
        if self.ignore_case not in BooleanParameter.values_as_list():
            raise ValueError(
                "Invalid value for 'ignore_case' parameter. Only boolean values allowed."
            )
        self.trim_whitespace = parameters.get("trim_whitespace", False)
        if self.trim_whitespace not in BooleanParameter.values_as_list():
            raise ValueError(
                "Invalid value for 'trim_whitespace' parameter. Only boolean values allowed."
            )
        self.ignore_accents = parameters.get("ignore_accents", False)
        if self.ignore_accents not in BooleanParameter.values_as_list():
            raise ValueError(
                "Invalid value for 'ignore_accents' parameter. Only boolean values allowed."
            )

    def validate_parameters(self, data_frame: DataFrame) -> None:
        if self.column_to_compare not in data_frame.columns:
            raise ValueError(f"{self.column_to_compare} not found in data")

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        if self.ignore_case:
            data_frame = data_frame.withColumn(
                self.column_name, F.lower(self.column_name)
            ).withColumn(self.column_to_compare, F.lower(self.column_to_compare))

        if self.trim_whitespace:
            data_frame = data_frame.withColumn(
                self.column_name, F.trim(self.column_name)
            ).withColumn(self.column_to_compare, F.trim(self.column_to_compare))

        if self.ignore_accents:
            data_frame = data_frame.withColumn(
                self.column_name,
                F.translate(
                    self.column_name,
                    self.accent_characters,
                    self.replacement_characters,
                ),
            ).withColumn(
                self.column_to_compare,
                F.translate(
                    self.column_to_compare,
                    self.accent_characters,
                    self.replacement_characters,
                ),
            )

        data_frame = data_frame.withColumn(
            self.column_name, self.convert_blank_to_null(self.column_name)
        )
        data_frame = data_frame.withColumn(
            self.column_to_compare, self.convert_blank_to_null(self.column_to_compare)
        )

        return data_frame.withColumn(
            "_is_equal",
            F.when(
                (data_frame[self.column_name] == data_frame[self.column_to_compare])
                | (
                    data_frame[self.column_name].isNull()
                    & data_frame[self.column_to_compare].isNull()
                ),
                "equal",
            ).otherwise("not equal"),
        )

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop("_is_equal")

    @staticmethod
    def convert_blank_to_null(column: Column) -> Column:
        """Convert blank (empty string) columns to null if present"""
        return F.when(F.col(column) == "", None).otherwise(F.col(column))


class expect_column_values_to_be_equal_to_other_column(ColumnEqualityRule):
    @classmethod
    def uuid(cls):
        return "fe658877-5171-4e49-81d0-48bba6b16014"

    @classmethod
    def aliases(cls):
        return [
            "ISEQUAL",
            "EQUALTOOTHERCOLUMN",
            "expect_column_values_to_be_equal_to_other_column",
        ]

    @classmethod
    def functional_name(cls):
        return "must be equal to other attribute (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must equal the value in given second attribute."

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame["_is_equal"] == "equal")

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame["_is_equal"] == "not equal")

    @classmethod
    def usage_examples(cls):
        return """
This rule ensures that column values are equal to another column.

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Other ID', 'Start Number', 'End Number', 'Birth City' and 'Current City'.
- 'ID', 'Other ID', 'Birth City' and 'Current City' are of type `string`, whereas 'Start Number' and 'End Number' are of type `integer`.

The dataset looks like this:
| ID          | Other ID      | Start Number | End Number   | Birth City   | Current City |
| ----------- | ------------- | ------------ | ------------ | ------------ | ------------ |
| 1           | 1             | 1            | 1            | Amsterdam    | amsterdam    |
| 2           | 2             | 2            | 2            | Utrecht      |    Utrecht   |
| 3           | 3             | 4            | 3            | London       | Liverpool    |
| 4           | 5             | 123          |              | Warsaw       | Warsaw       |

Examples:

1. If I would want to ensure that entries in the column 'ID' are the same as entries in the column 'Other ID', the rule parameters need to be defined as follows:

    ```
    column_to_compare: {data attribute identifier of the 'Other ID' column}
    ```

    When we define the DQ check on the 'ID' data element, the column to compare parameter needs to correspond to the data attribute id of the 'Other ID' column (or vice versa). TIP: Use the [Technical Metadata dashboard](https://app.powerbi.com/groups/2a0a081e-d91d-469b-a8ec-4be7eefea344/reports/c67c10fb-bb7c-4b57-a882-6dc85629fa62/ReportSectionb08931b43ab9f150a9e8?experience=power-bi) to find the correct data attributes identifiers.
    The ignore case parameter does not need to be filled in as our data does not contain different cases.
    The trim whitespace parameter does not need to be filled in as our data does not contain whitespaces.

    Given the dataset above, rows 1, 2 and 3 would be valid, but row 4 would result in a hit as the columns contain a different value.

2. If I would want to ensure that entries in the column 'Start Number' are the same as entries in the column 'End Number', the rule parameters need to be defined as follows:

    ```
    column_to_compare: {data attribute identifier of the 'End Number' column}
    ```

    When we define the DQ check on the 'Start Number' data element, the column to compare parameter needs to correspond to the data attribute id of the 'End Number' column (or vice versa). TIP: Use the [Technical Metadata dashboard](https://app.powerbi.com/groups/2a0a081e-d91d-469b-a8ec-4be7eefea344/reports/c67c10fb-bb7c-4b57-a882-6dc85629fa62/ReportSectionb08931b43ab9f150a9e8?experience=power-bi) to find the correct data attributes identifiers.
    The ignore case parameter does not need to be filled in as our data does not contain different cases.
    The trim whitespace parameter does not need to be filled in as our data does not contain whitespaces.

    Given the dataset above, rows 1 and 2 would be valid, but rows 3 and 4 would result in a hit. Row 3 generates a hit as the column values are not the same and row 4 generates a hit as one of the column values is Null.

3. If I would want to ensure that entries in the column 'Birth City' are the same as entries in the column 'Current City', the rule parameters need to be defined as follows:

    ```
    column_to_compare: data attribute identifier of the 'Current City' column
    ignore_case: True
    trim_whitespace: True
    ```

    When we define the DQ check on the 'Birth City' data element, the column to compare parameter needs to correspond to the data attribute id of the 'Current City' column (or vice versa). TIP: Use the [Technical Metadata dashboard](https://app.powerbi.com/groups/2a0a081e-d91d-469b-a8ec-4be7eefea344/reports/c67c10fb-bb7c-4b57-a882-6dc85629fa62/ReportSectionb08931b43ab9f150a9e8?experience=power-bi) to find the correct data attributes identifiers.
    The ignore case parameter needs to be set to true as our data does contain different cases. Note that, when this parameters is not filled or set to False, 'Amsterdam' and 'amsterdam' will not be seen as the same.
    The trim whitespace parameter needs to be set to true as our data does contain whitespaces. Note that, when this parameters is not filled or set to False, 'amsterdam' and '    amsterdam' will not be seen as the same.

    Given the dataset above, rows 1, 2 and 4 would be valid, but row 3 would result in a hit as the values in the columns are not the same.

4. If you want to compare 2 columns where one column has accent characters and other column has no accent parameters then the 'ignore_accents' parameter can be enabled to allow the comparison to ignore the accent characters. Accent characters include: 'á', 'ã', 'â', 'à', 'é', 'ê', 'è', 'í', 'î', 'ì', 'ó', 'ö', 'õ', 'ô', 'ò', 'ú', 'û', 'ù', 'ç'; therse characters are replaced with: 'a', 'a', 'a', 'a', 'e', 'e', 'e', 'i', 'i', 'i', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'c'.
"""


class expect_column_values_to_be_not_equal_to_other_column(ColumnEqualityRule):
    @classmethod
    def uuid(cls):
        return "5e1d0725-9040-4e7c-9116-8d50fcddaff3"

    @classmethod
    def aliases(cls):
        return [
            "NOTEQUALTOOTHERCOLUMN",
            "expect_column_values_to_be_different_from_other_column",
        ]

    @classmethod
    def functional_name(cls):
        return "must not be equal to other attribute (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must not equal the value in given second attribute."

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame["_is_equal"] == "not equal")

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame["_is_equal"] == "equal")

    @classmethod
    def usage_examples(cls):
        return """
This rule ensures that column values are **NOT** equal to another column.

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Other ID', 'Start Number', 'End Number', 'Birth City' and 'Current City'.
- 'ID', 'Other ID', 'Birth City' and 'Current City' are of type `string`, whereas 'Start Number' and 'End Number' are of type `integer`.

The dataset looks like this:
| ID          | Other ID      | Start Number | End Number   | Birth City   | Current City |
| ----------- | ------------- | ------------ | ------------ | ------------ | ------------ |
| 1           | 1             | 1            | 1            | Amsterdam    | amsterdam    |
| 2           | 2             | 2            | 2            | Utrecht      |    Utrecht   |
| 3           | 3             | 4            | 3            | London       | Liverpool    |
| 4           | 5             | 123          |              | Warsaw       | Warsaw       |

Examples:

1. If I would want to ensure that entries in the column 'ID' are not the same as entries in the column 'Other ID', the rule parameters need to be defined as follows:

    ```
    column_to_compare: {data attribute identifier of the 'Other ID' column}
    ```

    When we define the DQ check on the 'ID' data element, the column to compare parameter needs to correspond to the data attribute id of the 'Other ID' column (or vice versa). TIP: Use the [Technical Metadata dashboard](https://app.powerbi.com/groups/2a0a081e-d91d-469b-a8ec-4be7eefea344/reports/c67c10fb-bb7c-4b57-a882-6dc85629fa62/ReportSectionb08931b43ab9f150a9e8?experience=power-bi) to find the correct data attributes identifiers.
    The ignore case parameter does not need to be filled in as our data does not contain different cases.
    The trim whitespace parameter does not need to be filled in as our data does not contain whitespaces.

    Given the dataset above, row 4 would be valid, but rows 1, 2 and 3 would result in a hit as the columns contain the same value.

2. If I would want to ensure that entries in the column 'Start Number' are not the same as entries in the column 'End Number', the rule parameters need to be defined as follows:

    ```
    column_to_compare: {data attribute identifier of the 'End Number' column}
    ```

    When we define the DQ check on the 'Start Number' data element, the column to compare parameter needs to correspond to the data attribute id of the 'End Number' column (or vice versa). TIP: Use the [Technical Metadata dashboard](https://app.powerbi.com/groups/2a0a081e-d91d-469b-a8ec-4be7eefea344/reports/c67c10fb-bb7c-4b57-a882-6dc85629fa62/ReportSectionb08931b43ab9f150a9e8?experience=power-bi) to find the correct data attributes identifiers.
    The ignore case parameter does not need to be filled in as our data does not contain different cases.
    The trim whitespace parameter does not need to be filled in as our data does not contain whitespaces.

    Given the dataset above, rows 3 and 4 would be valid, but rows 1 and 2 would result in a hit as the columns contain the same value.

3. If I would want to ensure that entries in the column 'Birth City' are not the same as entries in the column 'Current City', the rule parameters need to be defined as follows:

    ```
    column_to_compare: data attribute identifier of the 'Current City' column
    ignore_case: True
    trim_whitespace: True
    ```

    When we define the DQ check on the 'Birth City' data element, the column to compare parameter needs to correspond to the data attribute id of the 'Current City' column (or vice versa). TIP: Use the [Technical Metadata dashboard](https://app.powerbi.com/groups/2a0a081e-d91d-469b-a8ec-4be7eefea344/reports/c67c10fb-bb7c-4b57-a882-6dc85629fa62/ReportSectionb08931b43ab9f150a9e8?experience=power-bi) to find the correct data attributes identifiers.
    The ignore case parameter needs to be set to true as our data does contain different cases. Note that, when this parameters is not filled or set to False, 'Amsterdam' and 'amsterdam' will not be seen as the same.
    The trim whitespace parameter needs to be set to true as our data does contain whitespaces. Note that, when this parameters is not filled or set to False, 'amsterdam' and '    amsterdam' will not be seen as the same.

    Given the dataset above, row 3 would be valid, but rows 1, 2 and 4 would result in a hit as the columns contain the same value.
4. If you want to compare 2 columns where one column has accent characters and other column has no accent parameters then the 'ignore_accents' parameter can be enabled to allow the comparison to ignore the accent characters. Accent characters include: 'á', 'ã', 'â', 'à', 'é', 'ê', 'è', 'í', 'î', 'ì', 'ó', 'ö', 'õ', 'ô', 'ò', 'ú', 'û', 'ù', 'ç'; therse characters are replaced with: 'a', 'a', 'a', 'a', 'e', 'e', 'e', 'i', 'i', 'i', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'c'.
"""
