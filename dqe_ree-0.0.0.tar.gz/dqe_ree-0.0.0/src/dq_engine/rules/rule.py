import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Literal, Optional

from pyspark.sql import DataFrame

from .custom_exceptions import (
    AttributeIDNotFoundException,
    ColumnNotFoundException,
    DataAttributeNotFoundException,
    ParameterNotFoundException,
)


@dataclass
class ParameterDefinition:
    technical_name: str
    functional_name: str
    description: str
    value_type: Literal["string", "number", "data-attribute", "boolean"]
    logical_type: Literal["value", "array"]
    required: bool
    is_reference_data_attribute: bool = field(default=False)
    enum_values: List = field(default_factory=list)
    default_value: Optional[str] = field(default=None)


@dataclass
class DataAttributeParameter:
    data_attribute_uuid: int
    column_name: str


class Rule(ABC):
    """Base abstract class for all the rules."""

    @classmethod
    @abstractmethod
    def uuid(cls) -> str: ...

    @classmethod
    def technical_name(cls) -> str:
        return cls.__name__

    @classmethod
    @abstractmethod
    def aliases(cls):
        """possible aliases in case of changing name for renaming"""
        return []

    @classmethod
    @abstractmethod
    def functional_name(cls) -> str: ...

    @classmethod
    @abstractmethod
    def description(cls) -> str: ...

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    @abstractmethod
    def subdimension(cls) -> str: ...

    @classmethod
    @abstractmethod
    def parameter_definitions(cls) -> List[ParameterDefinition]:
        return []

    def __init__(
        self,
        spark,
        data_attribute_uuid,
        parameters,
        att_colname_map,
        dq_dataset_data_attribute_uuid: Optional[str] = None,
        logger=None,
        metadata_dataframe: Optional[DataFrame] = None,
    ):
        """Rule class init method

        Args:
            spark : spark session object.
            data_attribute_uuid : data attribute id of the column on which rule is applied
            parameters : parameters for the rule
            att_colname_map : the attribute id and column name map
            logger (_type_, optional): logger object which can be used for logging the exceptions. Defaults to None.
            dq_dataset_data_attribute_uuid: additional data attribute when rule is applied on a DQ dataset (DQ recipe)
        """
        self.logger = self.get_logger(logger)
        self.spark = spark
        self.metadata_dataframe = metadata_dataframe
        self.att_colname_map = self.create_attuuid_colname_map(att_colname_map)
        self.column_name = self.get_column_name(
            data_attribute_uuid, dq_dataset_data_attribute_uuid
        )
        self.parse_parameters(parameters)

    def get_column_name(
        self,
        data_attribute_uuid: str,
        dq_dataset_data_attribute_uuid: Optional[str] = None,
    ) -> str:
        """Method to convert data_attribute_uuid to column name on the physical file."""
        try:
            return (
                self.att_colname_map[data_attribute_uuid]
                if not dq_dataset_data_attribute_uuid
                else self.att_colname_map[dq_dataset_data_attribute_uuid]
            )
        except KeyError:
            raise DataAttributeNotFoundException(data_attribute_uuid)

    def create_attuuid_colname_map(self, att_colname_map):
        """Method to create a mapper between data_attribute_uuid and column names.

        Uses metadata_dataframe if defined, otherwise uses the provided att_colname_map parameter.
        """
        if not self.metadata_dataframe:
            return {key: value.upper() for key, value in att_colname_map.items()}
        all_colnames = self.metadata_dataframe.select(
            self.metadata_dataframe["column_name"],
            self.metadata_dataframe["data_attribute_uuid"],
        ).filter(self.metadata_dataframe["data_attribute_uuid"].isNotNull())
        return {
            rec["data_attribute_uuid"]: rec["column_name"].upper()
            for rec in all_colnames.collect()
        }

    def get_logger(self, logger):
        if not logger:
            return
        if isinstance(logger, str) and logger == "default":
            return logging.getLogger(self.__class__.__name__)
        elif isinstance(logger, object):
            return logger

    def log_message(self, log_level, message):
        """logging helper method. If no logger found then just print the message.
        If a logger is found then use the log_level to log message based on type.

        Args:
            log_level (_type_): default log levels available.
            message (_type_): the logging message.
        """
        if not self.logger:
            print(message)
            return
        if log_level == "info":
            self.logger.info(message)
        elif log_level == "debug":
            self.logger.debug(message)
        elif log_level == "warning":
            self.logger.warn(message)
        elif log_level == "error":
            self.logger.error(message)
        elif log_level == "exception":
            self.logger.exception(message)
        elif log_level == "critical":
            self.logger.critical(message)
        else:
            print(f'Logging method "{log_level}" not implemented')

    @classmethod
    def rule_json(cls):
        return {
            "id": cls.uuid(),
            "name": cls.functional_name(),
            "description": cls.description(),
            "technical_name": cls.technical_name(),
            "subdimension": cls.subdimension(),
            "scope": cls.scope(),
            "parameters": [
                cls.get_parameter_definition_as_json(parameter)
                for parameter in cls.parameter_definitions()
            ],
        }

    @classmethod
    def get_parameter_definition_as_json(cls, parameter):
        parameter_dict = {
            "name": parameter.functional_name,
            "description": parameter.description,
            "technical_name": parameter.technical_name,
            "value_type": parameter.value_type,
            "logical_type": parameter.logical_type,
            "required": parameter.required,
        }
        if parameter.value_type == "data-attribute":
            parameter_dict["is_reference_data_attribute"] = (
                parameter.is_reference_data_attribute
            )
        if parameter.enum_values:
            parameter_dict["enum_values"] = parameter.enum_values
        return parameter_dict

    def set_colname(self, parameters):
        return self.att_colname_map[parameters["data_attribute_uuid"]]

    def validate(self, data_frame: DataFrame) -> None:
        """validate parameters and columns in dataframe"""
        self.validate_column_name(data_frame)
        self.validate_parameters(data_frame)

    def validate_column_name(self, data_frame: DataFrame) -> None:
        """validates if the reporting column for the rule exists in the input dataframe"""
        if self.column_name not in list(map(str.upper, data_frame.columns)):
            raise ColumnNotFoundException(self.column_name, data_frame.columns)

    def parse_parameters(self, parameters) -> None:
        """Receive JSON definition and convert JSON fields into parameters of the correct type. If values can't be parsed raise errors.
        Also raise errors in case parameters combinations are not valid; e.g. lower bound is higher than upper bound

        This function reads the parameter definitions and if it finds a parameter which is of type data-attribute id then converts it to
        column name based on the attribute column name map passed to the base rule class.
        If the attribute id is not found in the map then raises error

        Raises:
            AttributeIDNotFound: error raised when attribute id is not found in the mapping dictionary att_colname_map
        """

        parameter_definitions = self.parameter_definitions()
        for param in parameter_definitions:
            param_value = parameters.get(param.technical_name)

            if param_value is None or (
                isinstance(param_value, (str, list)) and not param_value
            ):
                if not param.required:
                    continue
                else:
                    raise ParameterNotFoundException(
                        f"Required parameter '{param.technical_name}' not found."
                    )
            if param.value_type != "data-attribute":
                continue
            try:
                param_value = (
                    DataAttributeParameter(
                        data_attribute_uuid=param_value,
                        column_name=self.att_colname_map[param_value],
                    )
                    if param.logical_type != "array"
                    else [
                        DataAttributeParameter(
                            data_attribute_uuid=val,
                            column_name=self.att_colname_map[val],
                        )
                        for val in param_value
                    ]
                )
            except KeyError as e:
                error_message = f"attribute {e.args[0]} could not be mapped to a column name on the dataset"
                self.log_message("error", error_message)
                raise AttributeIDNotFoundException(error_message)
            parameters[param.technical_name] = param_value

    def supporting_data(self) -> dict:
        """
        return details of the dataframe we want to load
        data_attribute_uuid: number
        snapshot: Literal["latest", "matching"]
        additional_attributes: List[str]

        {'ref_df': DataAttributeParameter}
        """
        ...

    def set_supporting_data(self, supporting_data):
        """
        this function sets the supporting dataframes as instance variables so they can be used by all functions
        """
        pass

    def validate_parameters(self, data_frame: DataFrame) -> None:
        """
        Validate that the parameters are correct and that the rule can be executed given the provided data_frame on which the rule needs to be performed.
        For example type mismatches when attempting to do numeric comparisons on date fields.
        In case this happens Error's should be raised. Presence of the main column name is already validated and should not be checked here.
        """
        pass

    def pre_process(self, data_frame) -> DataFrame:
        """Place for adding a temporary column that supports rule execution
        supporting_dataframes: map of dataframe name{'dataframe_name1: dataframe obj}
        """
        return data_frame

    @abstractmethod
    def passing(self, data_frame: DataFrame) -> DataFrame:
        """Execute the check and return a dataframe which contains only passing records (records that adhere to the
        rule)"""
        return data_frame

    @abstractmethod
    def failing(self, data_frame: DataFrame) -> DataFrame:
        """Execute the check and return a dataframe which contains only failing records (records that do not adhere
        to the rule)"""
        return data_frame

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        """Place to perform cleanup such as removing columns added in pre_process"""
        return data_frame

    @classmethod
    def usage_examples(cls) -> str:
        """Method containing usage examples for a DQ rule."""
        return "To be documented."
