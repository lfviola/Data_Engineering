from functools import reduce
from operator import and_, or_
from typing import Literal
from dq_engine.rules.custom_exceptions import (
    InvalidParameterException,
    ParameterNotFoundException,
)
from pyspark.sql import functions as F
from dq_engine.rules.rule import ParameterDefinition
from dq_engine.rules.parameters import trim_whitespace
from .helpers import BooleanParameter, get_datatype_from_colname, string_datatypes
from pyspark.sql import DataFrame
from dq_engine.rules.rule_reference import ReferenceDataRule
from abc import ABC


class ColumnValueCombinationAgainstLookupTable(ReferenceDataRule, ABC):
    """
    Checks data attribute combination from a source table against a reference table."
    """

    @classmethod
    def presence_operator(cls) -> Literal["exists", "does not exist"]:
        """
        Indicates whether the rule checks for existence or
        not existence of the data in lookup table.
        """
        raise NotImplementedError

    @classmethod
    def functional_name(cls):
        return f"must be combination that {cls.presence_operator()} in reference table(automatable)"

    @classmethod
    def description(cls):
        return f"Data attribute combination from the source table should {'exist' if cls.presence_operator() == 'exists' else 'not exist'} in reference table."

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="source_attributes",
                functional_name="List of source attributes",
                description=f"List of two or more Data attributes; the combination of which should {'exist' if cls.presence_operator() == 'exists' else 'not exist'} in the lookup table. Should be present in the same flat-file as the data attribute the DQ Checks is reporting on.",
                value_type="data-attribute",
                logical_type="array",
                required=True,
                is_reference_data_attribute=False,
            ),
            ParameterDefinition(
                technical_name="lookup_attributes",
                functional_name="List of lookup attributes",
                description="List of two or more attributes on the lookup table; corresponding in order with the same list of source attributes. Should all be present in the same flatfile.",
                value_type="data-attribute",
                logical_type="array",
                required=True,
                is_reference_data_attribute=True,
            ),
            ParameterDefinition(
                technical_name="reference_data_attribute_id",
                functional_name="Reference attribute id",
                description="The reference data attribute in which to look up the value.",
                value_type="data-attribute",
                logical_type="value",
                required=True,
                is_reference_data_attribute=True,
            ),
            trim_whitespace,
        ]

    @classmethod
    def subdimension(cls):
        return "Logic Consistency"

    @classmethod
    def scope(cls):
        return "both"

    @classmethod
    def aliases(cls):
        return super().aliases()

    def parse_parameters(self, parameters) -> None:
        if not parameters.get("reference_data_attribute_id"):
            raise ParameterNotFoundException(
                "Parameter 'reference_data_attribute_id' not found."
            )
        if not parameters.get("source_attributes"):
            raise ParameterNotFoundException("Parameter 'source_attributes' not found.")
        if not parameters.get("lookup_attributes"):
            raise ParameterNotFoundException("Parameter 'lookup_attributes' not found.")
        super().parse_parameters(parameters)
        self.reference_data_attribute = parameters["reference_data_attribute_id"]
        self.reference_column_name = self.reference_data_attribute.column_name
        self.reference_attribute_id = self.reference_data_attribute.data_attribute_uuid
        self.source_attribute_column_names = [
            att.column_name for att in parameters["source_attributes"]
        ]
        self.lookup_attributes_column_names = [
            att.column_name + self.reference_suffix
            for att in parameters["lookup_attributes"]
        ]

        if len(self.source_attribute_column_names) != len(
            self.lookup_attributes_column_names
        ):
            raise InvalidParameterException(
                message="'source_attributes' and 'lookup_attributes' parameters should be of same length."
            )
        if len(self.source_attribute_column_names) < 2:
            raise InvalidParameterException(
                message="'source_attributes' cannot be less than 2."
            )
        if len(self.lookup_attributes_column_names) < 2:
            raise InvalidParameterException(
                message="'lookup_attributes' cannot be less than 2."
            )

        self.trim_whitespace = parameters.get("trim_whitespace", False)
        if self.trim_whitespace not in BooleanParameter.values_as_list():
            raise ValueError(
                "Invalid value for 'trim_whitespace' parameter. Only boolean values allowed."
            )

    def validate_parameters(self, data_frame: DataFrame) -> None:
        # columns in both parameters should be from same file
        if set(self.source_attribute_column_names).difference(data_frame.columns):
            raise InvalidParameterException(
                message="'source_attributes' columns are not present in source file."
            )

        if set(self.lookup_attributes_column_names).difference(self.ref_df.columns):
            raise InvalidParameterException(
                message="'lookup_attributes' columns are not present in reference file."
            )

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        reference_table = self.ref_df.select(*self.lookup_attributes_column_names)

        if self.trim_whitespace:
            data_frame = self._trim_columns_whitespaces(
                data_frame, self.source_attribute_column_names
            )
            reference_table = self._trim_columns_whitespaces(
                reference_table, self.lookup_attributes_column_names
            )

        reference_table_unique_values = reference_table.distinct()

        # preparing join columns mapping from both dataframes
        column_mappings = {
            col_1: col_2
            for col_1, col_2 in dict(
                zip(
                    self.source_attribute_column_names,
                    self.lookup_attributes_column_names,
                )
            ).items()
        }
        # preparing join condition
        join_conditions = [
            data_frame[main_table_col] == reference_table_unique_values[ref_table_col]
            for main_table_col, ref_table_col in column_mappings.items()
        ]
        join_condition = reduce(and_, join_conditions)

        joined_df = data_frame.join(
            reference_table_unique_values, on=join_condition, how="left"
        )

        return joined_df

    @staticmethod
    def _trim_columns_whitespaces(data_frame: DataFrame, columns: list):
        """
        Trims leading and trailing whitespaces from the specified columns in the DataFrame.

        :param df: Input DataFrame
        :param columns: List of column names to trim
        :return: DataFrame with trimmed columns
        """
        trimmed_df = data_frame.select(
            *[
                (
                    F.trim(F.col(c)).alias(c)
                    if c in columns
                    and get_datatype_from_colname(data_frame, c) in string_datatypes
                    else F.col(c)
                )
                for c in data_frame.columns
            ]
        )

        return trimmed_df

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(*self.lookup_attributes_column_names)

    @classmethod
    def usage_examples(cls) -> str:
        return f"""
This rule checks that some given data attribute combination from the source table {cls.presence_operator()} in reference table.

Example

The dataset looks like this:

| dq_dataset_name | column_name     | reason_code | reason_description |
| --------------- | --------------- | ----------- | ------------------ |
| dq_dataset_df   | "id"            | A           | Reason A           |
| dq_dataset_df   | "user_id"       | B           | Reason B           |
| dq_dataset_df   | "given_name"    | C           | Reason C           |
| dq_dataset_df   | "last_name"     | D           | Reason D           |
| dq_dataset_df   | "sex"           | E           | Reason E           |
| dq_dataset_df   | "email"         | F           | Reason F           |
| dq_dataset_df   | "phone"         | A           | Reason A           |
| dq_dataset_df   | "date_of_birth" | B           | Reason B           |
| dq_dataset_df   | "job_title"     | C           | Reason C           |
| dq_dataset_df   | "gender"        | A           | Reason B           |
| dq_dataset_df   | "initials"      | B           | Reason C           |

The reference table:

| dq_dataset_name_ref  | reason_code | reason_description |
| -------------------- | ----------- | ------------------ |
| dq_dataset_df        | A           | Reason A           |
| dq_dataset_df        | B           | Reason B           |
| dq_dataset_df        | C           | Reason C           |
| dq_dataset_df        | D           | Reason D           |


Check configuration:
- data_attribute_uuid: id matching "reason_code" column
- parameters:
  - source_attributes: ids matching "reason_code"  and  "reason_description" columns.
  - lookup_attributes: ids matching "reason_code"  and  "reason_description" columns.

"""


class expect_column_value_combinations_to_exist_in_lookup_table(
    ColumnValueCombinationAgainstLookupTable
):
    @classmethod
    def uuid(cls):
        return "fa1ce8d2-61d3-4d3f-8711-d3f839b8b0e2"

    @classmethod
    def presence_operator(cls) -> Literal["exists", "does not exist"]:
        """
        Indicates whether the rule checks for existence or
        not existence of the data in lookup table.
        """
        return "exists"

    def failing(self, data_frame: DataFrame) -> DataFrame:
        filter_condition = reduce(
            or_,
            [data_frame[col].isNull() for col in self.lookup_attributes_column_names],
        )
        return data_frame.filter(filter_condition)

    def passing(self, data_frame: DataFrame) -> DataFrame:
        filter_condition = reduce(
            and_,
            [
                data_frame[col].isNotNull()
                for col in self.lookup_attributes_column_names
            ],
        )
        return data_frame.filter(filter_condition)

    @classmethod
    def usage_examples(cls):
        usage_example = super().usage_examples()
        return (
            usage_example
            + """Given the data above, rows with reason code "E" and "F" and last 2 rows would result in
        a hit because the combination of "reason_code"  and  "reason_description" does not exist in the reference table.
        """
        )


class ColumnValueCombinationNotInLookupTable(ColumnValueCombinationAgainstLookupTable):
    @classmethod
    def uuid(cls):
        return "65c4876e-2115-4ba3-8127-376a68427505"

    @classmethod
    def presence_operator(cls) -> Literal["exists", "does not exist"]:
        """
        Indicates whether the rule checks for existence or
        not existence of the data in lookup table.
        """
        return "does not exist"

    def failing(self, data_frame: DataFrame) -> DataFrame:
        """Fails when values of column are present in the lookup table."""
        filter_condition = reduce(
            and_,
            [
                data_frame[col].isNotNull()
                for col in self.lookup_attributes_column_names
            ],
        )
        return data_frame.filter(filter_condition)

    def passing(self, data_frame: DataFrame) -> DataFrame:
        """Passes when values of column are not present in the lookup table."""
        filter_condition = reduce(
            or_,
            [data_frame[col].isNull() for col in self.lookup_attributes_column_names],
        )
        return data_frame.filter(filter_condition)

    @classmethod
    def usage_examples(cls):
        usage_example = super().usage_examples()
        return (
            usage_example
            + """Given the data above, the first 4 rows and the row with column names "phone",
            "date_of_birth" and "job_title" would result in a hit because the combination of
        "reason_code"  and  "reason_description" exist in the reference table."""
        )
