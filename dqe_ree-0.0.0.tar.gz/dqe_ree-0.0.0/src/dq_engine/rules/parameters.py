from .rule import ParameterDefinition
from .helpers import BooleanParameter

trim_whitespace = ParameterDefinition(
    technical_name="trim_whitespace",
    functional_name="Trim Whitespace",
    description="Ignore leading and trailing whitespace (spaces and tabs) on both provided values and values on source.",
    value_type="boolean",
    logical_type="value",
    required=False,
    enum_values=BooleanParameter.values_as_list(),
)

ignore_case = ParameterDefinition(
    technical_name="ignore_case",
    functional_name="Ignore Case",
    description="Enable case insensitive comparison between both provided values and values in source data.",
    value_type="boolean",
    logical_type="value",
    required=False,
    enum_values=BooleanParameter.values_as_list(),
)
