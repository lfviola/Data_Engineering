from decimal import Decimal

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from .custom_exceptions import DatatypeException, ParameterNotFoundException
from .helpers import BooleanParameter, get_datatype_from_colname
from .rule import ParameterDefinition, Rule
from dq_engine.rules.parameters import trim_whitespace, ignore_case


class InListRule(Rule):
    def __init__(self, **kwargs):
        self.allowed_values: list = []
        super().__init__(**kwargs)

    @classmethod
    def subdimension(cls):
        return "Values Acceptance"

    @classmethod
    def child_parameter_definitions(cls):
        raise NotImplementedError

    @classmethod
    def parameter_definitions(cls):
        shared_parameters = [
            ParameterDefinition(
                technical_name="values",
                functional_name="Values",
                description='The list of values to check for. Decimal values should have "." as decimal separator.',
                value_type="string",
                logical_type="array",
                required=True,
            ),
            trim_whitespace,
            ignore_case,
        ]

        return shared_parameters + cls.child_parameter_definitions()

    def parse_child_parameters(self, parameters):
        raise NotImplementedError

    def parse_parameters(self, parameters):
        if (
            "allowed_values" not in parameters
            and "values" not in parameters
            and "exception_values" not in parameters
        ):
            raise ParameterNotFoundException("Parameter not found.")
        if parameters.get("allowed_values"):
            self.allowed_values = parameters["allowed_values"]
        elif parameters.get("values"):
            self.allowed_values = parameters["values"]
        else:
            self.allowed_values = parameters["exception_values"]

        if not isinstance(self.allowed_values, list):
            raise ValueError("Parameter should be an array type")

        self.trim_whitespace = parameters.get("trim_whitespace", False)
        if self.trim_whitespace not in BooleanParameter.values_as_list():
            raise ValueError(
                "Invalid value for 'trim_whitespace' parameter. Only boolean values allowed."
            )
        self.ignore_case = parameters.get("ignore_case", False)
        if self.ignore_case not in BooleanParameter.values_as_list():
            raise ValueError(
                "Invalid value for 'ignore_case' parameter. Only boolean values allowed."
            )
        self.parse_child_parameters(parameters)

    @staticmethod
    def convert_list_to_type(convert_to_type, input_list):
        try:
            return list(map(convert_to_type, input_list))
        except Exception:
            raise ValueError("Cannot convert all input values to column datatype.")

    def validate_parameters(self, data_frame: DataFrame) -> None:
        column_type = get_datatype_from_colname(data_frame, self.column_name)
        if column_type not in [
            "string",
            "int",
            "bigint",
            "tinyint",
            "smallint",
        ] and not column_type.startswith("decimal"):
            raise ValueError(
                f"Column {self.column_name} datatype is not string or numeric."
            )
        if column_type == "string":
            self.allowed_values = self.convert_list_to_type(str, self.allowed_values)
        elif column_type in ["int", "bigint"]:
            self.allowed_values = self.convert_list_to_type(int, self.allowed_values)
        elif column_type.startswith("decimal"):
            self.allowed_values = self.convert_list_to_type(
                Decimal, self.allowed_values
            )
        else:
            raise DatatypeException(
                "Cannot convert input values to datatype of column."
            )

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        column_type = get_datatype_from_colname(data_frame, self.column_name)
        string_datatypes = ["string", "char", "varchar"]
        if self.trim_whitespace and column_type in string_datatypes:
            self.allowed_values = list(map(str.strip, self.allowed_values))
            data_frame = data_frame.withColumn(
                self.column_name, F.trim(F.col(self.column_name))
            )
        if self.ignore_case and column_type in string_datatypes:
            data_frame = data_frame.withColumn(
                self.column_name, F.lower(self.column_name)
            )
            self.allowed_values = list(map(str.lower, self.allowed_values))
        return data_frame


class expect_column_values_to_be_in_list(InListRule):
    @classmethod
    def uuid(cls):
        return "4c526856-6785-415d-9155-4e6ebdee4acb"

    @classmethod
    def aliases(cls):
        return ["expect_column_values_to_be_in_set", "ISINLIST"]

    @classmethod
    def functional_name(cls):
        return "must be in list of values (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must contain one of the values in the provided list."

    @classmethod
    def child_parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="allow_null_values",
                functional_name="Allow null values",
                description="Allow empty (null) values to pass the check, resulting in no hit. Only used by the 'must be in list of values' rule.",
                value_type="boolean",
                logical_type="value",
                required=False,
                enum_values=BooleanParameter.values_as_list(),
            )
        ]

    def parse_child_parameters(self, parameters):
        self.allow_null_values = False
        if parameters.get("allow_null_values"):
            self.allow_null_values = parameters["allow_null_values"]
        if self.allow_null_values not in BooleanParameter.values_as_list():
            raise ValueError(
                "Invalid value for 'allow_null_values' parameter. Only boolean values allowed."
            )
        if parameters.get("disallow_null_values"):
            raise ValueError(
                "Parameter 'disallow_null_values' can not be set for this rule."
            )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        condition = data_frame[self.column_name].isin(*self.allowed_values)

        if self.allow_null_values:
            condition = condition | (data_frame[self.column_name].isNull())

        return data_frame.filter(condition)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        condition = ~data_frame[self.column_name].isin(*self.allowed_values)

        if not self.allow_null_values:
            condition = condition | (data_frame[self.column_name].isNull())

        return data_frame.filter(condition)


class expect_column_values_to_not_be_in_list(InListRule):
    @classmethod
    def uuid(cls):
        return "21be8f62-9e1d-4b5b-8a07-e6fc27327ec1"

    @classmethod
    def aliases(cls):
        return ["expect_column_values_not_to_be_in_set", "ISNOTINLIST"]

    @classmethod
    def functional_name(cls):
        return "must not be in list of values (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must not contain one of the values in the provided list."

    @classmethod
    def child_parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="disallow_null_values",
                functional_name="Disallow null values",
                description="Disallow empty (null) values to pass the check, resulting in a hit. Only used by the 'must not be in list of values' rule.",
                value_type="boolean",
                logical_type="value",
                required=False,
                enum_values=BooleanParameter.values_as_list(),
            )
        ]

    def parse_child_parameters(self, parameters):
        self.disallow_null_values = False
        if parameters.get("disallow_null_values"):
            self.disallow_null_values = parameters["disallow_null_values"]
        if self.disallow_null_values not in BooleanParameter.values_as_list():
            raise ValueError(
                "Invalid value for 'disallow_null_values' parameter. Only boolean values allowed."
            )
        if parameters.get("allow_null_values"):
            raise ValueError(
                "Parameter 'allow_null_values' can not be set for this rule."
            )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        condition = ~data_frame[self.column_name].isin(*self.allowed_values)

        if not self.disallow_null_values:
            condition = condition | (data_frame[self.column_name].isNull())

        return data_frame.filter(condition)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        condition = data_frame[self.column_name].isin(*self.allowed_values)

        if self.disallow_null_values:
            condition = condition | (data_frame[self.column_name].isNull())

        return data_frame.filter(condition)
