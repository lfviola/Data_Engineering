from typing import Literal

from pyspark.sql import functions as F
from pyspark.sql.types import BooleanType

from .custom_exceptions import InvalidParameterException, ParameterNotFoundException
from .helpers import generate_constraint_column_name, get_datatype_from_colname
from .rule import DataFrame, ParameterDefinition, Rule


class expect_column_values_to_be_valid_date_format(Rule):
    @classmethod
    def uuid(cls):
        return "230e8827-a13d-4dc0-898d-81c2d43b21b4"

    @classmethod
    def functional_name(cls):
        return "must be a valid date format (automatable)"

    @classmethod
    def description(cls):
        return (
            "Data attribute must be a valid date according to the provided date format."
        )

    @classmethod
    def aliases(cls):
        return super().aliases()

    @classmethod
    def subdimension(cls):
        return "Format Acceptance"

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="date_format",
                functional_name="Date format",
                description="The date format as defined by Spark. See https://spark.apache.org/docs/latest/sql-ref-datetime-pattern.html. Required when the date is a string value. Note that 'MM' stands for month and 'mm' stands for minutes.",
                value_type="string",
                logical_type="value",
                required=True,
            )
        ]

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def parse_parameters(self, parameters: dict) -> None:
        if "date_format" not in parameters:
            raise ParameterNotFoundException("Parameter 'date_format' not found.")
        self.date_format = parameters["date_format"]
        if not isinstance(self.date_format, str):
            raise ValueError('Parameter "date_format" is an empty string.')
        if self.date_format.strip() == "":
            raise InvalidParameterException("Value cannot be an empty string.")

    def validate_parameters(self, data_frame: DataFrame) -> None:
        col_datatype = get_datatype_from_colname(data_frame, self.column_name)
        if col_datatype in ["timestamp", "date"]:
            self.log_message(
                "warning", "Column datatype is date so all records will pass."
            )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        col_datatype = get_datatype_from_colname(data_frame, self.column_name)
        if col_datatype in ["timestamp", "date"]:
            return data_frame.filter(data_frame[self.column_name].isNotNull())
        return data_frame.filter(
            F.to_date(data_frame[self.column_name], self.date_format).isNotNull()
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        col_datatype = get_datatype_from_colname(data_frame, self.column_name)
        if col_datatype in ["timestamp", "date"]:
            return data_frame.filter(data_frame[self.column_name].isNull())
        return data_frame.filter(
            F.to_date(data_frame[self.column_name], self.date_format).isNull()
        )

    @classmethod
    def usage_examples(cls):
        return """
This rule ensures that column values are a date or are parseable to a date format.

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Start Date' and 'End Date'.
- 'ID' and 'Start Date' are of type `string` and 'End Date' is of type `date`.

The dataset looks like this:
| ID          | Start Date  | End Date   |
| ----------- | ----------- | ---------- |
| 1           | 12-10-2012  | 12-10-2012 |
| 2           | 01-01-2025  | 01-01-2025 |
| 3           | 01012026    | 01-01-2026 |
| 4           | 2025-02-20  | 20-02-2025 |

Examples:

1. If I would want to ensure that entries in the column 'End Date' are valid dates, the following parameter definition is needed:

    ```
    date_format: dd-MM-yyyy
    ```

    The date format is actually not needed as the data element is of type `date` already. However, it is good practice to always define this format. Note the capital 'MM' for months.

    Given the dataset above, all rows would be valid.

2. If I would want to ensure that entries in the column 'Start Date' are valid dates, the following parameter definition is needed:

    ```
    date_format: dd-MM-yyyy
    ```

    The date format is needed and is defined as a date-month-year format. Note the capital 'MM' for months.

    Given the dataset above, rows 1 and 2 would be valid, but row 3 and 4 would result in a hit as they do not follow the format.
"""


class ValidateNumbers(Rule):
    @classmethod
    def subdimension(cls):
        return "Format Acceptance"

    @classmethod
    def aliases(cls):
        return super().aliases()

    @classmethod
    def parameter_definitions(cls):
        return []

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"


class expect_column_values_to_be_numbers(ValidateNumbers):
    @classmethod
    def uuid(cls):
        return "7a9948fb-c5b0-4bc0-9cca-23c5ac0e2e7c"

    @classmethod
    def functional_name(cls):
        return "must be a number (automatable)"

    @classmethod
    def description(cls):
        return (
            "Data attribute must be a valid numeric value. Decimal values are allowed."
        )

    def validate_parameters(self, data_frame: DataFrame) -> None:
        column_type = get_datatype_from_colname(data_frame, self.column_name)
        if column_type in [
            "boolean",
            "date",
            "void",
            "timestamp",
            "array",
            "map",
            "struct",
        ]:
            raise ValueError(f"Column {self.column_name} is not a number.")
        if column_type in ["int", "float", "decimal"]:
            self.log_message(
                "warning",
                "Column datatype is interger/float/decimal so all records will pass.",
            )

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        def check_number(value):
            try:
                string_value = str(value)
                if (
                    string_value.isnumeric()
                    or string_value.replace(".", "", 1).isdecimal()
                ):
                    return True
                else:
                    float(string_value)
                    return True
            except (ValueError, TypeError):
                return False

        check_number_udf = F.udf(lambda z: check_number(z), BooleanType())
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )
        return data_frame.withColumn(
            self.constraint_column_name, check_number_udf(self.column_name)
        )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == True)  # noqa: E712

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == False)  # noqa: E712

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_column_name)

    @classmethod
    def usage_examples(cls):
        return """
This rule ensures that column values are a numerical value.

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Start Number', 'End Number' and 'Other Number'.
- 'ID' and 'Start Number' are of type `string`, 'End Number' is of type `integer` and 'Other Number' is of type `decimal`.

The dataset looks like this:
| ID          | Start Number  | End Number   | Other Number |
| ----------- | ------------- | ------------ | ------------ |
| 1           | 1             | 1            | 1.1          |
| 2           | incorrect     | 2            | 1.0          |
| 3           | 2             | 3            | 2.2          |
| 4           | 123f          |              | 5.1          |

Examples:

1. If I would want to ensure that entries in the column 'End Number' are numerical values, the rule needs to be defined on the correct attribute.
    No parameters are needed.

    Given the dataset above, rows 1, 2 and 3 would be valid, but row 4 would result in a hit as it contains an empty value.

2. If I would want to ensure that entries in the column 'Other Number' are numerical values, the rule needs to be defined on the correct attribute.
    No parameters are needed.

    Given the dataset above, all rows would be valid.

3. If I would want to ensure that entries in the column 'Start Number' are numerical values, the rule needs to be defined on the correct attribute.
    No parameters are needed.

    Given the dataset above, rows 1 and 3 would be valid, but row 2 and 4 would result in a hit as they are not numerical values.
"""


class expect_column_values_to_be_a_whole_number(ValidateNumbers):
    @classmethod
    def uuid(cls):
        return "882aa77b-4080-47df-9709-08771415ac94"

    @classmethod
    def functional_name(cls):
        return "must be a whole number (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must be a valid whole number. Decimal values are not allowed."

    def validate_parameters(self, data_frame: DataFrame) -> None:
        column_type = get_datatype_from_colname(data_frame, self.column_name)
        if column_type in [
            "boolean",
            "date",
            "void",
            "timestamp",
            "array",
            "map",
            "struct",
            "double",
        ]:
            raise ValueError(f"Column {self.column_name} is not a number or a string.")
        if column_type in ["int"]:
            self.log_message(
                "warning", "Column datatype is interger so all records will pass."
            )

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        def check_number(value):
            try:
                _ = float(value)
                return float(value).is_integer()
            except (ValueError, TypeError):
                return False

        check_number_udf = F.udf(lambda z: check_number(z), BooleanType())
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )
        return data_frame.withColumn(
            self.constraint_column_name, check_number_udf(self.column_name)
        )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == True)  # noqa: E712

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == False)  # noqa: E712

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_column_name)

    @classmethod
    def usage_examples(cls):
        return """
This rule ensures that column values are whole numbers.

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Start Number', 'End Number' and 'Other Number'.
- 'ID' and 'Start Number' are of type `string`, 'End Number' is of type `integer` and 'Other Number' is of type `decimal`.

The dataset looks like this:
| ID          | Start Number  | End Number   | Other Number |
| ----------- | ------------- | ------------ | ------------ |
| 1           | 1             | 1            | 1.1          |
| 2           | 2             | 2            | 1.0          |
| 3           | 2.2           | 3            | 2.2          |
| 4           | 123           |              | 5.1          |

Examples:

1. If I would want to ensure that entries in the column 'End Number' are whole numbers, the rule needs to be defined on the correct attribute.
    No parameters are needed.

    Given the dataset above, rows 1, 2 and 3 would be valid, but row 4 would result in a hit as it contains an empty value.

2. If I would want to ensure that entries in the column 'Other Number' are whole numbers, the rule needs to be defined on the correct attribute.
    No parameters are needed.

    Given the dataset above, all rows would result in hits as all values are decimal.

3. If I would want to ensure that entries in the column 'Start Number' are whole numbers, the rule needs to be defined on the correct attribute.
    No parameters are needed.

    Given the dataset above, rows 1, 2 and 4 would be valid, but row 3 would result in a hit as it contains a decimal value.
"""


class expect_column_values_to_be_amount(ValidateNumbers):
    @classmethod
    def uuid(cls):
        return "e089a28a-9a16-4f2a-b9af-ec29dc44ef73"

    @classmethod
    def functional_name(cls):
        return "must be an amount (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must be a valid amount. This rule ensures that all data is considered correct if the data type is integer, double, or numeric. If the data type is a string, it will validate the amount."

    def validate_parameters(self, data_frame: DataFrame) -> None:
        column_type = get_datatype_from_colname(data_frame, self.column_name)
        if column_type in [
            "boolean",
            "date",
            "void",
            "timestamp",
            "array",
            "map",
            "struct",
        ]:
            raise ValueError(
                f"Column {self.column_name} is not a number or string.So valid amount can't be validated"
            )
        if column_type in ["int", "float", "decimal"]:
            self.log_message(
                "warning",
                "Column datatype is interger/float/decimal so all records will pass.",
            )

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        def check_amount(value):
            try:
                string_value = str(value)
                if (
                    string_value.isnumeric()
                    or string_value.replace(".", "", 1).isdecimal()
                ):
                    return True
                else:
                    float(string_value.replace(".", "").replace(",", "."))
                    return True
            except (ValueError, TypeError):
                return False

        check_amount_udf = F.udf(lambda z: check_amount(z), BooleanType())
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )
        return data_frame.withColumn(
            self.constraint_column_name, check_amount_udf(self.column_name)
        )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == True)  # noqa: E712

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == False)  # noqa: E712

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_column_name)

    @classmethod
    def usage_examples(cls):
        return """
This rule ensures that column values are valid amounts.
Note that only numerical values or strings will be validated. Other datatypes will raise errors.

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Start Number', 'End Number' and 'Other Number'.
- 'ID' and 'Start Number' are of type `string`, 'End Number' is of type `integer` and 'Other Number' is of type `decimal`.

The dataset looks like this:
| ID          | Start Number  | End Number   | Other Number |
| ----------- | ------------- | ------------ | ------------ |
| 1           | 1.111,00      | 1            | 1.10         |
| 2           | 2000          | 2            | 1000.00      |
| 3           | 2.345,00      | 3            | 2200.20      |
| 4           | invalid       |              | 5.10         |

Examples:

1. If I would want to ensure that entries in the column 'End Number' are valid amounts, the rule needs to be defined on the correct attribute.
    No parameters are needed.

    Given the dataset above, rows 1, 2 and 3 would be valid, but row 4 would result in a hit as it contains an empty value.

2. If I would want to ensure that entries in the column 'Other Number' are valid amounts, the rule needs to be defined on the correct attribute.
    No parameters are needed.

    Given the dataset above, all rows would be valid.

3. If I would want to ensure that entries in the column 'Start Number' are valid amounts, the rule needs to be defined on the correct attribute.
    No parameters are needed.

    Given the dataset above, rows 1, 2 and 3 would be valid, but row 4 would result in a hit as it contains an invalid value.
"""
