from .rule import Rule, ParameterDefinition
from abc import abstractmethod
from typing import Literal
from pyspark.sql import DataFrame
from .custom_exceptions import ParameterNotFoundException
from .helpers import get_datatype_from_colname


class NumericColumnComparisonRule(Rule):
    @classmethod
    @abstractmethod
    def operator(cls) -> Literal["<", ">", "=", "<=", ">="]:
        pass

    @classmethod
    @abstractmethod
    def operator_desc(cls) -> str:
        pass

    @classmethod
    def functional_name(cls):
        return f"must be {cls.operator_desc()} other attribute (automatable)"

    @classmethod
    def description(cls):
        return f"Compares whether the attribute under inspection is a numeric value {cls.operator_desc()} the numeric value in another column.\n\nWill also fail if either attribute is not filled or contains a non-numeric value."

    @classmethod
    def subdimension(cls):
        return "Logic Consistency"

    @classmethod
    def aliases(cls):
        return super().aliases()

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="column_to_compare",
                functional_name="Comparison attribute",
                description="The attribute against which to compare. ",
                value_type="data-attribute",
                logical_type="value",
                required=True,
                is_reference_data_attribute=False,
            )
        ]

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def parse_parameters(self, parameters):
        super().parse_parameters(parameters)
        if "column_to_compare" not in parameters:
            raise ParameterNotFoundException(
                "Parameter 'column_to_compare' not found in parameters"
            )
        self.column_to_compare = parameters["column_to_compare"].column_name

    def validate_parameters(self, data_frame: DataFrame) -> None:
        if self.column_to_compare not in data_frame.columns:
            raise ValueError(f"{self.column_to_compare} not found in data")
        main_column_dtype = get_datatype_from_colname(data_frame, self.column_name)
        column_to_compare_dtype = get_datatype_from_colname(
            data_frame, self.column_to_compare
        )
        if main_column_dtype in [
            "boolean",
            "date",
            "void",
            "timestamp",
            "array",
            "map",
            "struct",
            "string",
        ]:
            raise ValueError(f"Column {self.column_name} is not a number")
        if column_to_compare_dtype in [
            "boolean",
            "date",
            "void",
            "timestamp",
            "array",
            "map",
            "struct",
            "string",
        ]:
            raise ValueError(f"Column {self.column_to_compare} is not a number")


class expect_column_values_to_be_greater_than_other_column(NumericColumnComparisonRule):
    @classmethod
    def operator(cls):
        return ">"

    @classmethod
    def operator_desc(cls):
        return "greater than"

    @classmethod
    def uuid(cls):
        return "b654e995-b3c7-4bcf-b91b-e15aec435231"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            data_frame[self.column_name] > data_frame[self.column_to_compare]
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] > data_frame[self.column_to_compare])
            | (data_frame[self.column_name].isNull())
            | (data_frame[self.column_to_compare].isNull())
        )


class expect_column_values_to_be_equal_or_greater_than_other_column(
    NumericColumnComparisonRule
):
    @classmethod
    def uuid(cls):
        return "1cad1512-bed4-4efa-8311-6aa440fc45ab"

    @classmethod
    def operator(cls):
        return ">="

    @classmethod
    def operator_desc(cls):
        return "equal or greater than"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            data_frame[self.column_name] >= data_frame[self.column_to_compare]
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] >= data_frame[self.column_to_compare])
            | (data_frame[self.column_name].isNull())
            | (data_frame[self.column_to_compare].isNull())
        )


class expect_column_values_to_be_less_than_other_column(NumericColumnComparisonRule):
    @classmethod
    def uuid(cls):
        return "b7ed243e-9c98-4bf8-8a8d-cd07a330d4a8"

    @classmethod
    def operator(cls):
        return "<"

    @classmethod
    def operator_desc(cls):
        return "less than"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            data_frame[self.column_name] < data_frame[self.column_to_compare]
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] < data_frame[self.column_to_compare])
            | (data_frame[self.column_name].isNull())
            | (data_frame[self.column_to_compare].isNull())
        )


class expect_column_values_to_be_equal_or_less_than_other_column(
    NumericColumnComparisonRule
):
    @classmethod
    def uuid(cls):
        return "89126823-36fc-442b-b1d9-eb199c715801"

    @classmethod
    def operator(cls):
        return "<="

    @classmethod
    def operator_desc(cls):
        return "equal or less than"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            data_frame[self.column_name] <= data_frame[self.column_to_compare]
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] <= data_frame[self.column_to_compare])
            | (data_frame[self.column_name].isNull())
            | (data_frame[self.column_to_compare].isNull())
        )
