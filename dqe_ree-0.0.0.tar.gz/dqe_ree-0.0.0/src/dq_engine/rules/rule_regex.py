from typing import List, Literal

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StringType

from .custom_exceptions import (
    DatatypeException,
    InvalidRegexException,
    ParameterNotFoundException,
    ParameterNotSetException,
)
from .helpers import generate_constraint_column_name, get_datatype_from_colname
from .rule import ParameterDefinition, Rule


class expect_column_values_to_match_generic_regex(Rule):
    @classmethod
    def uuid(cls):
        return "cbda44bc-7c58-4259-bebe-0561e8a13b63"

    @classmethod
    def aliases(cls):
        return []

    @classmethod
    def functional_name(cls):
        return "must be valid for given regular expression (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must be valid according to the provided regular expression. \
                Regular expression must not be provided between slashes. \
                This check uses Spark Regular Expression, which has a Java RegEx flavor. For more information opn RegEx, \
                see explanations at https://en.wikipedia.org/wiki/Regular_expression and tool support at \
                e.g. https://www.codeproject.com/Articles/5334829/Regex-7-free-test-tools"

    @classmethod
    def subdimension(cls):
        return "Format Acceptance"

    @classmethod
    def parameter_definitions(cls) -> List[ParameterDefinition]:
        return [
            ParameterDefinition(
                technical_name="regex",
                functional_name="Regex string Input",
                description="Regex string to match against atributes",
                value_type="string",
                logical_type="value",
                required=True,
            )
        ]

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def parse_parameters(self, parameters):
        if "regex" not in parameters:
            raise ParameterNotFoundException("Parameter 'regex' not found")
        self.regex = parameters["regex"]

    def validate_parameters(self, data_frame):
        if not self.regex:
            raise ParameterNotSetException("Parameter 'regex' not set correctly.")

        try:
            import re

            re.compile(self.regex)
        except re.error:
            raise InvalidRegexException("Not a valid regex expression.")

        if (
            str(get_datatype_from_colname(data_frame, self.column_name))[:7]
            == "decimal"
        ):
            raise DatatypeException(
                "Column type decimal not supported. Only strings, integers and longs types are currently supported"
            )
        elif get_datatype_from_colname(data_frame, self.column_name) not in [
            "string",
            "integer",
            "long",
        ]:
            raise DatatypeException(
                f"Column type {get_datatype_from_colname(data_frame, self.column_name)} not supported. Only strings, integers and longs types are currently supported"
            )

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )
        data_frame = data_frame.withColumn(
            "_str_" + self.column_name, data_frame[self.column_name].cast(StringType())
        ).withColumn(
            self.constraint_column_name,
            F.col("_str_" + self.column_name).rlike(self.regex),
        )
        return data_frame

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == True)  # noqa: E712

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            (data_frame[self.constraint_column_name] != True)  # noqa: E712
            | (data_frame[self.constraint_column_name].isNull())
        )

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_column_name, "_str_" + self.column_name)

    @classmethod
    def usage_examples(cls):
        return """
This rule ensures that column values conform to a user defined regular expression.

Use case:

Regular Expressions are quite complex, but allow you to many things. For basic string manipulations a SQL `LIKE` statement might be easier. See the documentation page for the SQL `LIKE` rule [here](./rules/must-be-valid-for-given-sql-like-pattern-(automatable)-documentation).

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Value', 'Country' and 'Date of Birth'.
- All columns are of type `string`.
- I want codes to follow the following format: Codes must contain 2 uppercase letters, 4 digits and 2 lowercase letters in that order. The regular expression to enforce this is regex `^[A-Z]{2}\d{4}[a-z]{2}$`.

The dataset looks like this:
| ID          | Code          |
| ----------- | ------------- |
| 1           | NL1234nl      |
| 2           | nl4321NL      |
| 3           | DE8984de      |
| 4           | FR09876fr     |

Examples:

1. If I would want to ensure that entries in the column 'Code' follow the format as determined above, the following parameter needs to be defined:
    ```
    regex: ^[A-Z]{2}\d{4}[a-z]{2}$
    ```

    Given the dataset above, rows 1 and 3 would be valid, but rows 2 and 4 would result in hits, as the values do not conform with the defined format.
"""


class expect_column_values_to_match_sql_like_pattern(Rule):
    def __init__(self, **kwargs):
        self.like_pattern = None
        super().__init__(**kwargs)

    @classmethod
    def uuid(cls):
        return "f542f266-fb5e-4c40-9d44-aa4d3baafdd6"

    @classmethod
    def aliases(cls):
        return []

    @classmethod
    def functional_name(cls):
        return "must be valid for given sql like pattern (automatable)"

    @classmethod
    def description(cls):
        return (
            "Data attribute must be valid according to the provided sql like search pattern . This check uses Spark"
            "Like Expression. For more information on Like patterns, see explanation "
            "at https://spark.apache.org/docs/latest/sql-ref-syntax-qry-select-like.html"
        )

    @classmethod
    def subdimension(cls):
        return "Format Acceptance"

    @classmethod
    def parameter_definitions(cls) -> List[ParameterDefinition]:
        return [
            ParameterDefinition(
                technical_name="like_pattern",
                functional_name="like_pattern Input",
                description="Pattern string to search against attribute",
                value_type="string",
                logical_type="value",
                required=True,
            )
        ]

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def parse_parameters(self, parameters):
        if "like_pattern" not in parameters:
            raise ParameterNotFoundException("Parameter 'like_pattern' not found")
        self.like_pattern = parameters["like_pattern"]

    def validate_parameters(self, data_frame):
        if not self.like_pattern:
            raise ParameterNotSetException(
                "Parameter 'like_pattern' not set correctly."
            )

        column_datatype = get_datatype_from_colname(data_frame, self.column_name)
        if "decimal" in column_datatype.lower():
            raise DatatypeException(
                "Column type decimal not supported. Only strings, integers and longs types are currently supported"
            )
        elif column_datatype not in ["string", "integer", "long"]:
            raise DatatypeException(
                f"Column type {column_datatype} not supported. Only strings, integers and longs types are currently supported"
            )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.column_name].like(self.like_pattern))

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            (~data_frame[self.column_name].like(self.like_pattern))
            | (data_frame[self.column_name].isNull())
        )

    @classmethod
    def usage_examples(cls):
        return """
This rule ensures that column values conform to a user defined regular expression.

Use case:

SQL `LIKE` patterns give easy solutions for string matching. For more complex and precise matching consider using regular expressions. See the documentation page for the regular expression rule [here](./rules/must-be-valid-for-given-regular-expression-(automatable)-documentation).

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Value', 'Country' and 'Date of Birth'.
- All columns are of type `string`.
- I want all email addresses present in the data to only be from the mycompany domain. A SQL `LIKE` pattern to use for this is: `%@company.com`.

The dataset looks like this:
| ID          | Email Address        |
| ----------- | -------------------- |
| 1           | user1@mycompany.com  |
| 2           | user2@mycompany.com  |
| 3           | user3@gmail.com      |
| 4           | user4@mycompany.com  |

Examples:

1. If I would want to ensure that entries in the column 'Email Address' only contain 'mycompany' email addresses, the following parameter needs to be defined:
    ```
    like_pattern: %@company.com
    ```

    Given the dataset above, rows 1, 2 and 4 would be valid, but row 3 would result in a hit, as the values do not conform with the defined format.
"""
