class BaseException(Exception):
    def __init__(self, message: str, error_code: int) -> None:
        self.error_code = error_code
        self.message = message
        super().__init__(self.message)

    def get_error_json(self):
        return {"code": self.error_code, "description": self.message}


class ColumnNotFoundException(BaseException):
    def __init__(self, column_name, available_columns):
        super().__init__(
            f"Column '{column_name}' does not exist in Data Frame, check the validity of the provided column name or data attribute uuid. "
            f"Available columns are: {available_columns}.",
            501,
        )


class ParameterNotFoundException(BaseException):
    def __init__(self, message) -> None:
        super().__init__(message, error_code=502)


class InvalidParameterException(BaseException):
    def __init__(self, message) -> None:
        super().__init__(message, error_code=503)


class ParameterNotSetException(BaseException):
    def __init__(self, message) -> None:
        super().__init__(message, error_code=504)


class InvalidRegexException(BaseException):
    def __init__(self, message) -> None:
        super().__init__(message, error_code=505)


class DatatypeException(BaseException):
    def __init__(self, message) -> None:
        super().__init__(message, error_code=506)


class AttributeIDNotFoundException(BaseException):
    def __init__(self, message):
        super().__init__(message, error_code=507)


class InvalidAttributeException(BaseException):
    def __init__(self, message):
        super().__init__(message, error_code=508)


class InvalidColumnDatatypeException(BaseException):
    def __init__(self, message) -> None:
        super().__init__(message, error_code=509)


class HelperFunctionDictNotFoundException(BaseException):
    def __init__(self):
        super().__init__("Helper function dict not found.", error_code=510)


class HelperFunctionNotFoundException(BaseException):
    def __init__(self, funtion_name):
        super().__init__(f"{funtion_name} helper function not found.", error_code=511)


class HelperMetadataTableNotFoundException(BaseException):
    def __init__(self):
        super().__init__("helper metadata table not found.", error_code=512)


class FileNameNotFoundException(BaseException):
    def __init__(self, *args: object) -> None:
        super().__init__("filename not found for data attribute uuid.", error_code=513)


class UnknownInstanceException(BaseException):
    def __init__(self, *args: object) -> None:
        super().__init__(f"Unknown databricks instance id: {args[0]}", error_code=514)


class FileReadException(BaseException):
    def __init__(self, file_name: str) -> None:
        super().__init__(f"Cannot list snapshots for file: {file_name}", error_code=515)


class FileNotFoundException(BaseException):
    def __init__(self, file_name, file_type) -> None:
        super().__init__(
            f"File not found: {file_name}, file type: {file_type}", error_code=516
        )


class InvalidRuleNameException(BaseException):
    def __init__(self, technical_name: str, instance_type: str) -> None:
        super().__init__(
            f"Invalid rule name: '{technical_name}' in {instance_type}", 517
        )


class DataAttributeIdNotFoundException(BaseException):
    def __init__(self, instance_type: str) -> None:
        super().__init__(
            f"Data Attribute uuID not found in rule. In {instance_type}.", 518
        )


class ParametersMissingException(BaseException):
    def __init__(self, instance_type: str) -> None:
        super().__init__(
            f"parameters missing or not present in rule data. In {instance_type}.", 519
        )


class ParametersNotArrayTypeException(BaseException):
    def __init__(self, key: str, instance_type: str) -> None:
        super().__init__(
            f"Error: Parameter '{key}' not of type 'array' in {instance_type}", 520
        )


class CheckIDNotFoundException(BaseException):
    def __init__(self) -> None:
        super().__init__("Check ID not found.", 521)


class GoldenDataElementNotFoundException(BaseException):
    def __init__(
        self,
    ) -> None:
        super().__init__("Golden Data Element id not found.", 522)


class RuleNotFoundException(BaseException):
    def __init__(
        self,
    ) -> None:
        super().__init__("Rule not found.", 523)


class FilterNotFoundException(BaseException):
    def __init__(
        self,
    ) -> None:
        super().__init__("Filters key not found.", 524)


class DataAttributeNotFoundException(BaseException):
    def __init__(self, data_attribute) -> None:
        super().__init__(
            f"Data attribute '{data_attribute}' is not defined on the flat file. Please check the validity of the provided data attribute uuid.",
            525,
        )


class DataAttributeNotFoundValidationException(BaseException):
    def __init__(self, data_attribute, filename, rule_type, attribute_type) -> None:
        super().__init__(
            f"The {attribute_type} data attribute '{data_attribute}' in the {rule_type} is not defined on the expected file '{filename}'. Please check the validity of the provided data attribute uuid.",
            526,
        )


class PrimaryKeyColumnNotFoundException(BaseException):
    def __init__(self, column_name, available_columns):
        super().__init__(
            f"Primary key(s) '{column_name}' does/do not exist in Data Frame, check the validity of the provided primary key(s). "
            f"Available columns are: {available_columns}.",
            527,
        )


# creating a dictionary of all the BaseException subclasses
exceptions_dict = {
    name: obj
    for name, obj in globals().items()
    if isinstance(obj, type)
    and issubclass(obj, BaseException)
    and obj is not BaseException
}

GENERIC_ERROR_MESSAGE = "Some internal error occurred"


def get_error_json(error_obj: Exception) -> dict:
    "this functions takes in the error class object from custom erros and returs the string message and the error code"
    if isinstance(error_obj, BaseException):
        return error_obj.get_error_json()
    return {"code": 500, "description": GENERIC_ERROR_MESSAGE}
