from functools import reduce
from typing import Literal

from pyspark.sql import DataFrame, functions as F

from .helpers import generate_constraint_column_name
from .rule import Rule, ParameterDefinition


class expect_column_values_to_be_unique(Rule):
    @classmethod
    def uuid(cls):
        return "b2127e11-c463-414f-8704-9abd84e0dfc3"

    @classmethod
    def functional_name(cls):
        return "must be unique (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must contain unique values. If additional attributes are provided the attribute needs to be unique in combination with the other data attributes."

    @classmethod
    def subdimension(cls):
        return "Duplicates Avoidance"

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="additional_attributes",
                functional_name="Additional attributes to verify uniqueness",
                description="The additional attributes in combination with which the attributes should be unique.",
                value_type="data-attribute",
                logical_type="array",
                required=False,
                is_reference_data_attribute=False,
            )
        ]

    @classmethod
    def aliases(cls):
        return super().aliases()

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def parse_parameters(self, parameters: dict) -> None:
        super().parse_parameters(parameters)
        if not parameters.get("additional_attributes"):
            parameters["additional_attributes"] = []
        additional_attributes = [
            att.column_name for att in parameters["additional_attributes"]
        ]
        self.additional_attributes = (
            additional_attributes
            if self.column_name in additional_attributes
            else additional_attributes + [self.column_name]
        )

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )
        count_repetitions: DataFrame = (
            data_frame.groupby(self.additional_attributes)
            .count()
            .withColumnRenamed("count", self.constraint_column_name)
        )
        join_condition = reduce(
            lambda x, y: x & y,
            [
                data_frame[k].eqNullSafe(count_repetitions[k])
                for k in self.additional_attributes
            ],
        )
        return (
            data_frame.alias("a")
            .join(count_repetitions, join_condition, "left")
            .select(F.col("a.*"), F.col(self.constraint_column_name))
        )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(f"{self.constraint_column_name} == 1")

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(f"{self.constraint_column_name} > 1")

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_column_name)

    @classmethod
    def usage_examples(cls):
        return """
This rule ensures that column values are unique.

Imagine the following:

- I have a physical dataset containing the following data elements: 'ID', 'Value', 'Country' and 'Date of Birth'.
- All columns are of type `string`.

The dataset looks like this:
| ID          | Value         | Country | Date of Birth |
| ----------- | ------------- | ------- | ------------- |
| 1           | 1             | nl      | 01-01-1990    |
| 2           | 2             | be      | 02-01-1980    |
| 3           | 2             | de      | 02-02-1950    |
| 4           | 2             | de      | 02-02-1950    |

Examples:

1. If I would want to ensure that entries in the column 'ID' are unique, the rule needs to be defined on the correct attribute.
    No parameters are needed.

    Given the dataset above, all rows would be valid as there are no duplicate values.

2. If I would want to ensure that entries in the columns 'Value', 'Country' and 'Date of Birth' are unique, the rule needs to be defined on one of these attributes (let's assume the attribute for the 'Value' column) and the following parameters are needed:
    ```
    additional_attributes: [{data attribute identifier of the 'Country' column}, {{data attribute identifier of the 'Date of Birth' column}}]
    ```

    For the additional attributes, select the attribute identifiers for the attributes that need to be included in the check.
    **Note** that, if the check is already defined on one of the attributes as mentioned, this attribute does not need to be present in the `additional_attributes` parameter.

    Given the dataset above, rows 1 and 2 would be passing but rows 3 and 4 would result in hits, as they contain the exact same values for the given columns.
"""
