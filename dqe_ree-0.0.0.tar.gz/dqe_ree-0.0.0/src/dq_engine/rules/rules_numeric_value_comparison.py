from decimal import Decimal
from typing import Literal

from pyspark.sql import DataFrame

from .custom_exceptions import DatatypeException, ParameterNotFoundException
from .helpers import get_datatype_from_colname
from .rule import ABC, ParameterDefinition, Rule, abstractmethod


class NumericValueComparisonRule(Rule, ABC):
    @classmethod
    @abstractmethod
    def operator(cls) -> Literal["<", ">", "=", "!=", "=<", "=>"]:
        pass

    @classmethod
    @abstractmethod
    def operator_desc(cls): ...

    @classmethod
    def functional_name(cls):
        return f"must be {cls.operator_desc()} given numeric value (automatable)"

    @classmethod
    def description(cls):
        return (
            f"Compares whether the Data attribute under inspection contains a numeric value {cls.operator_desc()} the "
            f"given value.\n\nWill also fail if either attribute is not filled or contains a non-numeric value."
        )

    @classmethod
    def subdimension(cls):
        return "Values Acceptance"

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="value",
                functional_name="Numeric Comparison value",
                description="The Numeric value against which to compare. Only accepts numeric values. Decimal values should "
                'have "." as decimal separator',
                value_type="number",
                logical_type="value",
                required=True,
            )
        ]

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def parse_parameters(self, parameters):
        if "value" not in parameters:
            raise ParameterNotFoundException(
                "Parameter 'value' not found in parameters"
            )
        self.value = parameters["value"]
        str_value = str(self.value)
        if not str_value.isnumeric() and not str_value.replace(".", "", 1).isdecimal():
            raise ValueError("Comparison value is not numeric")
        self.value = (
            int(str_value) if str(str_value).isnumeric() else Decimal(str_value)
        )

    def validate_parameters(self, data_frame: DataFrame) -> None:
        column_type = get_datatype_from_colname(data_frame, self.column_name)
        if column_type in [
            "boolean",
            "date",
            "void",
            "timestamp",
            "array",
            "map",
            "struct",
        ]:
            raise DatatypeException(
                f"Column {self.column_name} datatype is not string or numeric."
            )


class expect_column_values_to_be_greater_than_given_number(NumericValueComparisonRule):
    @classmethod
    def uuid(cls):
        return "e3c51c51-94d0-4fe2-ba32-921d12d26d39"

    @classmethod
    def operator(cls):
        return ">"

    @classmethod
    def operator_desc(cls):
        return "greater than"

    @classmethod
    def aliases(cls):
        return super().aliases()

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.column_name] > self.value)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] > self.value)
            | data_frame[self.column_name].isNull()
        )


class expect_column_values_to_be_equal_or_greater_than_given_number(
    NumericValueComparisonRule
):
    @classmethod
    def uuid(cls):
        return "d48fddd8-1dec-4041-89ca-5c51a6a95004"

    @classmethod
    def aliases(cls):
        return ["expect_column_values_to_be_minimum_to_integer"]

    @classmethod
    def operator(cls):
        return "=>"

    @classmethod
    def operator_desc(cls):
        return "equal or greater than"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.column_name] >= self.value)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] >= self.value)
            | data_frame[self.column_name].isNull()
        )


class expect_column_values_to_be_less_than_given_number(NumericValueComparisonRule):
    @classmethod
    def uuid(cls):
        return "6438c37c-edca-4250-8781-441f4f4668e7"

    @classmethod
    def operator(cls):
        return "<"

    @classmethod
    def operator_desc(cls):
        return "less than"

    @classmethod
    def aliases(cls):
        return super().aliases()

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.column_name] < self.value)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] < self.value)
            | data_frame[self.column_name].isNull()
        )


class expect_column_values_to_be_equal_or_less_than_given_number(
    NumericValueComparisonRule
):
    @classmethod
    def uuid(cls):
        return "990efaef-268d-475b-bf65-b14ac15f172f"

    @classmethod
    def aliases(cls):
        return ["expect_column_values_to_be_maximum_to_integer"]

    @classmethod
    def operator(cls):
        return "=<"

    @classmethod
    def operator_desc(cls):
        return "equal or less than"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.column_name] <= self.value)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] <= self.value)
            | data_frame[self.column_name].isNull()
        )


class expect_column_values_to_be_equal_to_given_number(NumericValueComparisonRule):
    @classmethod
    def uuid(cls):
        return "78490880-bdc3-4d44-86a9-dca2e9a723b3"

    @classmethod
    def operator(cls):
        return "="

    @classmethod
    def operator_desc(cls):
        return "equal to"

    @classmethod
    def aliases(cls):
        return super().aliases()

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.column_name] == self.value)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] == self.value)
            | data_frame[self.column_name].isNull()
        )


class expect_column_values_to_be_not_equal_to_given_number(NumericValueComparisonRule):
    @classmethod
    def uuid(cls):
        return "8b39e79d-ceab-47c8-8430-cffc6a357e0d"

    @classmethod
    def operator(cls):
        return "!="

    @classmethod
    def operator_desc(cls):
        return "not equal to"

    @classmethod
    def aliases(cls):
        return super().aliases()

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] == self.value)
            | (data_frame[self.column_name].isNull())
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.column_name] == self.value)


class expect_column_values_to_be_within_given_range(Rule):
    @classmethod
    def uuid(cls):
        return "eabb823a-65b1-4ea7-9c02-ef6704578a99"

    @classmethod
    def aliases(cls):
        return ["expect_column_values_to_be_between"]

    @classmethod
    def functional_name(cls):
        return "must be within given range (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must contain a value which falls within the given range."

    @classmethod
    def subdimension(cls):
        return "Values Acceptance"

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="lower_bound",
                functional_name="Minimum",
                description="The minimal allowed value.",
                value_type="number",
                logical_type="value",
                required=True,
            ),
            ParameterDefinition(
                technical_name="upper_bound",
                functional_name="Maximum",
                description="The maximal allowed value.",
                value_type="number",
                logical_type="value",
                required=True,
            ),
        ]

    def check_valid_number(self, value):
        try:
            float(value)
            return True
        except ValueError:
            return False

    def parse_parameters(self, parameters: dict) -> None:
        if "lower_bound" not in parameters:
            raise ParameterNotFoundException("Parameter 'lower_bound' not found.")
        if "upper_bound" not in parameters:
            raise ParameterNotFoundException("Parameter 'upper_bound' not found.")
        lower_bound = str(parameters["lower_bound"])
        upper_bound = str(parameters["upper_bound"])
        if not self.check_valid_number(lower_bound):
            raise ValueError("Parameter 'lower_bound' should be a valid number.")
        if not self.check_valid_number(upper_bound):
            raise ValueError("Parameter 'upper_bound' should be a valid number.")
        self.lower_bound = (
            int(lower_bound) if lower_bound.isnumeric() else Decimal(lower_bound)
        )
        self.upper_bound = (
            int(upper_bound) if upper_bound.isnumeric() else Decimal(upper_bound)
        )
        if self.lower_bound >= self.upper_bound:
            raise ValueError("lower_bound should be less than upper bound.")

    def validate_parameters(self, data_frame: DataFrame) -> None:
        column_type = get_datatype_from_colname(data_frame, self.column_name)
        if column_type in [
            "boolean",
            "date",
            "void",
            "timestamp",
            "array",
            "map",
            "struct",
        ]:
            raise DatatypeException(
                f"Column {self.column_name} datatype is not string or numeric."
            )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            (data_frame[self.column_name] >= self.lower_bound)
            & (data_frame[self.column_name] <= self.upper_bound)
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(
                (data_frame[self.column_name] >= self.lower_bound)
                & (data_frame[self.column_name] <= self.upper_bound)
            )
            | data_frame[self.column_name].isNull()
        )
