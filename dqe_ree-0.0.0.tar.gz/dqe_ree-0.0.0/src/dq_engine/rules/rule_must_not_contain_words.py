from typing import Literal

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import BooleanType

from .custom_exceptions import DatatypeException, ParameterNotFoundException
from .helpers import (
    generate_constraint_column_name,
    get_datatype_from_colname,
    BooleanParameter,
)
from .rule import ParameterDefinition, Rule


def contain_not_allowed_words(value, not_allowed_words):
    if value is None or value == "":
        return True
    distinct_words = set(value.lower().split(" "))
    return not bool(distinct_words.intersection(set(not_allowed_words)))


class expect_column_string_values_to_not_contain_words(Rule):
    @classmethod
    def uuid(cls):
        return "7b61a910-de36-45e6-8982-78a3328d6722"

    @classmethod
    def aliases(cls):
        return super().aliases()

    @classmethod
    def functional_name(cls):
        return "must not contain words (automatable)"

    @classmethod
    def description(cls):
        return "Column values must not contain one of the values in the provided list."

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    def subdimension(cls):
        return "Values Acceptance"

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="disallowed_words",
                functional_name="Disallowed words",
                description="One or more words which are not allowed to be present anywhere in the source value. A word is defined as a sequence of characters separated by one or more spaces.",
                value_type="string",
                logical_type="array",
                required=True,
            ),
            ParameterDefinition(
                technical_name="case_sensitive",
                functional_name="Case sensitive",
                description="Whether the values provided should be considered to match even if they have different upper-/lower-casing.",
                value_type="boolean",
                logical_type="value",
                required=True,
                enum_values=BooleanParameter.values_as_list(),
            ),
            ParameterDefinition(
                technical_name="strip_characters",
                functional_name="Characters to remove",
                description="A string of non-whitespace characters which should be ignored when comparing words for equality. If space characters are included they will be ignored.",
                value_type="string",
                logical_type="value",
                required=False,
            ),
        ]

    def parse_parameters(self, parameters):
        if (
            "disallowed_words" not in parameters
            and "case_sensitive" not in parameters
            and "strip_characters" not in parameters
        ):
            raise ParameterNotFoundException("Parameter not found.")
        if "disallowed_words" in parameters:
            self.disallowed_words = parameters["disallowed_words"]
        if "case_sensitive" in parameters:
            self.case_sensitive = parameters["case_sensitive"]
        if "strip_characters" in parameters:
            self.strip_characters = parameters["strip_characters"]

        if not isinstance(self.disallowed_words, list):
            raise ValueError("Parameter should be an array type.")

        if self.case_sensitive not in BooleanParameter.values_as_list():
            raise ValueError(
                "Invalid value for 'case_sensitive' parameter. Only boolean values allowed."
            )

        if not isinstance(self.strip_characters, str):
            raise ValueError("Parameter should be a string type.")

        for word in self.disallowed_words:
            if not isinstance(word, str):
                raise DatatypeException(
                    "Only string values accepted in parameter array."
                )

    def validate_parameters(self, data_frame: DataFrame) -> None:
        column_type = get_datatype_from_colname(data_frame, self.column_name)
        if column_type not in ["string", "char", "varchar"]:
            raise ValueError(f"Column {self.column_name} datatype is not string.")

    def pre_process(self, data_frame: DataFrame):
        check_distinct_udf = F.udf(contain_not_allowed_words, BooleanType())
        data_frame = data_frame.withColumn(
            "_disallowed_words", F.lit(self.disallowed_words)
        )
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )
        return data_frame.withColumn(
            self.constraint_column_name,
            check_distinct_udf(self.column_name, "_disallowed_words"),
        )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == True)  # noqa: E712

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == False)  # noqa: E712

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_column_name, "_disallowed_words")
