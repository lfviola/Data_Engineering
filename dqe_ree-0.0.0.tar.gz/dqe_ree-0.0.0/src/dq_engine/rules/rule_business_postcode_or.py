from typing import Literal

from pyspark.sql import Column, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StringType

from dq_engine.rules.helpers import generate_constraint_column_name
from dq_engine.rules.rule import ParameterDefinition, Rule


class BusinessPostcodeOrRule(Rule):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.constraint_colname = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )

    @classmethod
    def subdimension(cls) -> str:
        return "Logic Consistency"

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    def parameter_definitions(cls) -> list[ParameterDefinition]:
        """Parameter definitions

        Make sure to add the suffix '_value' for non-column name parameters.
        """
        return [
            ParameterDefinition(
                technical_name="postcode_official",
                functional_name="Official postcode column",
                description="The column name of the official postcode column (default is 'PostCode_L')",
                value_type="string",
                logical_type="value",
                required=False,
                default_value="PostCode_L",
            ),
            ParameterDefinition(
                technical_name="postcode_official_value",
                functional_name="Official postcode value",
                description="The value of the official postcode to check for (default is '9700AT')",
                value_type="string",
                logical_type="value",
                required=False,
                default_value="9700AT",
            ),
            ParameterDefinition(
                technical_name="postcode_preferential",
                functional_name="Preferential postcode column",
                description="The column name of the preferential postcode column (default is 'PostCode_P')",
                value_type="string",
                logical_type="value",
                required=False,
                default_value="PostCode_P",
            ),
            ParameterDefinition(
                technical_name="postcode_preferential_value",
                functional_name="Preferential postcode value",
                description="The value of the preferential postcode to check for (default is '9700AT')",
                value_type="string",
                logical_type="value",
                required=False,
                default_value="9700AT",
            ),
            ParameterDefinition(
                technical_name="housenumber_preferential",
                functional_name="Preferential house number column",
                description="The column name of the preferential house number column (default is 'Housenumber_P')",
                value_type="number",
                logical_type="value",
                required=False,
                default_value="Housenumber_P",
            ),
            ParameterDefinition(
                technical_name="housenumber_legal",
                functional_name="Legal house number column",
                description="The column name of the legal house number column (default is 'Housenumber_L')",
                value_type="string",
                logical_type="value",
                required=False,
                default_value="Housenumber_L",
            ),
            ParameterDefinition(
                technical_name="postofficeboxnumber_preferential",
                functional_name="Preferential postoffice box number column",
                description="The column name of the preferential postoffice box number column (default is 'PostOfficeBoxNumber_P')",
                value_type="string",
                logical_type="value",
                required=False,
                default_value="PostOfficeBoxNumber_P",
            ),
            ParameterDefinition(
                technical_name="housenumber_value",
                functional_name="House number value",
                description="The value of the house number or PO box to check for (default is '754')",
                value_type="string",
                logical_type="value",
                required=False,
                default_value="754",
            ),
            ParameterDefinition(
                technical_name="countrycode_legal",
                functional_name="Legal country code column",
                description="The column name of the legal country code column (default is 'CountryCode_L')",
                value_type="string",
                logical_type="value",
                required=False,
                default_value="CountryCode_L",
            ),
            ParameterDefinition(
                technical_name="countrycode_value",
                functional_name="Country code value",
                description="The value of the country code to check for (default is 'NL')",
                value_type="string",
                logical_type="value",
                required=False,
                default_value="NL",
            ),
            ParameterDefinition(
                technical_name="streetname_legal",
                functional_name="Legal street name column",
                description="The column name of the legal street name column (default is 'StreetName_L')",
                value_type="string",
                logical_type="value",
                required=False,
                default_value="StreetName_L",
            ),
        ]

    @classmethod
    def aliases(cls) -> list:
        return super().aliases()

    def parse_parameters(self, parameters) -> None:
        """Set user defined or default value for parameters."""
        super().parse_parameters(parameters)

        for parameter in self.parameter_definitions():
            if parameter.technical_name in parameters:
                setattr(
                    self,
                    parameter.technical_name,
                    parameters[parameter.technical_name].upper(),
                )
            else:
                setattr(
                    self,
                    parameter.technical_name,
                    parameter.default_value.upper(),
                )

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        """Cast all needed columns to string."""
        for parameter in self.parameter_definitions():
            if not parameter.technical_name.endswith("value"):
                column_name = getattr(self, parameter.technical_name)
                data_frame = data_frame.withColumn(
                    column_name, data_frame[column_name].cast(StringType())
                )
        return data_frame.fillna("")


class expect_column_value_to_not_match_postcode_condition(BusinessPostcodeOrRule):
    @classmethod
    def uuid(cls) -> str:
        return "c002e2c6-aedf-4c22-b68b-d9c516736fe3"

    @classmethod
    def functional_name(cls) -> str:
        return "must not match postcode condition (automatable)"

    @classmethod
    def description(cls) -> str:
        return (
            "Data attribute must not match the condition on the postcode. "
            "The condition equates to 1) Checking if offical postcode is equivalent to '9700AT' OR "
            "2) Checking if preferrential postocde is equal to '9700AT' and either one of "
            "preferrential house number, official housenumber or post office box number is equal to '754' OR "
            "3) Legal country code is NL, legal house number is empty and legal streetname is empty with "
            "the post office number filled."
        )

    def condition(self, data_frame: DataFrame) -> Column:
        condition = (
            (
                (F.trim(data_frame[self.postcode_official]) != "")
                & (data_frame[self.postcode_official] == self.postcode_official_value)
            )
            | (
                (
                    (F.trim(data_frame[self.postcode_preferential]) != "")
                    & (
                        data_frame[self.postcode_preferential]
                        == self.postcode_preferential_value
                    )
                )
                & (
                    (
                        data_frame[self.housenumber_preferential]
                        == self.housenumber_value
                    )
                    | (data_frame[self.housenumber_legal] == self.housenumber_value)
                    | (
                        data_frame[self.postofficeboxnumber_preferential]
                        == self.housenumber_value
                    )
                )
            )
            | (
                (data_frame[self.countrycode_legal] == self.countrycode_value)
                & (F.trim(data_frame[self.housenumber_legal]) == "")
                & (F.trim(data_frame[self.streetname_legal]) == "")
                & (F.trim(data_frame[self.postofficeboxnumber_preferential]) != "")
            )
        )
        return condition

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(~self.condition(data_frame))

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(self.condition(data_frame))
