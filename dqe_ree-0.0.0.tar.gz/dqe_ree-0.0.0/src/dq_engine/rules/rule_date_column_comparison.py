"""
This module contains all the rules that compare multiple date columns.
"""

import re
import isodate
import datetime
from pyspark.sql.functions import datediff, col
from typing import Literal, List, Callable
from pyspark.sql.types import IntegerType
from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from dq_engine.rules.custom_exceptions import (
    ParameterNotFoundException,
    InvalidParameterException,
)
from dq_engine.rules.helpers import (
    generate_constraint_column_name,
    get_datatype_from_colname,
    Operator,
)
from dq_engine.rules.rule import ParameterDefinition, Rule

SECONDS_PER_YEAR = (
    ((365 * 3) + 366) / 4
) * 86400  # 1 leap year every 4 years. 86400 seconds per day.
SECONDS_PER_MONTH = SECONDS_PER_YEAR / 12

DATE_TYPES = ["date", "timestamp"]
NUMERICAL_TYPES = ["int", "bigint", "double", "float"]
STR_TYPES = ["string"]
VALID_TYPES = DATE_TYPES + NUMERICAL_TYPES + STR_TYPES


class DateColumnComparisonRule(Rule):
    @classmethod
    def get_operator(cls) -> Literal["<", ">", "=", "!=", "=<", "=>"]:
        return "="

    @classmethod
    def operator_desc(cls) -> str:
        return "default description"

    @classmethod
    def functional_name(cls) -> str:
        return f"must be date {cls.operator_desc()} other attribute (automatable)"

    @classmethod
    def description(cls) -> str:
        return f"Data attribute must contain a date {cls.operator_desc()} the date value in another Data attribute.\n\nWill also fail if either attribute is not filled or contains a value not according to defined parameter."

    @classmethod
    def subdimension(cls) -> str:
        return "Logic Consistency"

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    def parameter_definitions(cls) -> list[ParameterDefinition]:
        return super().parameter_definitions() + [
            ParameterDefinition(
                technical_name="main_date_format",
                functional_name="Main attribute date format",
                description=(
                    "The date format of the attribute this check is defined on as defined by Spark. "
                    "See https://spark.apache.org/docs/latest/sql-ref-datetime-pattern.html. "
                    "Required when the column is not a date type. "
                    "When the column is a numerical type (integer, float, decimal etc.), only date formats 'ddMMyyyy' and 'yyyyMMdd' are supported."
                    "Note that 'MM' stands for month and 'mm' stands for minutes."
                ),
                value_type="string",
                logical_type="value",
                required=False,
            ),
            ParameterDefinition(
                technical_name="column_to_compare",
                functional_name="Comparison attribute",
                description="The attribute against which to compare. ",
                value_type="data-attribute",
                logical_type="value",
                required=True,
                is_reference_data_attribute=False,
            ),
            ParameterDefinition(
                technical_name="comparison_date_format",
                functional_name="Comparison attribute date format",
                description=(
                    "The date format of the attribute to be compared against as defined by Spark. "
                    "See https://spark.apache.org/docs/latest/sql-ref-datetime-pattern.html. "
                    "Required when the column is not a date type. "
                    "When the column is a numerical type (integer, float, decimal etc.), only date formats 'ddMMyyyy' and 'yyyyMMdd' are supported."
                    "Note that 'MM' stands for month and 'mm' stands for minutes."
                ),
                value_type="string",
                logical_type="value",
                required=False,
            ),
        ]

    def parse_parameters(self, parameters):
        """
        steps:
        1 check if main column and column to compare are of type date
        2 if not date type then convert using main_date_format or comparison_date_format
        parameters = {"column_to_compare": 123, "main_date_format": "YYYYmmdd", "comparison_date_format": "YYYYmmdd"}
        """
        super().parse_parameters(parameters)
        if "column_to_compare" not in parameters:
            raise ParameterNotFoundException("Parameter 'column_to_compare' not found.")
        self.column_to_compare = parameters["column_to_compare"].column_name
        self.main_date_format = parameters.get("main_date_format")
        self.comparison_date_format = parameters.get("comparison_date_format")

    def validate_parameters(self, data_frame: DataFrame) -> None:
        col1_type = get_datatype_from_colname(data_frame, self.column_name)
        col2_type = get_datatype_from_colname(data_frame, self.column_to_compare)

        if col1_type not in VALID_TYPES and "decimal" not in col1_type:
            raise ValueError(
                f"Column '{self.column_name}' of type '{col1_type}' is not a date."
            )
        elif col1_type not in DATE_TYPES and not self.main_date_format:
            raise ParameterNotFoundException(
                "Required parameter 'main_date_format' not found. This parameter is required when the date is not a date value."
            )

        if col2_type not in VALID_TYPES and "decimal" not in col2_type:
            raise ValueError(
                f"Column '{self.column_name}' of type '{col2_type}' is not a date."
            )
        elif col2_type not in DATE_TYPES and not self.comparison_date_format:
            raise ParameterNotFoundException(
                "Required parameter 'comparison_date_format' not found. This parameter is required when the date is not a date value."
            )

    def convert_column_based_on_type(
        self,
        df,
        output_type,
        conversion_function,
        col_name,
        converted_col_name,
        col_type,
        date_format,
    ):
        """
        Converts date containing column based on type:
        1. If type is numerical -> Convert to int, cast to string, pad with 0's if needed and convert to date
        2. If type is non date (timestamp or string) -> cast to date
        3. If type is date -> keep as date

        If output type is 'timestamp' the same logic holds, but value gets converted to timestamp instead of date.

        Args:
            df: DataFrame: dataframe containing date column.
            output_type: str: needed output type for date column (date or timestamp).
            conversion_function: func: conversion function to apply on column (convert column to either date or timestamp).
            col_name: str: current column name.
            converted_col_name: str: output column name.
            col_type: str: type of column.
            date_format: str: output date format as defined in parameters.
        """
        if col_type in NUMERICAL_TYPES or "decimal" in col_type:
            # Handle numerical types
            return df.withColumn(
                converted_col_name,
                conversion_function(
                    F.lpad(df[col_name].cast("int").cast("string"), 8, "0"), date_format
                ),
            )
        elif col_type != output_type:
            # Handle non-date types
            return df.withColumn(
                converted_col_name, conversion_function(df[col_name], date_format)
            )
        else:
            # Leave the column unchanged
            return df.withColumn(converted_col_name, df[col_name])

    def pre_process(
        self, data_frame: DataFrame, output_type: str = "date"
    ) -> DataFrame:
        """Pre-process the dataframe to convert date columns to the appropriate format."""
        col1_type = get_datatype_from_colname(data_frame, self.column_name)
        col2_type = get_datatype_from_colname(data_frame, self.column_to_compare)

        self.main_date_converted_col_name = generate_constraint_column_name(
            "main_col", self.column_name
        )
        self.comparison_date_converted_col_name = generate_constraint_column_name(
            "main_col", self.column_to_compare
        )
        if output_type == "date":
            data_frame = self.convert_column_based_on_type(
                data_frame,
                output_type,
                F.to_date,
                self.column_name,
                self.main_date_converted_col_name,
                col1_type,
                self.main_date_format,
            )
            data_frame = self.convert_column_based_on_type(
                data_frame,
                output_type,
                F.to_date,
                self.column_to_compare,
                self.comparison_date_converted_col_name,
                col2_type,
                self.comparison_date_format,
            )

        elif output_type == "timestamp":
            data_frame = self.convert_column_based_on_type(
                data_frame,
                output_type,
                F.to_timestamp,
                self.column_name,
                self.main_date_converted_col_name,
                col1_type,
                self.main_date_format,
            )
            data_frame = self.convert_column_based_on_type(
                data_frame,
                output_type,
                F.to_timestamp,
                self.column_to_compare,
                self.comparison_date_converted_col_name,
                col2_type,
                self.comparison_date_format,
            )

        else:
            raise ValueError("Internal error: Incorrect output type defined")
        return data_frame

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(
            self.main_date_converted_col_name, self.comparison_date_converted_col_name
        )


class expect_column_dates_to_be_greater_than_other_column(DateColumnComparisonRule):
    @classmethod
    def uuid(cls) -> str:
        return "ddaf2224-ee7f-4210-97f5-6f6455d5aa02"

    @classmethod
    def get_operator(cls) -> str:
        return ">"

    @classmethod
    def operator_desc(cls) -> str:
        return "greater than"

    @classmethod
    def aliases(cls) -> list:
        return super().aliases()

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            data_frame[self.main_date_converted_col_name]
            > data_frame[self.comparison_date_converted_col_name]
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(
                data_frame[self.main_date_converted_col_name]
                > data_frame[self.comparison_date_converted_col_name]
            )
            | data_frame[self.main_date_converted_col_name].isNull()
            | data_frame[self.comparison_date_converted_col_name].isNull()
        )


class expect_column_dates_to_be_equal_or_greater_than_other_column(
    DateColumnComparisonRule
):
    @classmethod
    def uuid(cls) -> str:
        return "641cfb66-2002-4200-8b1b-b4801731fa37"

    @classmethod
    def get_operator(cls) -> str:
        return "=>"

    @classmethod
    def operator_desc(cls) -> str:
        return "equal or greater than"

    @classmethod
    def aliases(cls) -> list:
        return super().aliases()

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            data_frame[self.main_date_converted_col_name]
            >= data_frame[self.comparison_date_converted_col_name]
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(
                data_frame[self.main_date_converted_col_name]
                >= data_frame[self.comparison_date_converted_col_name]
            )
            | data_frame[self.main_date_converted_col_name].isNull()
            | data_frame[self.comparison_date_converted_col_name].isNull()
        )


class expect_column_dates_to_be_less_than_other_column(DateColumnComparisonRule):
    @classmethod
    def uuid(cls) -> str:
        return "f4a02e43-b676-430b-876e-ec6af53d6f93"

    @classmethod
    def get_operator(cls) -> str:
        return "<"

    @classmethod
    def operator_desc(cls) -> str:
        return "less than"

    @classmethod
    def aliases(cls) -> list:
        return super().aliases()

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            data_frame[self.main_date_converted_col_name]
            < data_frame[self.comparison_date_converted_col_name]
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(
                data_frame[self.main_date_converted_col_name]
                < data_frame[self.comparison_date_converted_col_name]
            )
            | data_frame[self.main_date_converted_col_name].isNull()
            | data_frame[self.comparison_date_converted_col_name].isNull()
        )


class expect_column_dates_to_be_equal_or_less_than_other_column(
    DateColumnComparisonRule
):
    @classmethod
    def uuid(cls) -> str:
        return "fb6e7e45-9a01-4703-83c0-a98026e37eb8"

    @classmethod
    def get_operator(cls) -> str:
        return "=<"

    @classmethod
    def operator_desc(cls) -> str:
        return "equal or less than"

    @classmethod
    def aliases(cls) -> list:
        return super().aliases()

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            data_frame[self.main_date_converted_col_name]
            <= data_frame[self.comparison_date_converted_col_name]
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(
                data_frame[self.main_date_converted_col_name]
                <= data_frame[self.comparison_date_converted_col_name]
            )
            | data_frame[self.main_date_converted_col_name].isNull()
            | data_frame[self.comparison_date_converted_col_name].isNull()
        )


class expect_column_dates_to_be_equal_to_other_column(DateColumnComparisonRule):
    @classmethod
    def uuid(cls) -> str:
        return "1780a4b0-ba8d-4768-9e08-ac5b6a53bc36"

    @classmethod
    def get_operator(cls) -> str:
        return "="

    @classmethod
    def operator_desc(cls) -> str:
        return "equal to"

    @classmethod
    def aliases(cls) -> list:
        return super().aliases()

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            data_frame[self.main_date_converted_col_name]
            == data_frame[self.comparison_date_converted_col_name]
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(
                data_frame[self.main_date_converted_col_name]
                == data_frame[self.comparison_date_converted_col_name]
            )
            | data_frame[self.main_date_converted_col_name].isNull()
            | data_frame[self.comparison_date_converted_col_name].isNull()
        )


class expect_column_dates_to_be_not_equal_to_other_column(DateColumnComparisonRule):
    @classmethod
    def uuid(cls) -> str:
        return "04f7ae6e-ce6b-4313-955c-e1acb3b3eb5e"

    @classmethod
    def get_operator(cls) -> str:
        return "!="

    @classmethod
    def aliases(cls) -> list:
        return ["expect_column_dates_to_be_different_from_other_column"]

    @classmethod
    def operator_desc(cls) -> str:
        return "not equal to"

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            data_frame[self.main_date_converted_col_name]
            != data_frame[self.comparison_date_converted_col_name]
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(
                data_frame[self.main_date_converted_col_name]
                != data_frame[self.comparison_date_converted_col_name]
            )
            | data_frame[self.main_date_converted_col_name].isNull()
            | data_frame[self.comparison_date_converted_col_name].isNull()
        )


class compare_column_dates_difference_with_period(DateColumnComparisonRule):
    def __init__(self, **kwargs):
        self.period = None
        self.operator = None
        super().__init__(**kwargs)
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )

    @classmethod
    def uuid(cls) -> str:
        return "d19d1cae-b4df-4e7f-8619-33ad673f3a17"

    @classmethod
    def functional_name(cls) -> str:
        return "must be compared against period between two attributes (automatable)"

    @classmethod
    def description(cls) -> str:
        return "Compares against the period difference between 2 date attributes."

    @classmethod
    def subdimension(cls) -> str:
        return "Logic Consistency"

    @classmethod
    def aliases(cls) -> list:
        return []

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    def parameter_definitions(cls):
        return super().parameter_definitions() + [
            ParameterDefinition(
                technical_name="period",
                functional_name="Period",
                description="Period to compare the date difference between the data attributes with. Must conform to an ISO 8601 duration format. See https://www.digi.com/resources/documentation/digidocs//90001488-13/reference/r_iso_8601_duration_format.htm. NOTE: For periods including years and months, the following assumptions are taken: Average days in a year is 365.25 (leap year every 4 years), average days in a month is 30.4375 (365.25/12).",
                value_type="string",
                logical_type="value",
                required=True,
            ),
            ParameterDefinition(
                technical_name="operator",
                functional_name="Comparison Type",
                description="Kind of operator between Number of Days parameter and the number of "
                "days difference between main date value and snapshot date.",
                value_type="string",
                logical_type="value",
                required=True,
                enum_values=Operator.as_list(),
            ),
        ]

    @staticmethod
    def is_iso8601_duration(duration: str) -> bool:
        """
        Validate if the given string is a correct ISO 8601 duration format.
        Definition taken from https://www.digi.com/resources/documentation/digidocs//90001488-13/reference/r_iso_8601_duration_format.htm
        """
        pattern = re.compile(
            r"^P(?!$)(?:(\d+Y)?(\d+M)?(\d+D)?)(T(?=\d)(\d+H)?(\d+M)?(\d+S)?)?$"
        )
        return bool(pattern.match(duration))

    @staticmethod
    def parse_period(period: str) -> int:
        """Parses an ISO 8601 duration format to a number of seconds.

        If duration is an instance of `datetime.timedelta`, we just take the total seconds.
        If duration is an instance of `isodate.duration.Duration`, we need to calculate duration of years and months separately.

        Assumptions taken:
        - Average days in a year is 365.25 (leap year every 4 years)
        - Average days in a month is 30.4375 (365.25/12)

        Raises type error in the case that 3rd party logic changes.
        """
        duration = isodate.parse_duration(period)

        if isinstance(duration, datetime.timedelta):
            period = duration.total_seconds()
        elif isinstance(duration, isodate.duration.Duration):
            period = round(
                (float(duration.years) * SECONDS_PER_YEAR)
                + (float(duration.months) * SECONDS_PER_MONTH)
                + duration.total_seconds()
            )
        else:
            raise TypeError("Issue converting period string to a duration.")
        return period

    def parse_parameters(self, parameters: dict):
        """Parse and validate parameters including the period."""
        super().parse_parameters(parameters)
        self.operator = Operator.get_operator_from_str(parameters["operator"])
        if self.is_iso8601_duration(parameters["period"]):
            self.period = self.parse_period(parameters["period"])
        else:
            raise InvalidParameterException(
                f"Period '{parameters['period']}' does not adhere to the ISO 8601 duration format. Please update this parameter according to https://www.digi.com/resources/documentation/digidocs//90001488-13/reference/r_iso_8601_duration_format.htm"
            )

    def validate_parameters(self, data_frame: DataFrame) -> None:
        super().validate_parameters(data_frame)

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        data_frame = super().pre_process(
            data_frame, output_type="timestamp"
        )  # As a period can contain time information, it is vital to keep this
        data_frame = data_frame.withColumn(
            self.main_date_converted_col_name,
            F.unix_timestamp(data_frame[self.main_date_converted_col_name]),
        )
        data_frame = data_frame.withColumn(
            self.comparison_date_converted_col_name,
            F.unix_timestamp(data_frame[self.comparison_date_converted_col_name]),
        )
        return data_frame

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            self.operator(
                F.abs(
                    data_frame[self.main_date_converted_col_name]
                    - data_frame[self.comparison_date_converted_col_name]
                ),
                self.period,
            )
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            (
                ~self.operator(
                    F.abs(
                        data_frame[self.main_date_converted_col_name]
                        - data_frame[self.comparison_date_converted_col_name]
                    ),
                    self.period,
                )
            )
            | (
                data_frame[self.main_date_converted_col_name].isNull()
                | data_frame[self.comparison_date_converted_col_name].isNull()
            )
        )


class DaysDifferenceDateColumnComparisonRule(DateColumnComparisonRule):
    """
    Rule to compare the number of days difference between two date columns
    against a third column in the dataframe.
    Supports different comparison types, such as: equal, distinct, equal or less,
    less, equal or greater and greater.
    """

    operator: Callable
    main_date_converted_col_name: str
    comparison_date_converted_col_name: str
    days_difference_col_name: str
    days_difference_col_name_int: str = "days_difference_col_name_int"
    actual_days_difference_col_name: str = "actual_days_difference"

    @classmethod
    def uuid(cls) -> str:
        return "038373fe-7cfa-4c26-9f7c-1b8d4b09fd26"

    @classmethod
    def functional_name(cls) -> str:
        return "Days difference between two date attributes compared to third attribute (automatable)"

    @classmethod
    def aliases(cls):
        """possible aliases in case of changing name for renaming"""
        return []

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    def description(cls) -> str:
        return """
            Rule to compare the number of days difference between two date columns
            against a third column in the dataframe.
            The rule calculates the days of difference between 2 date attributes and then
            compares that number with the value of a third attribute containing the
            days of difference to be compared against to.
            Supports different comparison types, such as: equal, distinct, equal or less,
            less, equal or greater and greater.
            \n\n The records do not pass the check if:
            \n - The difference of days do not adhere to the rule.
            \n - Any of the mandatory attributes is missing.
        """

    @classmethod
    def subdimension(cls):
        return "Logic Consistency"

    @classmethod
    def parameter_definitions(cls) -> List[ParameterDefinition]:
        return super().parameter_definitions() + [
            ParameterDefinition(
                technical_name="days_difference_column",
                functional_name="Attribute id for dates difference column",
                description="Attribute id which contains the days difference value between the two date columns.",
                value_type="data-attribute",
                logical_type="value",
                required=True,
            ),
            ParameterDefinition(
                technical_name="comparison_type",
                functional_name="Comparison",
                description="The type of comparison.",
                value_type="string",
                logical_type="value",
                required=True,
                enum_values=Operator.as_list(),
                default_value=Operator.IS.name.lower(),
            ),
        ]

    def parse_parameters(self, parameters) -> None:
        super().parse_parameters(parameters)
        self.operator = Operator.get_operator_from_str(parameters["comparison_type"])
        if "days_difference_column" in parameters:
            self.days_difference_col_name = parameters[
                "days_difference_column"
            ].column_name

    def pre_process(self, data_frame) -> DataFrame:
        data_frame = super().pre_process(data_frame)

        # Calculate the number of days between the two dates
        data_frame = data_frame.withColumn(
            self.actual_days_difference_col_name,
            datediff(
                start=col(self.main_date_converted_col_name),
                end=col(self.comparison_date_converted_col_name),
            ),
        )

        # Convert days of difference column to integer
        data_frame = data_frame.withColumn(
            self.days_difference_col_name_int,
            col(self.days_difference_col_name).cast(IntegerType()),
        )

        return data_frame

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        data_frame = super().post_process(data_frame)
        return data_frame.drop(
            self.days_difference_col_name_int, self.actual_days_difference_col_name
        )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        """
        Execute the check and return a dataframe which contains
        only passing records (records that adhere to the rule)
        """
        return data_frame.filter(
            self.operator(
                data_frame[self.days_difference_col_name_int],
                data_frame[self.actual_days_difference_col_name],
            )
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        """
        Execute the check and return a dataframe which contains only
        failing records (records that do not adhere to the rule)
        """
        return data_frame.filter(
            ~self.operator(
                data_frame[self.days_difference_col_name_int],
                data_frame[self.actual_days_difference_col_name],
            )
            | (
                (data_frame[self.days_difference_col_name_int].isNull())
                | (data_frame[self.comparison_date_converted_col_name].isNull())
                | (data_frame[self.main_date_converted_col_name].isNull())
            )
        )

    @classmethod
    def usage_examples(cls) -> str:
        """Method containing specific examples for a DQ rule."""
        return "Test"


def is_iso8601_duration(duration: str) -> bool:
    """
    Validate if the given string is a correct ISO 8601 duration format.
    Definition taken from https://www.digi.com/resources/documentation/digidocs//90001488-13/reference/r_iso_8601_duration_format.htm
    """
    pattern = re.compile(
        r"^P(?!$)(?:(\d+Y)?(\d+M)?(\d+D)?)(T(?=\d)(\d+H)?(\d+M)?(\d+S)?)?$"
    )
    return bool(pattern.match(duration))
