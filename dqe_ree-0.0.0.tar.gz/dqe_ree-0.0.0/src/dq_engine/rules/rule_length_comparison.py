from abc import abstractmethod
from typing import Literal

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from .custom_exceptions import (
    InvalidColumnDatatypeException,
    ParameterNotFoundException,
)
from .helpers import generate_constraint_column_name, get_datatype_from_colname
from .rule import ParameterDefinition, Rule


class LengthComparisonRule(Rule):
    @classmethod
    @abstractmethod
    def operator(cls) -> Literal["=", "=<", "=>"]:
        pass

    @classmethod
    @abstractmethod
    def operator_desc(cls):
        pass

    @classmethod
    def functional_name(cls):
        return f"must be of length {cls.operator_desc()} given number (automatable)"

    @classmethod
    def description(cls):
        return f"Data attribute must contain a string value whose length is {cls.operator_desc()} the given number. Does not allow numeric fields to be checked."

    @classmethod
    def subdimension(cls):
        return "Format Acceptance"

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="length",
                functional_name="Length",
                description="The length against which to compare.",
                value_type="number",
                logical_type="value",
                required=True,
            )
        ]

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @staticmethod
    def valid_number(val):
        try:
            str_val = str(val)
            if str_val.isalnum():
                return False
            if "." in str_val:
                return False
            return True
        except Exception:
            return False

    def parse_parameters(self, parameters: dict) -> None:
        if "length" not in parameters and "number" not in parameters:
            raise ParameterNotFoundException("Parameter 'length' not found.")
        self.length = (
            parameters["length"] if "length" in parameters else parameters["number"]
        )
        if (
            not str(self.length).isnumeric()
            or int(self.length) < 0
            or self.length is None
        ):
            raise ValueError("Parameter 'length' should be a valid positive integer.")
        self.length = int(self.length)

    def validate_parameters(self, data_frame: DataFrame) -> None:
        if get_datatype_from_colname(data_frame, self.column_name) != "string":
            raise InvalidColumnDatatypeException("Column datatype is not a string.")

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )
        return data_frame.withColumn(
            self.constraint_column_name, F.length(data_frame[self.column_name])
        )

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_column_name)


class expect_column_values_length_to_be_equal_or_greater_than_given_number(
    LengthComparisonRule
):
    @classmethod
    def uuid(cls):
        return "b9063783-6073-431c-9552-20b533be9d0b"

    @classmethod
    def aliases(cls):
        return ["expect_column_values_length_to_be_at_least_number"]

    @classmethod
    def operator(cls):
        return "=>"

    @classmethod
    def operator_desc(cls):
        return "equal or greater than"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] >= self.length)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.constraint_column_name] >= self.length)
            | (data_frame[self.column_name].isNull())
        )


class expect_column_values_length_to_be_equal_or_less_than_given_number(
    LengthComparisonRule
):
    @classmethod
    def uuid(cls):
        return "25b8404a-0086-468b-ac6b-465f44cd7122"

    @classmethod
    def aliases(cls):
        return ["expect_column_values_length_to_be_equals_or_lessthan"]

    @classmethod
    def operator(cls):
        return "=<"

    @classmethod
    def operator_desc(cls):
        return "equal or less than"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] <= self.length)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.constraint_column_name] <= self.length)
            | (data_frame[self.column_name].isNull())
        )


class expect_column_values_length_to_be_equal_to_given_number(LengthComparisonRule):
    @classmethod
    def uuid(cls):
        return "25718c8c-7959-4275-babe-47c1d07b2cc0"

    @classmethod
    def aliases(cls):
        return ["expect_column_values_length_to_be_equal_to_number"]

    @classmethod
    def operator(cls):
        return "="

    @classmethod
    def operator_desc(cls):
        return "equal to"

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == self.length)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.constraint_column_name] == self.length)
            | (data_frame[self.column_name].isNull())
        )


class expect_column_values_length_to_be_within_given_range(Rule):
    @classmethod
    def uuid(cls):
        return "9bf26aa7-6d33-436f-bf33-a794e53372c1"

    @classmethod
    def aliases(cls):
        return ["expect_column_value_lengths_to_be_between"]

    @classmethod
    def functional_name(cls):
        return "must be of length in a given range (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must contain a string value whose length falls within the given range. Does not allow numeric fields to be checked."

    @classmethod
    def subdimension(cls):
        return "Format Acceptance"

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="lower_bound",
                functional_name="Minimum Length",
                description="The minimal allowed length of the value.",
                value_type="number",
                logical_type="value",
                required=True,
            ),
            ParameterDefinition(
                technical_name="upper_bound",
                functional_name="Maximum Length",
                description="The maximal allowed length of the value.",
                value_type="number",
                logical_type="value",
                required=True,
            ),
        ]

    def parse_parameters(self, parameters: dict) -> None:
        if "lower_bound" not in parameters:
            raise ParameterNotFoundException("Parameter 'lower_bound' not found.")
        if "upper_bound" not in parameters:
            raise ParameterNotFoundException("Parameter 'upper_bound' not found.")
        self.lower_bound = parameters["lower_bound"]
        self.upper_bound = parameters["upper_bound"]
        if (
            not str(self.lower_bound).isnumeric()
            or int(self.lower_bound) < 0
            or self.lower_bound is None
        ):
            raise ValueError(
                "Parameter 'lower_bound' should be a valid positive integer."
            )
        if (
            not str(self.upper_bound).isnumeric()
            or int(self.upper_bound) < 0
            or self.upper_bound is None
        ):
            raise ValueError(
                "Parameter 'upper_bound' should be a valid positive integer."
            )
        self.lower_bound = int(self.lower_bound)
        self.upper_bound = int(self.upper_bound)
        if self.upper_bound <= self.lower_bound:
            raise ValueError("Upper bound should be higher than lower bound.")

    def validate_parameters(self, data_frame: DataFrame) -> None:
        if get_datatype_from_colname(data_frame, self.column_name) != "string":
            raise InvalidColumnDatatypeException("Column datatype is not a string.")

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )
        return data_frame.withColumn(
            self.constraint_column_name, F.length(data_frame[self.column_name])
        )

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_column_name)

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            (data_frame[self.constraint_column_name] >= self.lower_bound)
            & (data_frame[self.constraint_column_name] <= self.upper_bound)
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(
                (data_frame[self.constraint_column_name] >= self.lower_bound)
                & (data_frame[self.constraint_column_name] <= self.upper_bound)
            )
            | (data_frame[self.column_name].isNull())
        )
