from dq_engine.rules.rule import Rule, DataFrame
from dq_engine.rules.helpers import (
    get_datatype_from_colname,
    generate_constraint_column_name,
)
from pyspark.sql import functions as F
from typing import Literal
from pyspark.sql.types import BooleanType


def bsn_check(value):
    string_value = str(value).replace(".", "").replace(" ", "")
    if not string_value.isnumeric():
        return False
    if 9 < len(string_value) or len(string_value) < 8:
        return False
    mult_list = [9, 8, 7, 6, 5, 4, 3, 2, -1]
    bsn_list = list(map(int, string_value.rjust(9, "0")))
    zip_list = list(zip(mult_list, bsn_list))
    digit_sum = sum(map(lambda x: x[0] * x[1], zip_list))
    if digit_sum % 11 == 0:
        return True
    else:
        return False


class expect_column_to_be_valid_BSN(Rule):
    @classmethod
    def uuid(cls):
        return "5a77f04c-cc6c-4d54-8bd6-918ca8b02c5a"

    @classmethod
    def functional_name(cls):
        return "must be valid BSN (automatable)"

    @classmethod
    def description(cls):
        return (
            "The column must be a valid whole number which is compliant with the BSN format. "
            "This is tested using a special case of the elf-proef algorithm https://nl.wikipedia.org/wiki/Burgerservicenummer"
        )

    @classmethod
    def subdimension(cls):
        return "Format Acceptance"

    @classmethod
    def aliases(cls):
        return super().aliases()

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    def parameter_definitions(cls):
        return []

    def parse_parameters(self, parameters):
        return super().parse_parameters(parameters)

    def validate_parameters(self, data_frame: DataFrame) -> None:
        column_type = get_datatype_from_colname(data_frame, self.column_name)
        if column_type in [
            "boolean",
            "date",
            "void",
            "timestamp",
            "array",
            "map",
            "struct",
            "double",
            "decimal",
            "float",
        ]:
            raise ValueError(f"Column {self.column_name} is not a number or a string.")
        if column_type in ["int"]:
            self.log_message(
                "warning", "Column datatype is interger so all records will pass."
            )

    def pre_process(self, data_frame: DataFrame) -> DataFrame:
        check_number_udf = F.udf(lambda z: bsn_check(z), BooleanType())
        self.constraint_column_name = generate_constraint_column_name(
            self.__class__.__name__, self.column_name
        )
        return data_frame.withColumn(
            self.constraint_column_name, check_number_udf(self.column_name)
        )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == True)  # noqa: E712

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.constraint_column_name] == False)  # noqa: E712

    def post_process(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.drop(self.constraint_column_name)
