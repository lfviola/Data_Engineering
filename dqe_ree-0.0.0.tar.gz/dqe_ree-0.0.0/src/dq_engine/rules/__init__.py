from os.path import dirname, basename, isfile, join
import glob

# to import all rules in the directory
modules = glob.glob(join(dirname(__file__), "*.py"))
all_modules = [
    basename(f)[:-3]
    for f in modules
    if isfile(f)
    and basename(f).startswith("rule")
    and not basename(f).endswith("__init__.py")
]
__all__ = [*all_modules]
