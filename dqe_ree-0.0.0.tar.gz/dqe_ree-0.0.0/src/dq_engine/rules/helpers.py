import string
import operator

from random import SystemRandom
from enum import Enum
from typing import Literal, Callable

from dq_engine.rules.custom_exceptions import ColumnNotFoundException


class BooleanParameter(Enum):
    TRUE = True
    FALSE = False

    @classmethod
    def values_as_list(cls) -> list:
        return [member.value for member in cls]


class Operator(Enum):
    IS = operator.eq
    IS_NOT = operator.ne
    LESS_THAN = operator.lt
    LESS_THAN_OR_EQUAL = operator.le
    GREATER_THAN = operator.gt
    GREATER_THAN_OR_EQUAL = operator.ge

    @classmethod
    def as_list(cls) -> list:
        return [member.name.lower().replace("_", " ") for member in cls]

    @classmethod
    def get_operator_from_str(
        cls,
        operator_str: Literal[
            "is",
            "is not",
            "less than",
            "less than or equal",
            "greater than",
            "greater than or equal",
        ],
    ) -> Callable:
        """Retrieves an operator for a given readable string"""
        try:
            return cls[operator_str.upper().replace(" ", "_")].value
        except KeyError:
            raise ValueError(
                f"Unknown operator type '{operator_str}', please select from {cls.as_list()}"
            )


def generate_constraint_column_name(constraint_type: str, column_name: str) -> str:
    cryptogen = SystemRandom()
    random_suffix = "".join(cryptogen.choice(string.ascii_lowercase) for _ in range(12))
    return f"__checkengine__{column_name.replace(' ', '_')}_{constraint_type}_{random_suffix}"


def get_datatype_from_colname(df, colname):
    """
    Gets the datatype of a column from a dataframe.
    Raises a ColumnNotFoundException if the column can not be found in the provided dataframe.
    """
    if colname not in df.schema.fieldNames():
        raise ColumnNotFoundException(colname, df.columns)
    return [c[1] for c in df.dtypes if c[0] == colname][0]


string_datatypes = ["string", "char", "varchar"]
