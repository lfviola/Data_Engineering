from .rule import Rule, ParameterDefinition
from pyspark.sql import DataFrame
from .custom_exceptions import ParameterNotFoundException
from .helpers import get_datatype_from_colname
from decimal import Decimal
from datetime import datetime


class EqualityRule(Rule):
    @classmethod
    def scope(cls):
        return "both"

    @classmethod
    def subdimension(cls):
        return "Values Acceptance"

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="value",
                functional_name="Value",
                description="The value to check for. Numeric, decimal and date values can be provided. Date values should be in format 'dd-MM-yyyy'.",
                value_type="string",
                logical_type="value",
                required=True,
            )
        ]

    @staticmethod
    def check_number_and_return_datatype(value):
        try:
            string_value = str(value)
            if string_value.isnumeric() or string_value.replace(".", "", 1).isdecimal():
                data_type = int
                if isinstance(value, float) or "." in string_value:
                    data_type = float
                return True, data_type
            else:
                # for handling negative values
                float(string_value)
                data_type = int
                if isinstance(value, float) or "." in string_value:
                    data_type = float
                return True, data_type
        except (ValueError, TypeError):
            return False, None

    # validate parameter itself
    def parse_parameters(self, parameters):
        if "value" not in parameters:
            raise ParameterNotFoundException("Parameter 'value' not found")
        self.value = parameters["value"]
        if (
            not self.value and self.value != 0
        ):  # in order to accept 0 as boolean we have to add this here
            raise ValueError("Value cannot be empty")

        if type(self.value) in [tuple, list]:
            raise ValueError("Value cannot be of type tuple or array")

    # validate the values in the dataframe
    def validate_parameters(self, data_frame):
        column_type = get_datatype_from_colname(data_frame, self.column_name)

        if column_type == "float":
            raise ValueError("Exact matches can't be made against floats")

        elif column_type in ["timestamp"]:
            raise ValueError(
                "The following data type is currently not supported: timestamp"
            )
        # "array", "map", "struct" are handled by pyspark ParseException: DataType ... is not supported

        elif column_type == "string":
            self.value = str(self.value)

        elif column_type in ["int", "bigint", "tinyint", "smallint"]:
            valid_number, value_type = self.check_number_and_return_datatype(self.value)
            if not valid_number:
                raise ValueError("Value is not numeric")
            if value_type is not int:
                raise ValueError("Datatype mismatch between value and column datatype")
            self.value = int(self.value)

        elif column_type in ["decimal", "double"]:
            valid_number, value_type = self.check_number_and_return_datatype(self.value)
            if not valid_number:
                raise ValueError("Value is not numeric")
            if value_type is not float:
                raise ValueError("Datatype mismatch between value and column datatype")
            self.value = (
                Decimal(self.value)
                if isinstance(self.value, str)
                else Decimal(repr(self.value))
            )

        elif column_type == "boolean":
            if isinstance(self.value, str):
                self.value = self.value.lower()
            if self.value == "true" or self.value == 1:
                self.value = True
            elif self.value == "false" or self.value == 0:
                self.value = False
            else:
                raise ValueError(f"Value is not boolean: '{self.value}'")

        elif column_type == "date":
            try:
                self.value = datetime.strptime(self.value, "%d-%m-%Y").date()
            except ValueError:
                raise ValueError("Value does not match format 'dd-mm-yyyy'")


class expect_column_values_to_be_equal_to_value(EqualityRule):
    @classmethod
    def uuid(cls):
        return "fe40cbf2-0e65-4eca-af46-4635cc941995"

    @classmethod
    def aliases(cls):
        return ["expect_column_values_to_be_value", "EQUALS"]

    @classmethod
    def functional_name(cls):
        return "must be given value (automatable)"

    @classmethod
    def description(cls):
        return "Data attribute must equal to the given value."

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.column_name] == self.value)

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] == self.value)
            | (data_frame[self.column_name].isNull())
        )


class expect_column_values_to_be_not_equal_to_value(EqualityRule):
    @classmethod
    def uuid(cls):
        return "533fdaef-3b10-4c5d-8f8c-e96830119419"

    @classmethod
    def functional_name(cls):
        return "must not be given value (automatable)"

    @classmethod
    def aliases(cls):
        return ["expect_column_values_to_be_not_equal_to_value", "NOTEQUALS"]

    @classmethod
    def description(cls):
        return "Data attribute must not equal the given value."

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            ~(data_frame[self.column_name] == self.value)
            | (data_frame[self.column_name].isNull())
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(data_frame[self.column_name] == self.value)
