from pyspark.sql import functions as F

from .rule import DataFrame, Rule


class expect_column_values_to_not_be_null(Rule):
    @classmethod
    def uuid(cls):
        return "336deb7c-b612-4bf7-82f7-1656bc536c5f"

    @classmethod
    def technical_name(cls):
        return "expect_column_values_to_not_be_null"

    @classmethod
    def aliases(cls):
        return ["ISNOTNULL", "ISNOTEMPTY"]

    @classmethod
    def functional_name(cls):
        return "must be filled (automatable)"

    @classmethod
    def description(cls):
        return "checks if a Data attribute value is not null or not a blank string. For documentation see: https://dev.azure.com/cbsp-abnamro/GRD0001077/_wiki/wikis/DQ%20Rule%20Engine%20Modernization/112875/must-be-filled-(automatable)-documentation"

    @classmethod
    def scope(cls):
        return "both"

    @classmethod
    def subdimension(cls):
        return "Population Coverage"

    @classmethod
    def parameter_definitions(cls):
        return []

    def parse_parameters(self, parameters):
        return super().parse_parameters(parameters)

    def passing(self, data_frame):
        return data_frame.filter(
            (data_frame[self.column_name].isNotNull())
            & (F.trim(data_frame[self.column_name]) != "")
        )

    def failing(self, data_frame):
        return data_frame.filter(
            (data_frame[self.column_name].isNull())
            | (F.trim(data_frame[self.column_name]) == "")
        )

    @classmethod
    def usage_examples(cls) -> str:
        return """
Imagine the following:

- I have a physical dataset containing the following data attributes: 'ID' and 'Country'.

The dataset looks like this:
| ID          | Country     |
| ----------- | ----------- |
| 1           | nl          |
| 2           | de          |
| 3           | uk          |
| 4           |             |


If I would want to ensure that no entry in the data attribute 'Country' is empty, the rule needs to be defined on this data attribute:

Given the dataset above, rows 1, 2 and 3 would be valid, and 4 would result in a hit.
"""


class expect_column_values_to_be_null(Rule):
    @classmethod
    def uuid(cls):
        return "b3b69da2-8edd-42ad-9c3e-395be79fca09"

    @classmethod
    def technical_name(cls):
        return "expect_column_values_to_be_null"

    @classmethod
    def aliases(cls):
        return ["ISNULL", "ISEMPTY"]

    @classmethod
    def functional_name(cls):
        return "must not be filled (automatable)"

    @classmethod
    def description(cls):
        return "checks if a Data attribute value is null or blank string. For documentation see: https://dev.azure.com/cbsp-abnamro/GRD0001077/_wiki/wikis/DQ%20Rule%20Engine%20Modernization/112895/must-not-be-filled-(automatable)-documentation."

    @classmethod
    def scope(cls):
        return "both"

    @classmethod
    def subdimension(cls):
        return "Population Coverage"

    @classmethod
    def parameter_definitions(cls):
        return []

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            (data_frame[self.column_name].isNull())
            | (F.trim(data_frame[self.column_name]) == "")
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.filter(
            (data_frame[self.column_name].isNotNull())
            & (F.trim(data_frame[self.column_name]) != "")
        )

    @classmethod
    def usage_examples(cls) -> str:
        return """
Imagine the following:

- I have a physical dataset containing the following data attributes: 'ID', 'Country', 'Retired' and 'Retirement Date'.
- 'ID', 'Country' and 'Retirement Date' are of type `string`, Retired is of type `boolean`.

The dataset looks like this:
| ID          | Country     | Retired   | Retirement Date
| ----------- | ----------- | --------- | ---------------- |
| 1           | nl          | True      | 12-10-2012       |
| 2           | de          | False     |                  |
| 3           | uk          | True      | 01-01-2023       |
| 4           |             | False     | 20-02-2024       |


If I would want to ensure that everyone who isn't retired also does not have a retirement date, I would use the 'must not be filled (automatable)' rule.

Note:

- This would also need a filter defined on the 'Retired' attribute, only filtering records where its value is 'False'. Generally speaking, the 'must not be filled (automatable)' rule will need a filter to be useful.
- For more information on filters, see [Data Quality Check User Manual](https://confluence.int.abnamro.com/display/DQMDP/Data+Quality+Check+User+Manual#DataQualityCheckUserManual-2.4Filters:)

Given the dataset above and the example, rows 1 and 3 would be out of scope, row 2 would pass and row 4 would result in a hit.
"""
