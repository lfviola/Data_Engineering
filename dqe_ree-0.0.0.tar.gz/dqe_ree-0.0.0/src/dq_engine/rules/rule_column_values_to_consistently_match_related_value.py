from .rule import Rule, DataFrame, ParameterDefinition
from .helpers import get_datatype_from_colname
from typing import Literal


class expect_column_values_to_consistently_match_related_value(Rule):
    @classmethod
    def uuid(cls):
        return "018eec70-c3e2-7fd6-aa94-68ed9126b27d"

    @classmethod
    def functional_name(cls):
        return "must be consistent given value in related attribute (automatable)"

    @classmethod
    def description(cls):
        return "Checks for a column if the column with another column (pair) is consistent in the dataset For example: two records with the same parent should always have the same grandparent."

    @classmethod
    def subdimension(cls):
        return "Logic Consistency"

    @classmethod
    def aliases(cls):
        return super().aliases()

    @classmethod
    def scope(cls) -> Literal["check", "filter", "both"]:
        return "both"

    @classmethod
    def parameter_definitions(cls):
        return [
            ParameterDefinition(
                technical_name="related_value_attribute",
                functional_name="Related consistent value",
                description="The column containing the value which should always be identical for identical values of the main column of this DQ Check. For example: two records with the same parent should always have the same grandparent.",
                value_type="data-attribute",
                logical_type="value",
                required=True,
                is_reference_data_attribute=False,
            )
        ]

    def parse_parameters(self, parameters):
        super().parse_parameters(parameters)
        self.column_related = parameters["related_value_attribute"].column_name

    def validate_parameters(self, data_frame: DataFrame) -> None:
        if get_datatype_from_colname(
            data_frame, self.column_name
        ) != get_datatype_from_colname(data_frame, self.column_related):
            raise ValueError(
                f"Column {self.column_name} is not of same data type as a Column {self.column_related}"
            )

    def passing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.join(
            (data_frame.groupBy(self.column_name, self.column_related).count())
            .groupBy(self.column_name)
            .count()
            .filter("count > 1"),
            on=self.column_name,
            how="leftanti",
        )

    def failing(self, data_frame: DataFrame) -> DataFrame:
        return data_frame.join(
            (data_frame.groupBy(self.column_name, self.column_related).count())
            .groupBy(self.column_name)
            .count()
            .filter("count == 1"),
            on=self.column_name,
            how="leftanti",
        )
