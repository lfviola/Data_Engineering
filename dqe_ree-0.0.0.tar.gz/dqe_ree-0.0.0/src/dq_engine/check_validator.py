import ast
import datetime
import json
import logging
import os
from collections import defaultdict
from functools import reduce
from operator import and_
from typing import Optional

from pyspark.sql import DataFrame, SparkSession

from dq_engine.lib import rule_json_export
from dq_engine.rules.custom_exceptions import (
    CheckIDNotFoundException,
    DataAttributeIdNotFoundException,
    FilterNotFoundException,
    GoldenDataElementNotFoundException,
    InvalidRuleNameException,
    ParametersMissingException,
    ParametersNotArrayTypeException,
    RuleNotFoundException,
    get_error_json,
)
from dq_engine.utils.check_output import log_check_output
from dq_engine.utils.helpers import AzureFileHandler

logger = logging.getLogger(__name__)


class ValidateDQChecks:
    """
    Class responsible for:
    - Loading DQ Checks parquets from DQ Library storage account.
    - Validating DQ Checks.
    - Writing valid and invalid checks to DQE storage account.
    """

    def __init__(
        self,
        spark: SparkSession,
        reader_file_handler: AzureFileHandler,
        writer_file_handler: AzureFileHandler,
        reader_end_point: str,
        check_status_filters: list[str],
        check_source_filters: list[str],
        extra_filters: Optional[dict] = None,
    ) -> None:
        self.spark = spark
        self.dq_lib_file_handler = reader_file_handler
        self.dqe_file_handler = writer_file_handler
        self.reader_end_point = reader_end_point
        self.status_filters = check_status_filters
        self.source_filters = check_source_filters
        self.extra_filters = extra_filters if extra_filters else {}
        self.dqe_container_name = "dqe-data"
        self.parameter_rules: dict = {
            rule["technical_name"]: {
                parameter["technical_name"]: {
                    "required": parameter["required"],
                    "type": parameter["value_type"],
                }
                for parameter in rule["parameters"]
            }
            for rule in rule_json_export()
        }
        self.update_parameter_rules()
        self.functional_name_technical_name_map: dict[str, str] = {
            rule["name"]: rule["technical_name"] for rule in rule_json_export()
        }

    def update_parameter_rules(self):
        self.parameter_rules["expect_column_values_to_be_in_list"].update(
            {
                "allowed_values": {
                    "required": True,
                    "type": "array",
                }
            }
        )
        self.parameter_rules["expect_column_values_to_not_be_in_list"].update(
            {
                "allowed_values": {
                    "required": True,
                    "type": "array",
                }
            }
        )

    def validate_rule_instance(self, rule_dict: dict, instance_type: str) -> list:
        errors = []
        rules = self.parameter_rules.get(rule_dict["technical_name"], {})
        if rule_dict["technical_name"] not in self.parameter_rules:
            errors.append(
                InvalidRuleNameException(rule_dict["technical_name"], instance_type)
            )
        if "data_attribute" not in rule_dict:
            errors.append(DataAttributeIdNotFoundException(instance_type))
        if not rule_dict["data_attribute"]:
            errors.append(
                DataAttributeIdNotFoundException(instance_type)
            )  # ToDo: create DataAttributeNotFoundException (without id)
        if "parameters" not in rule_dict or rule_dict["parameters"] is None:
            errors.append(ParametersMissingException(instance_type))
        for key, values in rules.items():
            if not values["required"]:
                continue
            if values["type"] != "array":
                continue
            param_value = rule_dict["parameters"].get(key)
            if not param_value and param_value != "":
                continue
            if not isinstance(param_value, list):
                errors.append(ParametersNotArrayTypeException(key, instance_type))
        return errors

    def validate_check_keys(self, check) -> list:
        errors = []
        if "id" not in check:
            errors.append(CheckIDNotFoundException())
        if (
            "golden_data_element_id" not in check
            or not str(check["golden_data_element_id"]).strip()
        ):
            errors.append(GoldenDataElementNotFoundException())
        if "rule" not in check:
            errors.append(RuleNotFoundException())
        if "filters" not in check:
            errors.append(FilterNotFoundException())

        return errors

    def validate_check(self, check: dict) -> list:
        check_error_list = self.validate_check_keys(check)
        check_error_list.extend(
            self.validate_rule_instance(check["rule"], instance_type="rule")
        )

        for filter_instance in check["filters"]:
            filter_validation = self.validate_rule_instance(
                rule_dict=filter_instance, instance_type="filter"
            )
            check_error_list.extend(filter_validation)
        return [get_error_json(err) for err in check_error_list]

    def validate_checks_list(
        self, checks_list: list[dict]
    ) -> tuple[list, list, dict, int]:
        valid_checks, invalid_checks = [], []
        errors_dict = dict()
        checks_validated_count = 0
        for num, check in enumerate(checks_list):
            if (
                check["status_id"] not in self.status_filters
                or check["source_id"] not in self.source_filters
            ):
                continue
            validation_errors = self.validate_check(check)
            if not validation_errors:
                valid_checks.append(check)
            else:
                errors_dict[check["id"]] = {
                    "errors": validation_errors,
                    "rule_json": check,
                }
                invalid_checks.append(check)
            checks_validated_count += 1
        return valid_checks, invalid_checks, errors_dict, checks_validated_count

    def return_check_json(self, rule_data, filter_data) -> dict:
        rule_dict = {
            "technical_name": self.functional_name_technical_name_map.get(
                rule_data.dq_rule, rule_data.dq_rule
            ),
            "parameters": ast.literal_eval(rule_data["rule_parameters"]),
            "data_attribute": {
                "data_attribute_uuid": rule_data["data_attribute_uuid"],
                "data_attribute_source": rule_data["data_attribute_source"],
            },
        }
        filter_dict = [
            {
                "parameters": ast.literal_eval(_filter["parameters"]),
                "description": _filter["description"],
                "data_attribute": {
                    "data_attribute_uuid": _filter["data_attribute_uuid"],
                    "data_attribute_source": rule_data["data_attribute_source"],
                },
                "technical_name": self.functional_name_technical_name_map.get(
                    _filter["dq_rule"], _filter["dq_rule"]
                ),
            }
            for _filter in filter_data
        ]
        rule_json = {
            "golden_data_element_id": rule_data["golden_data_element_id"],
            "id": rule_data["id"],
            "description": rule_data["functional_description"],
            "status_id": rule_data["business_status"],
            "source_id": rule_data["dq_rule_source"],
            "rule": rule_dict,
            "filters": filter_dict,
            "uuid_source": rule_data["data_attribute_source"],
        }

        return rule_json

    def validate_checks_parquets(
        self, dq_checks: DataFrame, dq_filters: DataFrame
    ) -> tuple[
        list,
        list,
        dict,
        int,
        DataFrame,
    ]:
        valid_checks, invalid_checks = [], []
        filter_condition = reduce(
            and_,
            [
                dq_checks["business_status"].isin(self.status_filters),
                dq_checks["dq_rule_source"].isin(self.source_filters),
            ]
            + [dq_checks[col].isin(value) for col, value in self.extra_filters.items()],
        )
        all_checks = []
        filters_dict = defaultdict(list)
        filtered_checks_df = dq_checks.filter(filter_condition)
        for _filter in dq_filters.collect():
            filters_dict[_filter["dq_check_id"]].append(_filter)
        for num, check in enumerate(filtered_checks_df.collect()):
            check_filters = filters_dict.get(check["id"], [])
            check_json = self.return_check_json(check, check_filters)
            all_checks.append(check_json)
        (
            valid_checks,
            invalid_checks,
            check_errors_dict,
            checks_validated,
        ) = self.validate_checks_list(all_checks)
        valid_checks_df = filtered_checks_df.filter(
            filtered_checks_df["id"].isin([check["id"] for check in valid_checks])
        )
        return (
            valid_checks,
            invalid_checks,
            check_errors_dict,
            checks_validated,
            valid_checks_df,
        )

    def get_latest_filename(self, file_list: list):
        timestamps = [
            (file_name, file_name.split("_")[-1].split(".")[0])
            for file_name in file_list
        ]
        sorted_files = sorted(timestamps, key=lambda x: x[1], reverse=True)
        return sorted_files[0][0]

    def load_latest_dq_checks_and_filters(
        self, azure_handler: AzureFileHandler, container_name: str, base_path: str
    ) -> tuple[DataFrame, DataFrame]:
        all_files = azure_handler.list_files_in_container_folder(
            container=container_name,
            starts_with=base_path + "/dqlibrary_dqlibrary_dqchecks_v3",
            ends_with=".parquet",
        )
        timestamps = [
            (file_name, file_name.split("_")[-1].split(".")[0])
            for file_name in all_files
        ]
        dq_checks_path = sorted(timestamps, key=lambda x: x[1], reverse=True)[0][0]
        dq_filters_path = dq_checks_path.replace("dqchecks", "dqfilters")
        dq_lib_endpoint = self.reader_end_point
        dq_checks_parquet = self.spark.read.parquet(
            os.path.join(dq_lib_endpoint, dq_checks_path)
        )
        dq_filters_parquet = self.spark.read.parquet(
            os.path.join(dq_lib_endpoint, dq_filters_path)
        )

        return dq_checks_parquet, dq_filters_parquet

    def validate_and_log_v2(
        self,
        dq_checks_parquet_path: str,
        out_checks_path: str,
        out_filters_path: str,
        logs_directory: str = "check_outputs",
        dq_lib_logs_directory: str = "check_outputs",
        container_name: str = "main",
    ) -> tuple:
        """
        1 - Loads the checks and filters from given `dq_checks_parquet_path`.
        2 - Validates the checks and filters.

        Args:
            dq_checks_parquet_path: Storage account location where the parquet files for the checks and filters are stored.
            out_checks_path: Storage account location where the valid checks must be stored after validation.
            out_filters_path: Storage account location where the valid filters must be stored after validation.
            container_name: Name of the container where the checks and filters are loaded and stored.

        Returns:
            - valid_checks
            - invalid_checks
            - check_errors_dict
            - checks_validated

        Side Effects:
            This method writes outputs to external location. Valid checks and filters are stored in
            given `out_checks_path` and `out_filters_path` respectively.
            For invalid ones, a json file is stored in storage account folder "invalid_dq_checks".

        """
        dq_checks_df, dq_filters_df = self.load_latest_dq_checks_and_filters(
            azure_handler=self.dq_lib_file_handler,
            container_name=container_name,
            base_path=dq_checks_parquet_path,
        )

        (
            valid_checks,
            invalid_checks,
            check_errors_dict,
            checks_validated,
            valid_checks_df,
        ) = self.validate_checks_parquets(
            dq_checks=dq_checks_df, dq_filters=dq_filters_df
        )

        valid_check_ids = [check["id"] for check in valid_checks]
        valid_filters_df = dq_filters_df.filter(
            dq_filters_df["dq_check_id"].isin(valid_check_ids)
        )

        valid_checks_df.write.mode("overwrite").parquet(out_checks_path)
        valid_filters_df.write.mode("overwrite").parquet(out_filters_path)
        invalid_checks_out = json.dumps(
            obj={"version": 2, "checks": invalid_checks}, indent=4
        )
        invalid_checks_filename = f"DQ_Library/invalid_dq_checks/dq_checks_{datetime.datetime.now().strftime('%Y-%m-%d-%H:%M')}.json"
        self.dqe_file_handler.write_file_to_azure(
            container=self.dqe_container_name,
            data=invalid_checks_out,
            filename=invalid_checks_filename,
        )

        # write each check log
        for check_id, check_errors in check_errors_dict.items():
            log_check_output(
                spark=self.spark,
                rule_id=check_id,
                rule_json_dict=check_errors["rule_json"],
                error=check_errors["errors"],
                file_handler_dqe=self.dqe_file_handler,
                dqe_container_name=self.dqe_container_name,
                file_handler_dq_lib_obj=self.dq_lib_file_handler,
                dq_lib_container_name=container_name,
            )
        return valid_checks, invalid_checks, check_errors_dict, checks_validated
