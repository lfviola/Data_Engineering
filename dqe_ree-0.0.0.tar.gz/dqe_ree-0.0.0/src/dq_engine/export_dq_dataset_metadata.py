"""
DQ dataset metadata export class.

This class is responsible for aggregating and exporting dq dataset metadata in JSON format to a central location.
From here it is picked up by:
- DQ Library (in order to construct DQ dataset checks)
- DQE main flow (in order to translate DQ check definition to actual column names)

This happens through the following steps:
1. Getting locations of all metadata folders.
2. Finding metadata files in those folders.
2. Reading all metadata files from given respective locations.
3. Creating JSON as per given example (see below).
4. Saving JSON at specified location.

Class is used in regularly scheduled databricks workflow:
https://adb-647480779061657.17.azuredatabricks.net/jobs/847325298521068?o=647480779061657

example JSON:
{
        "version": 1,
        "dq_datasets": [
                {
                        "name": "dqd_Loan",
                        "id": "0000000000000000000000000000cc40",
                        "columns": [
                                {
                                        "column_name": "agreementId",
                                        "uuid": "0000000000000000000000000000ddff47",
                                        "data_attribute_id": 14548807,
                                        "primary_key": true
                                },
                                {
                                        "column_name": "agreementTypeId",
                                        "id": "0000000000000000000000000000effdff47",
                                        "data_attribute_id": 268304199,
                                        "primary_key": false
                                },
                                {
                                        "column_name": "governingCreditFacilityId",
                                        "id": "0000000000000000000000000000acff47",
                                        "data_attribute_id": 11337543,
                                        "primary_key": false
                                }
                        ]
                }
        ]
}

"""

import json
import logging
from collections import defaultdict
from hashlib import md5
from pyspark.sql import SparkSession, DataFrame
from pydantic import BaseModel, field_validator, ConfigDict

from dq_engine.utils.helpers import AzureFileHandler, DatabricksHelperFunctions
from dq_engine.rules.custom_exceptions import (
    FileNotFoundException,
    FileReadException,
)

logger = logging.getLogger(__name__)

allowed = {"yes": True, "no": False}


class ColumnMetadata(BaseModel):
    """
    Metadata record for a single column in a dq dataset / recipe.
    """

    dq_dataset_name: str
    column_name: str
    data_attribute_id: int
    primary_key: bool

    model_config = ConfigDict(extra="forbid")

    @field_validator("primary_key", mode="before")
    def convert_primary_key(cls, v):
        """Convert 'yes'/'no' strings to boolean values for primary_key."""
        if isinstance(v, str):
            value = v.strip().lower()
            if value not in allowed:
                raise ValueError(
                    "Incorrect metadata. Primary key must be either 'yes' or 'no'."
                )
            return allowed[value]
        return bool(v)

    @field_validator("column_name", mode="before")
    def check_column_name(cls, v):
        """Ensure the column name does not contain spaces."""
        if " " in v.strip():
            raise ValueError("Incorrect metadata. Column name must not contain spaces.")
        return v.strip()


class CreateDQDatasetMetadata:
    def __init__(
        self,
        metadata_folder_locations: list,
        output_location: str,
        azure_file_handlers: dict[str, AzureFileHandler],
        att_id_att_uuid_file_id_map: dict,
        databricks_helpers: DatabricksHelperFunctions,
        spark: SparkSession,
    ):
        """
        Args:
            metadata_folder_locations: A list of paths to the folders
                containing user created metadata files for dq datasets.
            output_location: The path where the output will be stored.
            azure_file_handlers: A dictionary where keys are strings
                representing different sources, and values are AzureFileHandler
                objects for handling Azure file operations.
            att_id_att_uuid_file_id_map: Mapping between the data attribute id and, the data attribute uuid and flat file id
                in the form {"data_attribute_id":  ("data_attribute_uuid", "flat_file_id), ...}

        """
        self.metadata_folder_locations = metadata_folder_locations
        self.output_location = output_location
        self.file_handler_objects: dict[str, AzureFileHandler] = azure_file_handlers
        self.att_id_att_uuid_file_id_map = att_id_att_uuid_file_id_map
        self.databricks_helpers = databricks_helpers
        self.spark = spark

    def read_metadata_files(self, file_endswith: str = ".csv") -> dict:
        """
        Reads user-created metadata files for DQ datasets.

        Args:
            file_endswith: File extension filter for metadata files.

        Returns:
            A dictionary mapping file names to their raw data.
        """
        metadata_file_data_map: dict = defaultdict(list)
        for _folder in self.metadata_folder_locations:
            file_handler = self.file_handler_objects[_folder.name]
            metadata_files = file_handler.list_files_in_container_folder(  # noqa
                container=_folder.container_name,
                starts_with=_folder.metadata_path,
                ends_with=file_endswith,
            )
            file_data = {
                _file: file_handler.read_file_from_container_azure(  # noqa
                    container=_folder.container_name, file_path=_file
                )
                for _file in metadata_files
                if _file.endswith(file_endswith)
            }
            metadata_file_data_map.update(file_data)

        return metadata_file_data_map

    @staticmethod
    def return_id(string_data: str):
        """
        Generates a unique identifier based on the MD5 hash of the input string.

        Args:
            string_data: The input string to hash.

        Returns:
            A 32-character hexadecimal MD5 hash.
        """
        return md5(string_data.encode()).hexdigest()

    @staticmethod
    def csv_data(data: bytes) -> list[list[str]]:
        """
        Parses CSV data using '|' as the separator.

        Args:
            data: Raw CSV file contents as bytes.

        Returns:
            ret_list: A list of lists representing CSV rows.
            column_headers: A list of column headers.
        """
        sep = "|"
        ret_list = []
        column_headers = (
            data.decode("utf-8-sig").split("\n")[0].strip().lower().split(sep)
        )
        for rec in data.decode("utf-8-sig").split("\n")[1:]:
            split_data = rec.strip().split(sep)
            if len(split_data) > 1:
                ret_list.append(split_data)
        return ret_list, column_headers

    def parse_metadata_row(
        self, row: list, column_headers: list[str], dataset_name: str, file_name: str
    ) -> dict | None:
        """
        Validate and parse a single CSV metadata row.

        Args:
            row: A list of strings representing a CSV row.
            column_headers: A list of column headers.
            dataset_name: The name of the dataset.
            file_name: The name of the file being processed.

        Returns:
            A dictionary with parsed metadata fields if valid; otherwise, None.
        """
        data = dict(zip(column_headers, row))
        try:
            record = ColumnMetadata.model_validate(data)
        except Exception as e:
            raise ValueError(
                f"Incorrect metadata. Validation error in file '{file_name}' for row '{row}': {e}"
            )
        # Ensure the attribute_id exists in the mapping.
        if record.data_attribute_id not in self.att_id_att_uuid_file_id_map:
            raise ValueError(
                f"Incorrect metadata. Attribute identifier '{record.data_attribute_id}' not found in metadata mapping "
                f"for column '{record.column_name}' in dataset '{record.dq_dataset_name}'."
            )

        return {
            "column_name": record.column_name,
            "uuid": self.return_id(record.column_name + dataset_name),
            "data_attribute_uuid": self.att_id_att_uuid_file_id_map[
                record.data_attribute_id
            ][0],
            "flat_file_id": self.att_id_att_uuid_file_id_map[record.data_attribute_id][
                1
            ],
            "data_attribute_id": record.data_attribute_id,
            "primary_key": record.primary_key,
        }

    @staticmethod
    def handle_duplicate_columns(
        columns_list: list[dict], dataset_name: str
    ) -> tuple[list[dict], list]:
        """
        Handle duplicate columns defined in metadata. Either remove 1 (when full duplicates) or ignore all (when conflicting definitions).

        Args:
            columns_list: List of column dictionaries.
            dataset_name: Name of the dataset.

        Returns:
            unique_columns: A list of unique column dictionaries if valid; otherwise, None.
            errors: A list with error information on ignored columns.
        """
        unique_columns = []
        seen_columns = {}
        duplicates = set()
        errors = []

        for column in columns_list:
            name = column.get("column_name")
            if name in seen_columns:
                if column == seen_columns[name]:
                    errors.append(
                        ValueError(
                            f"Metadata in dataset '{dataset_name}' contains duplicate column '{name}' that is exactly the same. Keeping one instance."
                        )
                    )
                    continue
                else:
                    errors.append(
                        ValueError(
                            f"Incorrect metadata. Metadata in dataset '{dataset_name}' contains duplicate column name '{name}' with conflicting definitions. Ignoring all duplicates."
                        )
                    )
                    duplicates.add(name)
            else:
                seen_columns[name] = column
                unique_columns.append(column)
        if duplicates:
            unique_columns = [
                col
                for col in unique_columns
                if col.get("column_name") not in duplicates
            ]
        return unique_columns, errors

    def validate_dataset_metadata(
        self, columns_list: list[dict], dataset_name: str
    ) -> tuple[list[dict], list]:
        """
        Validate all metadata columns defined for a DQ dataset / recipe. Validates primary key consistency and de-duplicates columns.

        Args:
            columns_list: List of column dictionaries.
            dataset_name: Name of the dataset.

        Returns:
            unique_columns: A list of unique column dictionaries if valid; otherwise, None.
            errors:
        """
        # Find and deal with missing primary key
        if not any(column.get("primary_key") for column in columns_list):
            return None, [
                ValueError(
                    f"Incorrect metadata. No primary key flagged as true for dataset '{dataset_name}'."
                )
            ]
        primary_key_flat_file_identifiers = [
            column.get("flat_file_id")
            for column in columns_list
            if column.get("primary_key")
        ]
        # Find and deal with incorrectly defined primary keys
        if len(set(primary_key_flat_file_identifiers)) > 1:
            return None, [
                ValueError(
                    f"Incorrect metadata. Not all primary keys in dataset '{dataset_name}' are defined on the same flat file."
                )
            ]
        unique_columns, errors = self.handle_duplicate_columns(
            columns_list, dataset_name
        )

        return unique_columns, errors

    def validate_metadata(
        self, metadata_file_data: dict[str, list]
    ) -> tuple[dict[str, list[dict]], list[str]]:
        """
        Parse and validate all DQ dataset column metadata. Ignore and do not process incorrect metadata.

        Args:
            metadata_file_data: A dictionary mapping filenames to metadata.

        Returns:
            valid_metadata: A dictionary mapping a dataset name to valid metadata.
        """
        valid_metadata: dict = {}
        for file_name, data in metadata_file_data.items():
            file_errors = []
            file_data_list, column_headers = self.csv_data(data)
            if not file_data_list:
                continue
            dataset_name = file_data_list[0][0]
            columns_metadata = []
            for row in file_data_list:
                try:
                    parsed = self.parse_metadata_row(
                        row, column_headers, dataset_name, file_name
                    )
                    columns_metadata.append(parsed)
                except ValueError as e:
                    file_errors.append(str(e))
            validated_dataset_columns, file_validation_errors = (
                self.validate_dataset_metadata(columns_metadata, dataset_name)
            )
            file_errors += file_validation_errors
            if validated_dataset_columns:
                consistent_dataset_columns, consistency_errors = (
                    self.verify_metadata_consistency(
                        dataset_name, validated_dataset_columns
                    )
                )
                file_errors += consistency_errors
                if consistent_dataset_columns:
                    valid_metadata[dataset_name] = consistent_dataset_columns
            if file_errors:
                logger.error(
                    f"Errors in metadata file '{file_name}' for dataset '{dataset_name}': {file_errors}"
                )
        return valid_metadata

    def create_metadata_list(self, valid_metadata: dict[str, list]) -> list[dict]:
        """
        Create a list containing all valid DQ dataset column metadata.

        Args:
            valid_metadata: A dictionary mapping dataset names to valid metadata.

        Returns:
            metadata_list: A list of dictionaries containing dataset metadata.
        """
        metadata_list = list()
        for dataset_name, columns in valid_metadata.items():
            file_metadata = {
                "name": dataset_name,
                "id": self.return_id(dataset_name),
                "columns": columns,
            }
            metadata_list.append(file_metadata)
        return metadata_list

    def verify_metadata_consistency(
        self, dataset_name: str, columns_metadata: list[dict]
    ) -> tuple[list[dict], list]:
        """
        Verify that the metadata column definitions align with the actual data column definitions.

        Args:
            dataset_name: The name of the dataset being validated.
            columns_metadata: A list of metadata column definitions.

        Returns:
            consistent_columns_metadata: A list of consistent metadata column definitions.
            errors: A list with error information on ignored columns.
        """
        errors = []
        try:
            df = self.load_dq_dataset(dataset_name)
        except (
            FileNotFoundException,
            FileReadException,
        ):
            errors.append(
                "Warning. Physical data does not exist. We will not check consistency as it is assumed this is a new dataset."
            )
            return columns_metadata, errors
        data_columns = list(df.columns)
        data_columns = [col.upper() for col in data_columns]
        metadata_columns = [
            metadata["column_name"].upper() for metadata in columns_metadata
        ]

        forgotten_data_columns = list(set(data_columns) - set(metadata_columns))
        if forgotten_data_columns:
            errors.append(
                f"Warning. Metadata and physical data for dataset '{dataset_name}' are not consistent. The following columns are defined in the data but are not present in the metadata: {forgotten_data_columns}, maybe they are forgotten."
            )
        incorrect_metadata_columns = list(set(metadata_columns) - set(data_columns))
        if incorrect_metadata_columns:
            errors.append(
                ValueError(
                    f"Invalid metadata. Metadata and physical data for dataset '{dataset_name}' are not consistent. The following columns are defined in the metadata but are not present in the data: {incorrect_metadata_columns}. These will be ignored."
                )
            )
        consistent_columns_metadata = [
            column
            for column in columns_metadata
            if column["column_name"].upper() not in incorrect_metadata_columns
        ]
        return consistent_columns_metadata, errors

    def load_dq_dataset(self, dataset_name: str) -> DataFrame | None:
        """
        Load the dataset from the latest snapshot file path.

        Args:
            dataset_name: The name of the dq dataset to load.

        Returns:
            A Spark DataFrame containing the dq dataset.
        """
        snapshot_path = self.databricks_helpers.get_latest_snapshot_file_path(
            file_name=dataset_name, location="dqrem"
        )
        df = self.spark.read.parquet(snapshot_path)
        return df

    def save_metadata(
        self,
        dqe_file_handler: AzureFileHandler,
        json_data: list,
        dqe_obj,
        base_dict: dict,
        update_key: str,
    ):
        """
        Save the metadata JSON to Azure Storage.

        Args:
            dqe_file_handler: An AzureFileHandler instance for the DQE storage account.
            json_data: The metadata JSON data.
            dqe_obj: Object containing DQE configuration with default container name.
            base_dict: Base dictionary to update with metadata.
            update_key: Key used to update the base_dict.

        """
        base_dict.update({update_key: json_data})
        dqe_file_handler.write_file_to_azure(
            container=dqe_obj.default_container_name,
            data=json.dumps(base_dict, indent=4),
            filename=self.output_location,
        )

    def export_metadata(self, dqe_obj, base_dict, update_key, file_endswith=".csv"):
        "Main method to extract, parse, validate and save dq dataset metadata."
        metadata_file_data = self.read_metadata_files(file_endswith=file_endswith)
        validated_metadata = self.validate_metadata(metadata_file_data)
        metadata_json = self.create_metadata_list(validated_metadata)
        self.save_metadata(
            self.file_handler_objects["dqe-data"],
            json_data=metadata_json,
            dqe_obj=dqe_obj,
            base_dict=base_dict,
            update_key=update_key,
        )
